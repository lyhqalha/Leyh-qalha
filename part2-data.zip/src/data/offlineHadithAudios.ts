/**
 * Offline Hadiths and Stories Pre-stored Audio Registry
 * 
 * Pre-packages reciter audio tracks directly into the application bundle
 * so that Hadith recitation and Story narrations play 100% offline
 * with the exact same tranquil, reverent recitation voice without needing internet.
 */

export interface PrepackagedHadithTrack {
  hadithId: string;
  hasHadithAudio: boolean;
  hasStoryAudio: boolean;
  hadithUrl: string;
  storyUrl: string;
}

export const PREPACKAGED_HADITH_MAP: Record<string, { hadith: string; story: string }> = {
  'hadith-1': {
    hadith: '/audio/hadiths/hadith-1.mp3',
    story: '/audio/stories/hadith-1.mp3'
  },
  'hadith-1283': {
    hadith: '/audio/hadiths/hadith-1283.mp3',
    story: '/audio/stories/hadith-1283.mp3'
  },
  'hadith-15': {
    hadith: '/audio/hadiths/hadith-15.mp3',
    story: '/audio/stories/hadith-15.mp3'
  },
  'hadith-1956': {
    hadith: '/audio/hadiths/hadith-1956.mp3',
    story: '/audio/stories/hadith-1956.mp3'
  },
  'hadith-2516': {
    hadith: '/audio/hadiths/hadith-2516.mp3',
    story: '/audio/stories/hadith-2516.mp3'
  },
  'hadith-2747': {
    hadith: '/audio/hadiths/hadith-2747.mp3',
    story: ''
  },
  'hadith-5027': {
    hadith: '/audio/hadiths/hadith-5027.mp3',
    story: ''
  },
  'hadith-5376': {
    hadith: '/audio/hadiths/hadith-5376.mp3',
    story: '/audio/stories/hadith-5376.mp3'
  },
  'hadith-5971': {
    hadith: '/audio/hadiths/hadith-5971.mp3',
    story: '/audio/stories/hadith-5971.mp3'
  },
  'hadith-5997': {
    hadith: '/audio/hadiths/hadith-5997.mp3',
    story: '/audio/stories/hadith-5997.mp3'
  },
  'hadith-6011': {
    hadith: '/audio/hadiths/hadith-6011.mp3',
    story: '/audio/stories/hadith-6011.mp3'
  },
  'hadith-6018': {
    hadith: '/audio/hadiths/hadith-6018.mp3',
    story: '/audio/stories/hadith-6018.mp3'
  },
  'hadith-6116': {
    hadith: '/audio/hadiths/hadith-6116.mp3',
    story: '/audio/stories/hadith-6116.mp3'
  },
  'hadith-631': {
    hadith: '/audio/hadiths/hadith-631.mp3',
    story: '/audio/stories/hadith-631.mp3'
  },
  'hadith-9': {
    hadith: '/audio/hadiths/hadith-9.mp3',
    story: '/audio/stories/hadith-9.mp3'
  }
};

/**
 * Checks if a pre-stored offline audio file exists on the application.
 */
export function hasPrepackagedAudio(hadithId: string, type: 'hadith' | 'story' = 'hadith'): boolean {
  if (!hadithId) return false;
  const entry = PREPACKAGED_HADITH_MAP[hadithId];
  if (!entry) return false;
  return Boolean(type === 'story' ? entry.story : entry.hadith);
}

/**
 * Gets the direct offline path to the stored audio file.
 */
export function getPrepackagedAudioPath(hadithId: string, type: 'hadith' | 'story' = 'hadith'): string | null {
  if (!hadithId) return null;
  const entry = PREPACKAGED_HADITH_MAP[hadithId];
  if (!entry) return null;
  return type === 'story' ? (entry.story || null) : (entry.hadith || null);
}

/**
 * Returns all pre-packaged tracks for offline caching and verification.
 */
export function getAllPrepackagedTracks(): { id: string; url: string; type: 'hadith' | 'story' }[] {
  const list: { id: string; url: string; type: 'hadith' | 'story' }[] = [];
  for (const [hadithId, urls] of Object.entries(PREPACKAGED_HADITH_MAP)) {
    if (urls.hadith) list.push({ id: `${hadithId}_hadith`, url: urls.hadith, type: 'hadith' });
    if (urls.story) list.push({ id: `${hadithId}_story`, url: urls.story, type: 'story' });
  }
  return list;
}
