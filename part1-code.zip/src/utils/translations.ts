export type AppLanguage = 'ar' | 'en' | 'ur' | 'fa';

export interface LanguageOption {
  code: AppLanguage;
  name: string;
  nativeName: string;
  flag: string;
  dir: 'rtl' | 'ltr';
}

export const SUPPORTED_LANGUAGES: LanguageOption[] = [
  { code: 'ar', name: 'Arabic', nativeName: 'العربية', flag: '🇸🇦', dir: 'rtl' },
  { code: 'en', name: 'English', nativeName: 'English', flag: '🇬🇧', dir: 'ltr' },
  { code: 'ur', name: 'Urdu', nativeName: 'اردو', flag: '🇵🇰', dir: 'rtl' },
  { code: 'fa', name: 'Persian', nativeName: 'فارسی', flag: '🇮🇷', dir: 'rtl' },
];

export const translations = {
  ar: {
    // Header & Brand
    appTitle: 'ليه قالها؟',
    appSubtitle: 'كل حديث قصة قبل أن يكون كلمة',
    charitableTag: 'وقف لله تعالى ولروح الحبيب المصطفى ﷺ',
    charitableSub: 'عمل خيري خالص لوجه الله تعالى',
    charitableNotice: 'تطبيق «ليه قالها؟» عمل وقفي خيري غير ربحي يهدف لتقريب معاني السنة النبوية الشريفة وأسباب ورود الأحاديث بلغة راقية وتجربة صوتية مريحة للقلوب.',

    // Common Actions
    search: 'البحث',
    settings: 'الإعدادات',
    stats: 'إحصائياتي',
    about: 'عن التطبيق',
    close: 'إغلاق',
    saveAndClose: 'حفظ وإغلاق',
    cancel: 'إلغاء',
    dismiss: 'تجاهل',
    offline: 'أوفلاين',
    share: 'مشاركة',
    bookmark: 'حفظ',
    bookmarked: 'محفوظ',
    copied: 'تم النسخ بنجاح',
    back: 'رجوع',
    backBtn: 'رجوع',
    prevBtn: 'السابق',
    nextBtn: 'التالي',

    // Language Selector
    language: 'لغة التطبيق',
    chooseLanguage: 'اختر لغة التطبيق',
    languageDescription: 'تغيير لغة التطبيق بالكامل (الأحاديث والقصص والواجهة)',

    // Navigation Tabs
    navHome: 'الرئيسية',
    navSaved: 'المحفوظات',
    navSearch: 'البحث',
    navDaily: 'حديث اليوم',
    navCategories: 'التصنيفات',

    // Home Screen
    beforeReading: 'قبل أن تقرأ الحديث...',
    startTodayStory: 'ابدأ قصة اليوم',
    todayDatePrefix: 'حديث اليوم · ',
    streakTitle: 'سلسلة القراءة:',
    streakDaysSingular: 'يوم',
    streakDaysDual: 'يومان',
    streakDaysPlural: 'أيام متتالية',
    startStreakPrompt: 'ابدأ سلسلة قراءتك اليومية الآن 🔥',
    mashaAllah: 'ما شاء الله!',
    statsSummary: 'قرأت {read} من {total} حديثاً · اضغط لعرض إنجازاتك',
    statsBoard: 'لوحة الإنجاز',
    charitableBannerTitle: 'عمل خيري خالص لوجه الله',
    charitableBannerSub: 'عن التطبيق، أهدافه، ورجاء الدعاء بالخير ❤️',

    // Highlights
    highlightsAuthentic: '2000+ حديث صحيح',
    highlightsScenes: '5 مشاهد تفاعلية',
    highlightsCalmAudio: 'صوتيات سكينة وتأمل',
    highlightsCards: 'بطاقات مصممة',

    // Periodic Athkar Reminder (Pure Athkar)
    dhikrTitle: 'الأذكار',
    dhikrBadge: 'تذكير دوري',
    dhikrSub: 'تذكير دوري بذكر الله والصلاة على النبي ﷺ',
    dhikrIntervalLabel: 'تكرار التذكير (يقول ذكراً مختلفاً في كل مرة):',
    every15m: 'كل 15 دقيقة',
    every15mSub: 'ذكر مختلف',
    every30m: 'كل 30 دقيقة',
    every30mSub: 'نصف ساعة (الافتراضي)',
    every60m: 'كل 60 دقيقة',
    every60mSub: 'كل ساعة',
    listenPodcastNow: '🔊 استمع للذكر الآن',
    stopPodcastNow: 'إيقاف الصوت الآن',
    listenDhikrNow: '🔊 استمع للذكر الآن',
    stopDhikrNow: 'إيقاف الصوت الآن',
    dhikrDisabledPrompt: 'التذكير الدوري معطل حالياً. يمكنك تفعيله بضغطة زر أعلاه.',
    dhikrQualityBadge: 'الأذكار مدمجة وتعمل 100% بدون إنترنت بصوت نقي وعالي.',
    dhikrNowNotice: 'ذكر الله',
    athkarClickListen: 'الأذكار (اضغط للاستماع):',

    // Download All Audio Pack
    downloadPackTitle: 'حفظ صوتيات الأحاديث والقصص والأذكار',
    downloadPackDesc: 'تخزين الصوتيات في ذاكرة التطبيق للعمل 100% بدون إنترنت بنبرة التلاوة الوقورة الخاشعة.',
    downloadPackBtn: '📥 حفظ حزمة الصوتيات أوفلاين الآن',
    downloadingPackProgress: 'جاري حفظ الصوتيات في ذاكرة التطبيق ({progress}%)...',
    downloadPackSuccess: '✅ تم حفظ الصوتيات بنجاح (تعمل 100% بدون إنترنت)',
    downloadPackVerify: '🔄 إعادة التحقق وتحديث الصوتيات',
    packStatsInfo: 'صوتيات وقورة للأحاديث والقصص والأذكار · مخزنة محلياً في التطبيق وتعمل بدون إنترنت',

    // Font Size
    fontSizeTitle: 'حجم خط المتن النبوي والقصص',
    fontSmall: 'صغير',
    fontSmallDesc: 'للشاشات الصغيرة',
    fontMedium: 'متوسط',
    fontMediumDesc: 'مريح ومتوازن',
    fontLarge: 'كبير',
    fontLargeDesc: 'واضح جداً للعين',

    // Daily Notification
    dailyNotifTitle: 'إشعار حديث اليوم',
    dailyNotifSub: 'تذكير يومي لتدبر حديث نبوي شريف جديد',
    setAlertTime: 'حدد وقت التنبيه:',
    testNotifBtn: 'تجربة الإشعار الآن',
    testNotifSent: 'تم إرسال إشعار تجريبي بنجاح!',
    dawnPreset: 'فجراً',
    morningPreset: 'صباحاً',
    afternoonPreset: 'عصراً',
    eveningPreset: 'مساءً',

    // Offline Audios
    offlineAudiosTitle: 'أحاديث وقصص محفوظة أوفلاين',
    offlineAudiosDesc: 'يمكنك تحميل أي حديث أو قصة للاستماع إليها أوفلاين دون إنترنت عبر زر التحميل داخل شاشة الحديث.',
    clearOfflineAudiosBtn: 'حذف الأحاديث والقصص المحفوظة لتفريغ المساحة',
    confirmClearOffline: 'هل تريد حذف جميع الملفات الصوتية المحفوظة لتفريغ المساحة؟',

    // Story View
    storyTab: 'القصة وسبب الورود',
    hadithTab: 'متن الحديث الشريف',
    playStory: 'استمع للقصة',
    pauseStory: 'إيقاف مؤقت',
    sceneLabel: 'المشهد',
    reflectionPrompt: 'وقفة تأمل:',
    hadithExcerpt: 'من هدي النبوة:',
    practicalLessons: 'الدروس المستفادة:',
    narratorLabel: 'الراوي:',
    sourceLabel: 'المصدر:',
    bookLabel: 'الكتاب:',
    gradeLabel: 'درجة الحديث:',
    sanadLabel: 'السند وسلسلة الرواية:',
    readTodayHadithNow: 'اقرأ حديث اليوم الآن',
    shareHadith: 'مشاركة بطاقة الحديث',
    listenStory: 'الاستماع للقصة',
    listenStoryAudio: 'الاستماع للقصة صوتياً',
    viewStory5Scenes: 'عرض القصة (٥ مشاهد)',
    listenHadith: 'استماع الحديث',
    hadithDetailTitle: 'الحديث الشريف',
    storyContextLabel: 'القصة التاريخية وسبب الورود',
    practicalBenefitLabel: 'الفائدة والدروس المستفادة',
    explanationLabel: 'شرح الحديث النبوي',
    hadithNumber: 'رقم: ',
    hadithFullPage: 'صفحة الحديث وتخريجه',
    stopStory: 'إيقاف',
    fullStoryPlaying: 'الاستماع للقصة كاملة (٥ مشاهد متتالية)',
    singleScenePlaying: 'استماع هذا المشهد فقط',
    stopScene: 'إيقاف المشهد',
    ambientSound: 'مؤثرات المشهد:',

    // Daily Hadith View
    dailyHadithHeading: 'حديث اليوم',
    nextDay: 'اليوم التالي',
    prevDay: 'اليوم السابق',
    dailyParchmentTitle: 'متن حديث اليوم',

    // Categories View
    categoriesTitle: 'تصنيفات الأحاديث',
    categoriesSub: 'تصفح أكثر من 2000 حديث مقسمة حسب الموضوع',
    backToCategories: 'العودة للتصنيفات',
    hadithsCount: '{count} حديث',

    // Saved View
    savedTitle: 'المحفوظات',
    savedHadithsHeading: 'المحفوظات',
    tabAll: 'الكل',
    tabFavorites: 'المفضلة',
    noSavedTitle: 'لا توجد أحاديث محفوظة حالياً',
    noSavedPrompt: 'لا توجد أحاديث محفوظة حالياً',
    noSavedDesc: 'اضغط على علامة الحفظ في أي حديث لتتمكن من الرجوع إليه وقراءته أو الاستماع إليه لاحقاً.',
    noSavedSub: 'اضغط على علامة الحفظ في أي حديث لتتمكن من الرجوع إليه وقراءته أو الاستماع إليه لاحقاً.',

    // Search View
    searchPlaceholder: 'ابحث بالكلمة، الموضوع، أو الراوي...',
    searchScopeAll: 'الكل',
    searchScopeHadith: 'نص الحديث',
    searchScopeNarrator: 'الراوي',
    searchScopeTopic: 'الموضوع',
    recentSearches: 'عمليات البحث السابقة',
    noSearchResults: 'لم يتم العثور على نتائج',
    noSearchSub: 'جرب البحث بكلمات أخرى أو تغيير نطاق البحث',
  },

  en: {
    // Header & Brand
    appTitle: 'Why Did He Say It?',
    appSubtitle: 'Every Hadith is a story before it became a word',
    charitableTag: 'Endowment for Allah & the beloved Prophet ﷺ',
    charitableSub: 'A sincere charitable initiative for the sake of Allah',
    charitableNotice: '"Why Did He Say It?" is a non-profit educational endowment designed to bring the context and stories behind Prophetic Hadiths to life with a peaceful audio experience.',

    // Common Actions
    search: 'Search',
    settings: 'Settings',
    stats: 'My Stats',
    about: 'About App',
    close: 'Close',
    saveAndClose: 'Save & Close',
    cancel: 'Cancel',
    dismiss: 'Dismiss',
    offline: 'Offline',
    share: 'Share',
    bookmark: 'Bookmark',
    bookmarked: 'Bookmarked',
    copied: 'Copied successfully',
    back: 'Back',
    backBtn: 'Back',
    prevBtn: 'Previous',
    nextBtn: 'Next',

    // Language Selector
    language: 'App Language',
    chooseLanguage: 'Select App Language',
    languageDescription: 'Change the entire application language (Hadiths, stories & UI)',

    // Navigation Tabs
    navHome: 'Home',
    navSaved: 'Bookmarks',
    navSearch: 'Search',
    navDaily: 'Daily Hadith',
    navCategories: 'Categories',

    // Home Screen
    beforeReading: 'Before you read the Hadith...',
    startTodayStory: "Start Today's Story",
    todayDatePrefix: "Today's Hadith · ",
    streakTitle: 'Reading Streak:',
    streakDaysSingular: 'day',
    streakDaysDual: 'days',
    streakDaysPlural: 'consecutive days',
    startStreakPrompt: 'Start your daily reading streak 🔥',
    mashaAllah: 'MashaAllah!',
    statsSummary: 'Read {read} of {total} Hadiths · Tap to view stats',
    statsBoard: 'Stats Board',
    charitableBannerTitle: 'Pure Charitable Act for Allah',
    charitableBannerSub: 'About the app, its mission, and sincere prayers ❤️',

    // Highlights
    highlightsAuthentic: '2000+ Authentic Hadiths',
    highlightsScenes: '5 Interactive Scenes',
    highlightsCalmAudio: 'Peaceful Reflections',
    highlightsCards: 'Designed Share Cards',

    // Periodic Athkar Reminder
    dhikrTitle: 'Athkar (Remembrances)',
    dhikrBadge: 'Periodic Reminder',
    dhikrSub: 'Periodic reminders to remember Allah and send blessings on the Prophet ﷺ',
    dhikrIntervalLabel: 'Reminder interval (recites a different Dhikr each time):',
    every15m: 'Every 15 minutes',
    every15mSub: 'Different Dhikr',
    every30m: 'Every 30 minutes',
    every30mSub: 'Half-hour (Default)',
    every60m: 'Every 60 minutes',
    every60mSub: 'Every hour',
    listenPodcastNow: '🔊 Listen to Dhikr Now',
    stopPodcastNow: 'Stop Audio',
    listenDhikrNow: '🔊 Listen to Dhikr Now',
    stopDhikrNow: 'Stop Audio',
    dhikrDisabledPrompt: 'Periodic reminder is currently disabled. Enable it with one tap above.',
    dhikrQualityBadge: 'Athkar are embedded and work 100% offline with clear audio.',
    dhikrNowNotice: 'Remembrance of Allah',
    athkarClickListen: 'Athkar (Tap to listen):',

    // Download All Audio Pack
    downloadPackTitle: 'Offline Hadiths, Stories & Athkar Pack',
    downloadPackDesc: 'Store audio tracks locally for 100% offline playback with the reverent recitation voice.',
    downloadPackBtn: '📥 Save All Offline Audio Now',
    downloadingPackProgress: 'Saving audio tracks into app storage ({progress}%)...',
    downloadPackSuccess: '✅ Audio saved successfully (works 100% offline)',
    downloadPackVerify: '🔄 Verify and refresh offline audio cache',
    packStatsInfo: 'Reverent reciter audio for Hadiths, Stories & Athkar · Stored offline without internet',

    // Font Size
    fontSizeTitle: 'Text Size for Hadith & Stories',
    fontSmall: 'Small',
    fontSmallDesc: 'For compact screens',
    fontMedium: 'Medium',
    fontMediumDesc: 'Balanced & comfortable',
    fontLarge: 'Large',
    fontLargeDesc: 'Very easy to read',

    // Daily Notification
    dailyNotifTitle: "Daily Hadith Notification",
    dailyNotifSub: 'Daily alert to reflect on a new authentic Hadith',
    setAlertTime: 'Set notification time:',
    testNotifBtn: 'Test notification now',
    testNotifSent: 'Test notification sent successfully!',
    dawnPreset: 'Dawn',
    morningPreset: 'Morning',
    afternoonPreset: 'Afternoon',
    eveningPreset: 'Evening',

    // Offline Audios
    offlineAudiosTitle: 'Offline Saved Hadiths & Stories',
    offlineAudiosDesc: 'You can download any Hadith or story to listen offline via the download icon.',
    clearOfflineAudiosBtn: 'Clear cached audio files to free storage',
    confirmClearOffline: 'Do you want to clear all offline audio files to free storage?',

    // Story View
    storyTab: 'Story & Historical Context',
    hadithTab: 'Noble Hadith Text',
    playStory: 'Listen to Story',
    pauseStory: 'Pause Audio',
    sceneLabel: 'Scene',
    reflectionPrompt: 'Pause & Reflect:',
    hadithExcerpt: 'Prophetic Guidance:',
    practicalLessons: 'Lessons Learned:',
    narratorLabel: 'Narrator:',
    sourceLabel: 'Source:',
    bookLabel: 'Book:',
    gradeLabel: 'Authenticity Grade:',
    sanadLabel: 'Chain of Transmission (Sanad):',
    readTodayHadithNow: "Read Today's Hadith Now",
    shareHadith: 'Share Hadith Card',
    listenStory: 'Listen to Story',
    listenStoryAudio: 'Listen to Story Audio',
    viewStory5Scenes: 'View Story (5 Scenes)',
    listenHadith: 'Listen to Hadith',
    hadithDetailTitle: 'Noble Hadith',
    storyContextLabel: 'Historical Story & Background',
    practicalBenefitLabel: 'Practical Benefits & Lessons',
    explanationLabel: 'Hadith Explanation',
    hadithNumber: 'No: ',
    hadithFullPage: 'Hadith Page & Sources',
    stopStory: 'Stop',
    fullStoryPlaying: 'Listen to Full Story (5 Scenes)',
    singleScenePlaying: 'Listen to this scene only',
    stopScene: 'Stop Scene',
    ambientSound: 'Scene Ambience:',

    // Daily Hadith View
    dailyHadithHeading: "Today's Hadith",
    nextDay: 'Next Day',
    prevDay: 'Previous Day',
    dailyParchmentTitle: "Today's Hadith Text",

    // Categories View
    categoriesTitle: 'Hadith Categories',
    categoriesSub: 'Explore over 2,000 Hadiths organized by topic',
    backToCategories: 'Back to Categories',
    hadithsCount: '{count} Hadiths',

    // Saved View
    savedTitle: 'Bookmarks',
    savedHadithsHeading: 'Bookmarks',
    tabAll: 'All',
    tabFavorites: 'Favorites',
    noSavedTitle: 'No saved Hadiths yet',
    noSavedPrompt: 'No saved Hadiths yet',
    noSavedDesc: 'Tap the bookmark icon on any Hadith to save it for reading or listening offline.',
    noSavedSub: 'Tap the bookmark icon on any Hadith to save it for reading or listening offline.',

    // Search View
    searchPlaceholder: 'Search by keyword, topic, or narrator...',
    searchScopeAll: 'All',
    searchScopeHadith: 'Hadith Text',
    searchScopeNarrator: 'Narrator',
    searchScopeTopic: 'Topic',
    recentSearches: 'Recent Searches',
    noSearchResults: 'No results found',
    noSearchSub: 'Try searching with different keywords or changing filter',
  },

  ur: {
    // Header & Brand
    appTitle: 'کیوں فرمایا؟',
    appSubtitle: 'ہر حدیث ایک کلمہ بننے سے پہلے ایک واقعہ ہے',
    charitableTag: 'وقف فی سبیل اللہ و روح نبی اکرم ﷺ',
    charitableSub: 'خالصتاً رضائے الٰہی کے لیے ایک فلاحی کاوش',
    charitableNotice: 'ایپ «کیوں فرمایا؟» ایک غیر تجارتی فلاحی خدمت ہے جس کا مقصد احادیث نبویہ کے تاریخی اسباب ورود کو دلکش انداز اور پرسکون صوتی تجربے کے ساتھ پیش کرنا ہے۔',

    // Common Actions
    search: 'تلاش',
    settings: 'ترتیبات',
    stats: 'میری کارکردگی',
    about: 'ایپ کے بارے میں',
    close: 'بند کریں',
    saveAndClose: 'محفوظ کر کے بند کریں',
    cancel: 'منسوخ',
    dismiss: 'نظر انداز',
    offline: 'آف لائن',
    share: 'شیئر کریں',
    bookmark: 'محفوظ کریں',
    bookmarked: 'محفوظ شدہ',
    copied: 'کامیابی سے کاپی ہو گیا',
    back: 'واپس',
    backBtn: 'واپس',
    prevBtn: 'پچھلا',
    nextBtn: 'اگلا',

    // Language Selector
    language: 'ایپ کی زبان',
    chooseLanguage: 'ایپ کی زبان منتخب کریں',
    languageDescription: 'مکمل ایپ کی زبان تبدیل کریں (احادیث، واقعات اور انٹرفیس)',

    // Navigation Tabs
    navHome: 'مرکزی صفحہ',
    navSaved: 'محفوظ شدہ',
    navSearch: 'تلاش',
    navDaily: 'آج کی حدیث',
    navCategories: 'زمرہ جات',

    // Home Screen
    beforeReading: 'حدیث پڑھنے سے پہلے...',
    startTodayStory: 'آج کا واقعہ شروع کریں',
    todayDatePrefix: 'آج کی حدیث · ',
    streakTitle: 'مسلسل مطالعہ:',
    streakDaysSingular: 'دن',
    streakDaysDual: 'دو دن',
    streakDaysPlural: 'مسلسل دن',
    startStreakPrompt: 'اپنے روزانہ کے مطالعے کا آغاز کریں 🔥',
    mashaAllah: 'ماشاء اللہ!',
    statsSummary: '{total} میں سے {read} احادیث پڑھی گئیں',
    statsBoard: 'کارکردگی بورڈ',
    charitableBannerTitle: 'خالصتاً رضائے الٰہی کے لیے',
    charitableBannerSub: 'ایپ کا تعارف، مقاصد اور دعائے خیر ❤️',

    // Highlights
    highlightsAuthentic: '2000+ صحیح احادیث',
    highlightsScenes: '5 انٹرایکٹو مناظر',
    highlightsCalmAudio: 'روح پرور صوتیات',
    highlightsCards: 'خوبصورت شیئر کارڈز',

    // Periodic Athkar Reminder
    dhikrTitle: 'اذکار',
    dhikrBadge: 'وقتاً فوقتاً یاد دہانی',
    dhikrSub: 'ذکر الٰہی اور درود شریف کی باقاعدہ یاد دہانی',
    dhikrIntervalLabel: 'یاد دہانی کا وقفہ (ہر بار مختلف ذکر):',
    every15m: 'ہر 15 منٹ بعد',
    every15mSub: 'مختلف ذکر',
    every30m: 'ہر 30 منٹ بعد',
    every30mSub: 'آدھا گھنٹہ (پہلے سے طے شدہ)',
    every60m: 'ہر 60 منٹ بعد',
    every60mSub: 'ہر گھنٹے بعد',
    listenPodcastNow: '🔊 ابھی ذکر سنیں',
    stopPodcastNow: 'آواز بند کریں',
    listenDhikrNow: '🔊 ابھی ذکر سنیں',
    stopDhikrNow: 'آواز بند کریں',
    dhikrDisabledPrompt: 'وقتاً فوقتاً یاد دہانی فی الحال بند ہے۔ اوپر کلک کر کے فعال کریں۔',
    dhikrQualityBadge: 'تمام اذکار ایپ میں موجود ہیں اور انٹرنیٹ کے بغیر بلند آواز میں چلتے ہیں۔',
    dhikrNowNotice: 'ذکر الٰہی',
    athkarClickListen: 'اذکار (سننے کے لیے دبائیں):',

    // Download All Audio Pack
    downloadPackTitle: 'احادیث، واقعات اور اذکار کا آڈیو پیک',
    downloadPackDesc: 'تمام آڈیوز ایپ میں محفوظ کریں تاکہ پروقار تلاوت کی آواز میں 100% انٹرنیٹ کے بغیر چلیں۔',
    downloadPackBtn: '📥 مکمل آف لائن آڈیو پیک محفوظ کریں',
    downloadingPackProgress: 'صوتی فائلیں محفوظ کی جا رہی ہیں ({progress}%)...',
    downloadPackSuccess: '✅ آڈیوز کامیابی سے محفوظ ہو گئیں (100% آف لائن)',
    downloadPackVerify: '🔄 آڈیوز کی جانچ اور تجدید کریں',
    packStatsInfo: 'پروقار تلاوت والی احادیث، واقعات اور اذکار · ایپ میں مکمل آف لائن دستیاب',

    // Font Size
    fontSizeTitle: 'متن حدیث اور واقعات کا فونٹ سائز',
    fontSmall: 'چھوٹا',
    fontSmallDesc: 'چھوٹی سکرین کے لیے',
    fontMedium: 'درمیانہ',
    fontMediumDesc: 'آرام دہ اور متوازن',
    fontLarge: 'بڑا',
    fontLargeDesc: 'واضح اور پڑھنے میں آسان',

    // Daily Notification
    dailyNotifTitle: 'آج کی حدیث کا نوٹیفکیشن',
    dailyNotifSub: 'روزانہ نئی صحیح حدیث پر غور و فکر کی یاد دہانی',
    setAlertTime: 'وقت منتخب کریں:',
    testNotifBtn: 'نوٹیفکیشن آزمائیں',
    testNotifSent: 'آزمائشی نوٹیفکیشن بھیج دیا گیا!',
    dawnPreset: 'فجر',
    morningPreset: 'صبح',
    afternoonPreset: 'عصر',
    eveningPreset: 'شام',

    // Offline Audios
    offlineAudiosTitle: 'آف لائن محفوظ شدہ مواد',
    offlineAudiosDesc: 'آپ کسی بھی حدیث یا واقعے کو ڈاؤن لوڈ کر کے آف لائن سن سکتے ہیں۔',
    clearOfflineAudiosBtn: 'میموری خالی کرنے کے لیے آڈیو فائلیں حذف کریں',
    confirmClearOffline: 'کیا آپ محفوظ شدہ آڈیو فائلیں حذف کرنا چاہتے ہیں؟',

    // Story View
    storyTab: 'واقعہ اور پس منظر',
    hadithTab: 'حدیث مبارکہ کا متن',
    playStory: 'واقعہ سنیں',
    pauseStory: 'وقفہ کریں',
    sceneLabel: 'منظر',
    reflectionPrompt: 'غور فرمائیں:',
    hadithExcerpt: 'فرمان نبوی:',
    practicalLessons: 'عملی اسباق:',
    narratorLabel: 'راوی:',
    sourceLabel: 'ماخذ:',
    bookLabel: 'کتاب:',
    gradeLabel: 'حدیث کا درجہ:',
    sanadLabel: 'سند اور روایت کا سلسلہ:',
    readTodayHadithNow: 'آج کی حدیث ابھی پڑھیں',
    shareHadith: 'حدیث کارڈ شیئر کریں',
    listenStory: 'واقعہ سنیں',
    listenStoryAudio: 'واقعہ کی آڈیو سنیں',
    viewStory5Scenes: 'واقعہ دیکھیں (۵ مناظر)',
    listenHadith: 'حدیث سنیں',
    hadithDetailTitle: 'حدیث شریف',
    storyContextLabel: 'تاریخی واقعہ اور سبب ورود',
    practicalBenefitLabel: 'فوائد اور عملی اسباق',
    explanationLabel: 'شرح حدیث نبوی',
    hadithNumber: 'نمبر: ',
    hadithFullPage: 'حدیث اور تخریج کا صفحہ',
    stopStory: 'روکیں',
    fullStoryPlaying: 'مکمل واقعہ سنیں (۵ مناظر)',
    singleScenePlaying: 'صرف یہ منظر سنیں',
    stopScene: 'منظر روکیں',
    ambientSound: 'منظر کا پس منظر:',

    // Daily Hadith View
    dailyHadithHeading: 'آج کی حدیث',
    nextDay: 'اگلا دن',
    prevDay: 'پچھلا دن',
    dailyParchmentTitle: 'آج کی حدیث کا متن',

    // Categories View
    categoriesTitle: 'احادیث کے زمرے',
    categoriesSub: 'موضوعات کے اعتبار سے 2000 سے زائد احادیث دیکھیں',
    backToCategories: 'تمام زمروں پر واپس',
    hadithsCount: '{count} احادیث',

    // Saved View
    savedTitle: 'محفوظ شدہ',
    savedHadithsHeading: 'محفوظ شدہ',
    tabAll: 'سب',
    tabFavorites: 'پسندیدہ',
    noSavedTitle: 'کوئی محفوظ شدہ حدیث نہیں ہے',
    noSavedPrompt: 'کوئی محفوظ شدہ حدیث نہیں ہے',
    noSavedDesc: 'کسی بھی حدیث کو محفوظ کرنے کے لیے بک مارک پر دبائیں تاکہ بعد میں پڑھ سکیں۔',
    noSavedSub: 'کسی بھی حدیث کو محفوظ کرنے کے لیے بک مارک پر دبائیں تاکہ بعد میں پڑھ سکیں۔',

    // Search View
    searchPlaceholder: 'کسی لفظ، موضوع، یا راوی کے نام سے تلاش کریں...',
    searchScopeAll: 'سب',
    searchScopeHadith: 'حدیث کا متن',
    searchScopeNarrator: 'راوی',
    searchScopeTopic: 'موضوع',
    recentSearches: 'حالیہ تلاش',
    noSearchResults: 'کوئی نتیجہ نہیں ملا',
    noSearchSub: 'دیگر الفاظ سے تلاش کریں یا فلٹر تبدیل کریں',
  },

  fa: {
    // Header & Brand
    appTitle: 'چرا فرمود؟',
    appSubtitle: 'هر حدیث داستانی است پیش از آنکه کلمه‌ای شود',
    charitableTag: 'وقف برای خدا و روح مطهر پیامبر اکرم ﷺ',
    charitableSub: 'کاری خالصانه برای رضای پروردگار',
    charitableNotice: 'برنامه «چرا فرمود؟» یک وقف فرهنگی و غیرانتفاعی است که با هدف نزدیک کردن دل‌ها به شأن ورود و داستان‌های احادیث نبوی همراه با فضایی صوتی و آرامش‌بخش طراحی شده است.',

    // Common Actions
    search: 'جستجو',
    settings: 'تنظیمات',
    stats: 'آمار من',
    about: 'درباره برنامه',
    close: 'بستن',
    saveAndClose: 'ذخیره و بستن',
    cancel: 'انصراف',
    dismiss: 'رد کردن',
    offline: 'آفلاین',
    share: 'اشتراک‌گذاری',
    bookmark: 'نشان کردن',
    bookmarked: 'نشان‌شده',
    copied: 'با موفقیت کپی شد',
    back: 'بازگشت',
    backBtn: 'بازگشت',
    prevBtn: 'قبلی',
    nextBtn: 'بعدی',

    // Language Selector
    language: 'زبان برنامه',
    chooseLanguage: 'انتخاب زبان برنامه',
    languageDescription: 'تغییر کامل زبان برنامه (احادیث، داستان‌ها و رابط کاربری)',

    // Navigation Tabs
    navHome: 'خانه',
    navSaved: 'نشان‌شده‌ها',
    navSearch: 'جستجو',
    navDaily: 'حدیث امروز',
    navCategories: 'دسته‌بندی‌ها',

    // Home Screen
    beforeReading: 'پیش از خواندن حدیث...',
    startTodayStory: 'آغاز داستان امروز',
    todayDatePrefix: 'حدیث امروز · ',
    streakTitle: 'زنجیره مطالعه:',
    streakDaysSingular: 'روز',
    streakDaysDual: 'دو روز',
    streakDaysPlural: 'روز متوالی',
    startStreakPrompt: 'زنجیره مطالعه روزانه خود را آغاز کنید 🔥',
    mashaAllah: 'ماشاءالله!',
    statsSummary: '{read} از {total} حدیث خوانده شد',
    statsBoard: 'تابلوی دستاوردها',
    charitableBannerTitle: 'کاری خالصانه برای رضای خداوند',
    charitableBannerSub: 'درباره برنامه، اهداف و التماس دعا ❤️',

    // Highlights
    highlightsAuthentic: '۲۰۰۰+ حدیث صحیح',
    highlightsScenes: '۵ صحنه تعاملی',
    highlightsCalmAudio: 'صداهای آرامش‌بخش',
    highlightsCards: 'کارت‌های اشتراک‌گذاری',

    // Periodic Athkar Reminder
    dhikrTitle: 'اذکار',
    dhikrBadge: 'یادآوری دوره‌ای',
    dhikrSub: 'یادآوری دوره‌ای ذکر خدا و صلوات بر پیامبر ﷺ',
    dhikrIntervalLabel: 'فاصله یادآوری (هر بار ذکری متفاوت):',
    every15m: 'هر ۱۵ دقیقه',
    every15mSub: 'ذکر متفاوت',
    every30m: 'هر ۳۰ دقیقه',
    every30mSub: 'نیم ساعت (پیش‌فرض)',
    every60m: 'هر ۶۰ دقیقه',
    every60mSub: 'هر ساعت',
    listenPodcastNow: '🔊 اکنون ذکر را بشنوید',
    stopPodcastNow: 'توقف صدا',
    listenDhikrNow: '🔊 اکنون ذکر را بشنوید',
    stopDhikrNow: 'توقف صدا',
    dhikrDisabledPrompt: 'یادآوری دوره‌ای در حال حاضر غیرفعال است. از بالا فعال کنید.',
    dhikrQualityBadge: 'تمام اذکار در برنامه قرار دارند و بدون اینترنت با صدایی رسا پخش می‌شوند.',
    dhikrNowNotice: 'یاد خدا',
    athkarClickListen: 'اذکار (برای شنیدن کلیک کنید):',

    // Download All Audio Pack
    downloadPackTitle: 'بسته صوتی احادیث، داستان‌ها و اذکار',
    downloadPackDesc: 'ذخیره کامل فایل‌های صوتی برای پخش ۱۰۰٪ آفلاین با تلاوتی آرام و دلنشین.',
    downloadPackBtn: '📥 ذخیره تمام صوت‌ها به صورت آفلاین',
    downloadingPackProgress: 'در حال ذخیره فایل‌های صوتی در حافظه برنامه ({progress}%)...',
    downloadPackSuccess: '✅ صوت‌ها با موفقیت ذخیره شدند (۱۰۰٪ آفلاین)',
    downloadPackVerify: '🔄 بازبینی و به‌روزرسانی صوت‌های آفلاین',
    packStatsInfo: 'تلاوت آرام و وقور احادیث، داستان‌ها و اذکار · ذخیره در برنامه بدون نیاز به اینترنت',

    // Font Size
    fontSizeTitle: 'اندازه قلم متن حدیث و داستان‌ها',
    fontSmall: 'کوچک',
    fontSmallDesc: 'برای صفحه‌های کوچک',
    fontMedium: 'متوسط',
    fontMediumDesc: 'راحت و متوازن',
    fontLarge: 'بزرگ',
    fontLargeDesc: 'بسیار واضح و خوانا',

    // Daily Notification
    dailyNotifTitle: 'اعلان حدیث امروز',
    dailyNotifSub: 'یادآوری روزانه برای تأمل در حدیث شریف نبوی',
    setAlertTime: 'زمان اعلان:',
    testNotifBtn: 'آزمایش اعلان اکنون',
    testNotifSent: 'اعلان آزمایشی با موفقیت ارسال شد!',
    dawnPreset: 'سحرگاه',
    morningPreset: 'صبح',
    afternoonPreset: 'عصر',
    eveningPreset: 'شامگاه',

    // Offline Audios
    offlineAudiosTitle: 'احادیث و داستان‌های ذخیره‌شده آفلاین',
    offlineAudiosDesc: 'می‌توانید هر حدیث یا داستانی را برای شنیدن آفلاین دانلود کنید.',
    clearOfflineAudiosBtn: 'پاک‌سازی فایل‌های صوتی برای آزادسازی حافظه',
    confirmClearOffline: 'آیا مایل به حذف تمام فایل‌های صوتی ذخیره‌شده هستید؟',

    // Story View
    storyTab: 'داستان و شأن ورود',
    hadithTab: 'متن حدیث شریف',
    playStory: 'شنیدن داستان',
    pauseStory: 'مکث',
    sceneLabel: 'صحنه',
    reflectionPrompt: 'لحظه‌ای تأمل:',
    hadithExcerpt: 'از رهنمود نبوی:',
    practicalLessons: 'درس‌های آموخته:',
    narratorLabel: 'راوی:',
    sourceLabel: 'منبع:',
    bookLabel: 'کتاب:',
    gradeLabel: 'درجه صحت حدیث:',
    sanadLabel: 'سند و زنجیره روایت:',
    readTodayHadithNow: 'اکنون حدیث امروز را بخوانید',
    shareHadith: 'اشتراک‌گذاری کارت حدیث',
    listenStory: 'شنیدن داستان',
    listenStoryAudio: 'شنیدن صوتی داستان',
    viewStory5Scenes: 'مشاهده داستان (۵ صحنه)',
    listenHadith: 'شنیدن حدیث',
    hadithDetailTitle: 'حدیث شریف',
    storyContextLabel: 'داستان تاریخی و شأن ورود',
    practicalBenefitLabel: 'فواید و درس‌های آموخته',
    explanationLabel: 'شرح حدیث نبوی',
    hadithNumber: 'شماره: ',
    hadithFullPage: 'صفحه حدیث و استناد',
    stopStory: 'توقف',
    fullStoryPlaying: 'شنیدن کامل داستان (۵ صحنه)',
    singleScenePlaying: 'شنیدن فقط این صحنه',
    stopScene: 'توقف صحنه',
    ambientSound: 'فضای صوتی صحنه:',

    // Daily Hadith View
    dailyHadithHeading: 'حدیث امروز',
    nextDay: 'روز بعد',
    prevDay: 'روز قبل',
    dailyParchmentTitle: 'متن حدیث امروز',

    // Categories View
    categoriesTitle: 'دسته‌بندی‌های احادیث',
    categoriesSub: 'مرور بیش از ۲۰۰۰ حدیث بر اساس موضوع',
    backToCategories: 'بازگشت به دسته‌بندی‌ها',
    hadithsCount: '{count} حدیث',

    // Saved View
    savedTitle: 'نشان‌شده‌ها',
    savedHadithsHeading: 'نشان‌شده‌ها',
    tabAll: 'همه',
    tabFavorites: 'محبوب‌ها',
    noSavedTitle: 'هیچ حدیثی ذخیره نشده است',
    noSavedPrompt: 'هیچ حدیثی ذخیره نشده است',
    noSavedDesc: 'روی نشانک هر حدیث کلیک کنید تا بعداً بتوانید آن را مطالعه کنید.',
    noSavedSub: 'روی نشانک هر حدیث کلیک کنید تا بعداً بتوانید آن را مطالعه کنید.',

    // Search View
    searchPlaceholder: 'جستجو بر اساس کلمه، موضوع یا نام راوی...',
    searchScopeAll: 'همه',
    searchScopeHadith: 'متن حدیث',
    searchScopeNarrator: 'راوی',
    searchScopeTopic: 'موضوع',
    recentSearches: 'جستجوهای اخیر',
    noSearchResults: 'نتیجه‌ای یافت نشد',
    noSearchSub: 'با کلمات دیگری جستجو کنید یا فیلتر را تغییر دهید',
  }
};

export type TranslationKey = keyof typeof translations.ar;
