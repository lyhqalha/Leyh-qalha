/**
 * Complete Multi-Language Hadith System
 * Supports Arabic (ar), English (en), Urdu (ur), and Persian (fa)
 * Fully translates hadith texts, narrators, sources, historical stories,
 * explanations, practical lessons, and all 5 story scenes.
 */

import { HadithItem, StoryScene } from '../types/hadith';
import { AppLanguage } from './translations';

export interface LocalizedCategory {
  id: string;
  name: string;
  iconName: string;
  count: number;
  description: string;
}

export const CATEGORIES_LOCALIZATION: Record<AppLanguage, LocalizedCategory[]> = {
  ar: [
    { id: 'morals', name: 'الأخلاق', iconName: 'MessageSquareHeart', count: 116, description: 'مكارم الأخلاق، الرحمة، الصدق، وحفظ اللسان' },
    { id: 'faith', name: 'الإيمان', iconName: 'ShieldCheck', count: 113, description: 'أصول العقيدة، توحيد الله، وأركان الإيمان الستة' },
    { id: 'people', name: 'التعامل مع الناس', iconName: 'UsersRound', count: 112, description: 'حسن الجوار، إكرام الضيف، ولين الجانب والتسامح' },
    { id: 'supplication', name: 'الدعاء', iconName: 'Hands', count: 112, description: 'مخ العبادة، سيد الاستغفار، وأوقات الإجابة' },
    { id: 'prayer', name: 'الصلاة', iconName: 'Compass', count: 111, description: 'عمود الدين، الخشوع، صلاة الجماعة وسنن الصلوات' },
    { id: 'repentance', name: 'التوبة', iconName: 'RotateCcw', count: 111, description: 'الاستغفار، الرجوع إلى الله، وسعة رحمة الغفور' },
    { id: 'quran', name: 'القرآن', iconName: 'BookOpen', count: 111, description: 'فضل التلاوة والتدبر، والماهر بالقرآن وشفاعته' },
    { id: 'work', name: 'المال والعمل', iconName: 'Coins', count: 111, description: 'أكل الحلال، أجر الأجير، والأمانة في التجارة' },
    { id: 'marriage', name: 'الزواج', iconName: 'Heart', count: 111, description: 'المودة والرحمة، وبناء البيت المسلم والعفة' },
    { id: 'manners', name: 'حسن الخلق', iconName: 'Smile', count: 111, description: 'طلاقة الوجه، التبسم صدقة، والحلم وكظم الغيظ' },
    { id: 'family', name: 'الأسرة والتربية', iconName: 'Users', count: 111, description: 'كلكم راع، خيركم لأهله، ورعاية الأبناء والنشء' },
    { id: 'shyness', name: 'الحياء', iconName: 'Sparkles', count: 110, description: 'الحياء لا يأتي إلا بخير، وزينة المؤمن الباطنة' },
    { id: 'patience', name: 'الصبر', iconName: 'Flame', count: 110, description: 'الصبر عند الصدمة الأولى، عجباً لأمر المؤمن واحتساب البلاء' },
    { id: 'parents', name: 'بر الوالدين', iconName: 'Award', count: 110, description: 'أمك ثم أمك ثم أبوك، ورضا الرب في رضا الوالدين' },
    { id: 'knowledge', name: 'العلم', iconName: 'GraduationCap', count: 110, description: 'فضل طلب العلم، والعلماء ورثة الأنبياء' },
    { id: 'ramadan', name: 'رمضان', iconName: 'Sparkle', count: 110, description: 'شهر الغفران، تصفيد الشياطين، وفضل ليلة القدر' },
    { id: 'hajj', name: 'الحج والعمرة', iconName: 'Navigation', count: 110, description: 'الحج المبرور ليس له جزاء إلا الجنة، ومناسك المشاعر' },
    { id: 'fasting', name: 'الصيام', iconName: 'Moon', count: 110, description: 'الصيام جنة، وباب الريان، وإني امرؤ صائم' }
  ],
  en: [
    { id: 'morals', name: 'Morals & Ethics', iconName: 'MessageSquareHeart', count: 116, description: 'Noble virtues, mercy, truthfulness, and guarding the tongue' },
    { id: 'faith', name: 'Faith (Iman)', iconName: 'ShieldCheck', count: 113, description: 'Foundations of creed, Islamic monotheism (Tawhid), and the 6 pillars' },
    { id: 'people', name: 'Dealing with People', iconName: 'UsersRound', count: 112, description: 'Treating neighbors well, honoring guests, gentle speech, and tolerance' },
    { id: 'supplication', name: 'Supplication (Dua)', iconName: 'Hands', count: 112, description: 'The core of worship, master of seeking forgiveness, and answered times' },
    { id: 'prayer', name: 'Prayer (Salah)', iconName: 'Compass', count: 111, description: 'Pillar of religion, humility, congregational prayer, and Sunnahs' },
    { id: 'repentance', name: 'Repentance (Tawbah)', iconName: 'RotateCcw', count: 111, description: 'Seeking forgiveness, returning to Allah, and His vast mercy' },
    { id: 'quran', name: 'The Holy Quran', iconName: 'BookOpen', count: 111, description: 'Virtues of recitation and contemplation, intercession of the Quran' },
    { id: 'work', name: 'Work & Wealth', iconName: 'Coins', count: 111, description: 'Earning Halal sustenance, fair worker wages, and honesty in trade' },
    { id: 'marriage', name: 'Marriage', iconName: 'Heart', count: 111, description: 'Affection, mercy, building a righteous household, and chastity' },
    { id: 'manners', name: 'Good Manners', iconName: 'Smile', count: 111, description: 'Cheerful demeanor, smiling as charity, forbearance, and restraining anger' },
    { id: 'family', name: 'Family & Upbringing', iconName: 'Users', count: 111, description: 'Being guardians of families, caring for parents, children, and youth' },
    { id: 'shyness', name: 'Modesty (Haya)', iconName: 'Sparkles', count: 110, description: 'Modesty brings only good, and is an inner adornment of the believer' },
    { id: 'patience', name: 'Patience (Sabr)', iconName: 'Flame', count: 110, description: 'Patience at the first strike of calamity, and seeking reward from Allah' },
    { id: 'parents', name: 'Honoring Parents', iconName: 'Award', count: 110, description: 'Your mother then your father, and Allah pleasure in their pleasure' },
    { id: 'knowledge', name: 'Sacred Knowledge', iconName: 'GraduationCap', count: 110, description: 'Virtues of seeking knowledge; scholars are the heirs of prophets' },
    { id: 'ramadan', name: 'Ramadan', iconName: 'Sparkle', count: 110, description: 'Month of forgiveness, chaining of devils, and the Night of Decree' },
    { id: 'hajj', name: 'Hajj & Umrah', iconName: 'Navigation', count: 110, description: 'An accepted Hajj has no reward but Paradise, sacred rites of Makkah' },
    { id: 'fasting', name: 'Fasting (Sawm)', iconName: 'Moon', count: 110, description: 'Fasting is a shield, the gate of Ar-Rayyan, and spiritual restraint' }
  ],
  ur: [
    { id: 'morals', name: 'اخلاق و آداب', iconName: 'MessageSquareHeart', count: 116, description: 'اعلیٰ اخلاق، رحمت، سچائی اور زبان کی حفاظت' },
    { id: 'faith', name: 'ایمان اور عقیدہ', iconName: 'ShieldCheck', count: 113, description: 'توحید باری تعالیٰ، عقیدہ کی بنیادیں اور ارکان ایمان' },
    { id: 'people', name: 'معاملات و معاشرت', iconName: 'UsersRound', count: 112, description: 'ہمسایوں کے حقوق، مہمان نوازی اور حسن سلوک' },
    { id: 'supplication', name: 'دعا اور مناجات', iconName: 'Hands', count: 112, description: 'عبادت کا مغز، سید الاستغفار اور قبولیت کی گھڑیاں' },
    { id: 'prayer', name: 'نماز', iconName: 'Compass', count: 111, description: 'دین کا ستون، خشوع و خضوع، باجماعت نماز اور مسنون دعائیں' },
    { id: 'repentance', name: 'توبہ و استغفار', iconName: 'RotateCcw', count: 111, description: 'گناہوں سے توبہ، اللہ کی طرف رجوع اور رحمت کی وسعت' },
    { id: 'quran', name: 'قرآن کریم', iconName: 'BookOpen', count: 111, description: 'تلاوت و تدبر کی فضیلت، قرآن کا شفاعت کرنا' },
    { id: 'work', name: 'مال اور حلال روزگار', iconName: 'Coins', count: 111, description: 'رزق حلال، مزدور کی اجرت اور تجارت میں امانت داری' },
    { id: 'marriage', name: 'نکاح و رفاقت', iconName: 'Heart', count: 111, description: 'محبت و رحمت، پاکیزہ گھریلو زندگی اور عفت' },
    { id: 'manners', name: 'حسن اخلاق', iconName: 'Smile', count: 111, description: 'خندہ پیشانی، مسکراہٹ صدقہ ہے، اور غصہ پر قابو' },
    { id: 'family', name: 'خاندان اور تربیت', iconName: 'Users', count: 111, description: 'اہل و عیال کی دیکھ بھال اور اولاد کی نیک تربیت' },
    { id: 'shyness', name: 'شرم و حیا', iconName: 'Sparkles', count: 110, description: 'حیا سے ہمیشہ خیر ہی جنم لیتی ہے، مومن کا زیور' },
    { id: 'patience', name: 'صبر و استقامت', iconName: 'Flame', count: 110, description: 'پہلے صدمے پر صبر، آزمائشوں پر اجر و ثواب کی امید' },
    { id: 'parents', name: 'والدین کی اطاعت', iconName: 'Award', count: 110, description: 'ماں اور باپ کا اکرام، رب کی رضا والدین کی رضا میں ہے' },
    { id: 'knowledge', name: 'علم و آگہی', iconName: 'GraduationCap', count: 110, description: 'طلب علم کی فضیلت، علماء انبیاء کے وارث ہیں' },
    { id: 'ramadan', name: 'رمضان المبارک', iconName: 'Sparkle', count: 110, description: 'مغفرت کا مہینہ، شیاطین کا قید ہونا اور شب قدر کی برکات' },
    { id: 'hajj', name: 'حج اور عمرہ', iconName: 'Navigation', count: 110, description: 'حج مبرور کا بدلہ جنت کے سوا کچھ نہیں' },
    { id: 'fasting', name: 'روزہ', iconName: 'Moon', count: 110, description: 'روزہ ڈھال ہے، باب الریان اور نفس پر قابو' }
  ],
  fa: [
    { id: 'morals', name: 'اخلاق و سیرت', iconName: 'MessageSquareHeart', count: 116, description: 'مکارم اخلاق، مهربانی، صداقت و حفظ زبان' },
    { id: 'faith', name: 'ایمان و عقیده', iconName: 'ShieldCheck', count: 113, description: 'اصول عقاید، توحید الهی و ارکان شش‌گانه ایمان' },
    { id: 'people', name: 'رفتار با مردم', iconName: 'UsersRound', count: 112, description: 'حقوق همسایه، اکرام میهمان، مدارا و بردباری' },
    { id: 'supplication', name: 'دعا و نیایش', iconName: 'Hands', count: 112, description: 'مغز عبادت، سید الاستغفار و اوقات اجابت دعا' },
    { id: 'prayer', name: 'نماز', iconName: 'Compass', count: 111, description: 'ستون دین، خشوع، نماز جماعت و سنت‌های نبوی' },
    { id: 'repentance', name: 'توبه و بازگشت', iconName: 'RotateCcw', count: 111, description: 'آمرزش‌خواهی، بازگشت به سوی خدا و وسعت رحمت الهی' },
    { id: 'quran', name: 'قرآن کریم', iconName: 'BookOpen', count: 111, description: 'فضیلت تلاوت و تدبر، و شفاعت قرآن کریم' },
    { id: 'work', name: 'مال و روزی حلال', iconName: 'Coins', count: 111, description: 'روزی حلال، حقوق کارگر و امانت‌داری در تجارت' },
    { id: 'marriage', name: 'ازدواج و خانواده', iconName: 'Heart', count: 111, description: 'مودت و رحمت، بنای خانه مسلمان و پاکدامنی' },
    { id: 'manners', name: 'حسن خلق', iconName: 'Smile', count: 111, description: 'گشاده‌رویی، تبسم به عنوان صدقه، و مهار خشم' },
    { id: 'family', name: 'خانواده و تربیت', iconName: 'Users', count: 111, description: 'مسئولیت سرپرستی، نیکی به فرزندان و تربیت صالح' },
    { id: 'shyness', name: 'حیا و پاکدامنی', iconName: 'Sparkles', count: 110, description: 'حیا جز نیکی نمی‌آورد و زینت درونی مومن است' },
    { id: 'patience', name: 'صبر و شکیبایی', iconName: 'Flame', count: 110, description: 'صبر در نخستین ضربه مصیبت و شگفتی امر مؤمن' },
    { id: 'parents', name: 'نیکی به والدین', iconName: 'Award', count: 110, description: 'مقام والای مادر و پدر، و رضایت خدا در رضایت آنان' },
    { id: 'knowledge', name: 'علم و دانش', iconName: 'GraduationCap', count: 110, description: 'فضیلت طلب دانش؛ علما وارثان پیامبرانند' },
    { id: 'ramadan', name: 'ماه رمضان', iconName: 'Sparkle', count: 110, description: 'ماه مغفرت، بسته شدن شیاطین و فضیلت شب قدر' },
    { id: 'hajj', name: 'حج و عمره', iconName: 'Navigation', count: 110, description: 'حج مقبول پاداشی جز بهشت ندارد و مناسک شریف' },
    { id: 'fasting', name: 'روزه', iconName: 'Moon', count: 110, description: 'روزه سپری در برابر آتش است، و درگاه ریان' }
  ]
};

// Map of canonical narrators
const NARRATORS_MAP: Record<string, Record<AppLanguage, string>> = {
  'أبو هريرة رضي الله عنه': {
    ar: 'أبو هريرة رضي الله عنه',
    en: 'Abu Hurairah (may Allah be pleased with him)',
    ur: 'حضرت ابوہریرہ رضی اللہ عنہ',
    fa: 'ابوهریره رضی الله عنه'
  },
  'عمر بن الخطاب رضي الله عنه': {
    ar: 'عمر بن الخطاب رضي الله عنه',
    en: 'Umar ibn al-Khattab (may Allah be pleased with him)',
    ur: 'حضرت عمر بن خطاب رضی اللہ عنہ',
    fa: 'عمر بن خطاب رضی الله عنه'
  },
  'عائشة رضي الله عنها': {
    ar: 'عائشة رضي الله عنها',
    en: 'Aisha (may Allah be pleased with her)',
    ur: 'ام المومنین حضرت عائشہ رضی اللہ عنہا',
    fa: 'عایشه رضی الله عنها'
  },
  'عبد الله بن مسعود رضي الله عنه': {
    ar: 'عبد الله بن مسعود رضي الله عنه',
    en: 'Abdullah ibn Masud (may Allah be pleased with him)',
    ur: 'حضرت عبداللہ بن مسعود رضی اللہ عنہ',
    fa: 'عبدالله بن مسعود رضی الله عنه'
  },
  'أنس بن مالك رضي الله عنه': {
    ar: 'أنس بن مالك رضي الله عنه',
    en: 'Anas ibn Malik (may Allah be pleased with him)',
    ur: 'حضرت انس بن مالک رضی اللہ عنہ',
    fa: 'انس بن مالک رضی الله عنه'
  },
  'عبد الله بن عمر رضي الله عنهما': {
    ar: 'عبد الله بن عمر رضي الله عنهما',
    en: 'Abdullah ibn Umar (may Allah be pleased with them both)',
    ur: 'حضرت عبداللہ بن عمر رضی اللہ عنہما',
    fa: 'عبدالله بن عمر رضی الله عنهما'
  },
  'عبد الله بن عباس رضي الله عنهما': {
    ar: 'عبد الله بن عباس رضي الله عنهما',
    en: 'Abdullah ibn Abbas (may Allah be pleased with them both)',
    ur: 'حضرت عبداللہ بن عباس رضی اللہ عنہما',
    fa: 'عبدالله بن عباس رضی الله عنهما'
  },
  'أبو سعيد الخدري رضي الله عنه': {
    ar: 'أبو سعيد الخدري رضي الله عنه',
    en: "Abu Sa'eed al-Khudri (may Allah be pleased with him)",
    ur: 'حضرت ابوسعید خدری رضی اللہ عنہ',
    fa: 'ابوسعید خدری رضی الله عنه'
  },
  'أبو ذر الغفاري رضي الله عنه': {
    ar: 'أبو ذر الغفاري رضي الله عنه',
    en: 'Abu Dharr al-Ghifari (may Allah be pleased with him)',
    ur: 'حضرت ابوذر غفاری رضی اللہ عنہ',
    fa: 'ابوذر غفاری رضی الله عنه'
  },
  'جابر بن عبد الله رضي الله عنه': {
    ar: 'جابر بن عبد الله رضي الله عنه',
    en: 'Jabir ibn Abdullah (may Allah be pleased with him)',
    ur: 'حضرت جابر بن عبداللہ رضی اللہ عنہ',
    fa: 'جابر بن عبدالله رضی الله عنه'
  },
  'معاذ بن جبل رضي الله عنه': {
    ar: 'معاذ بن جبل رضي الله عنه',
    en: "Mu'adh ibn Jabal (may Allah be pleased with him)",
    ur: 'حضرت معاذ بن جبل رضی اللہ عنہ',
    fa: 'معاذ بن جبل رضی الله عنه'
  },
  'علي بن أبي طالب رضي الله عنه': {
    ar: 'علي بن أبي طالب رضي الله عنه',
    en: 'Ali ibn Abi Talib (may Allah be pleased with him)',
    ur: 'حضرت علی بن ابی طالب رضی اللہ عنہ',
    fa: 'علی بن ابی‌طالب رضی الله عنه'
  },
  'عثمان بن عفان رضي الله عنه': {
    ar: 'عثمان بن عفان رضي الله عنه',
    en: 'Uthman ibn Affan (may Allah be pleased with him)',
    ur: 'حضرت عثمان بن عفان رضی اللہ عنہ',
    fa: 'عثمان بن عفان رضی الله عنه'
  }
};

// Map of canonical Hadith books
const BOOKS_MAP: Record<string, Record<AppLanguage, string>> = {
  'صحيح البخاري': {
    ar: 'صحيح البخاري',
    en: 'Sahih al-Bukhari',
    ur: 'صحیح بخاری',
    fa: 'صحیح بخاری'
  },
  'صحيح مسلم': {
    ar: 'صحيح مسلم',
    en: 'Sahih Muslim',
    ur: 'صحیح مسلم',
    fa: 'صحیح مسلم'
  },
  'صحيح البخاري ومسلم': {
    ar: 'صحيح البخاري ومسلم',
    en: 'Sahih al-Bukhari & Muslim',
    ur: 'صحیح بخاری و مسلم',
    fa: 'صحیح بخاری و مسلم'
  },
  'سنن أبي داود': {
    ar: 'سنن أبي داود',
    en: 'Sunan Abi Dawud',
    ur: 'سنن ابو داؤد',
    fa: 'سنن ابوداود'
  },
  'جامع الترمذي': {
    ar: 'جامع الترمذي',
    en: 'Jami` at-Tirmidhi',
    ur: 'جامع ترمذی',
    fa: 'جامع ترمذی'
  },
  'سنن النسائي': {
    ar: 'سنن النسائي',
    en: "Sunan an-Nasa'i",
    ur: 'سنن نسائی',
    fa: 'سنن نسائی'
  },
  'سنن ابن ماجه': {
    ar: 'سنن ابن ماجه',
    en: 'Sunan Ibn Majah',
    ur: 'سنن ابن ماجہ',
    fa: 'سنن ابن ماجه'
  },
  'مسند أحمد': {
    ar: 'مسند أحمد',
    en: 'Musnad Ahmad',
    ur: 'مسند احمد',
    fa: 'مسند احمد'
  },
  'كتاب الأدب': {
    ar: 'كتاب الأدب',
    en: 'Book of Good Manners',
    ur: 'کتاب الادب',
    fa: 'کتاب ادب'
  },
  'كتاب الإيمان': {
    ar: 'كتاب الإيمان',
    en: 'Book of Faith',
    ur: 'کتاب الایمان',
    fa: 'کتاب ایمان'
  },
  'كتاب الصلاة': {
    ar: 'كتاب الصلاة',
    en: 'Book of Prayer',
    ur: 'کتاب الصلاۃ',
    fa: 'کتاب نماز'
  },
  'كتاب الصيام': {
    ar: 'كتاب الصيام',
    en: 'Book of Fasting',
    ur: 'کتاب الصوم',
    fa: 'کتاب روزه'
  }
};

const GRADES_MAP: Record<string, Record<AppLanguage, string>> = {
  'متفق عليه': {
    ar: 'متفق عليه',
    en: 'Agreed Upon (Muttafaq Alayh)',
    ur: 'متفق علیہ',
    fa: 'متفق علیه'
  },
  'صحيح': {
    ar: 'صحيح',
    en: 'Sahih (Authentic)',
    ur: 'صحیح',
    fa: 'صحیح'
  },
  'حسن': {
    ar: 'حسن',
    en: 'Hasan (Good)',
    ur: 'حسن',
    fa: 'حسن'
  }
};

// Scene templates for 5 story scenes across languages
export const SCENE_TEMPLATES: Record<
  AppLanguage,
  {
    badge: string;
    title: string;
    subtitle: string;
    reflectionPrompt: string;
  }[]
> = {
  ar: [
    { badge: 'المشهد الأول', title: 'ماذا حدث؟', subtitle: 'الموقف وسياق الورود', reflectionPrompt: '' },
    { badge: 'المشهد الثاني', title: 'فكر لحظة: ما الميزان؟', subtitle: 'تأمل وحيرة', reflectionPrompt: 'تأمل في الحكمة النبوية قبل الانتقال إلى نص الحديث.' },
    { badge: 'المشهد الثالث', title: 'ماذا قال النبي ﷺ؟', subtitle: 'النداء النبوي الخالد', reflectionPrompt: '' },
    { badge: 'المشهد الرابع', title: 'سر الكلمة وبلاغة التوجيه', subtitle: 'الحكمة النبوية', reflectionPrompt: '' },
    { badge: 'المشهد الخامس', title: 'العبرة والعمل في حياتنا', subtitle: 'التطبيق المعاصر', reflectionPrompt: '' }
  ],
  en: [
    { badge: 'Scene 1', title: 'What Happened?', subtitle: 'The Historical Situation & Context', reflectionPrompt: '' },
    { badge: 'Scene 2', title: 'Pause & Reflect: What is the Standard?', subtitle: 'Contemplation & Inquiry', reflectionPrompt: 'Reflect deeply on the prophetic wisdom before moving to the text of the Hadith.' },
    { badge: 'Scene 3', title: 'What Did the Prophet ﷺ Say?', subtitle: 'The Timeless Prophetic Proclamation', reflectionPrompt: '' },
    { badge: 'Scene 4', title: 'The Secret of the Words', subtitle: 'Prophetic Wisdom & Eloquence', reflectionPrompt: '' },
    { badge: 'Scene 5', title: 'The Lesson & Practical Action', subtitle: 'Contemporary Life Application', reflectionPrompt: '' }
  ],
  ur: [
    { badge: 'پہلا منظر', title: 'کیا واقعہ پیش آیا؟', subtitle: 'پس منظر اور تاریخی موقع', reflectionPrompt: '' },
    { badge: 'دوسرا منظر', title: 'ایک لمحہ سوچیے: کیا میزان ہے؟', subtitle: 'غور و فکر اور سوال', reflectionPrompt: 'حدیث مبارکہ کے متن سے پہلے اس نبوی حکمت پر غور فرمائیں۔' },
    { badge: 'تیسرا منظر', title: 'نبی کریم ﷺ نے کیا فرمایا؟', subtitle: 'ابدی نبوی رہنمائی', reflectionPrompt: '' },
    { badge: 'چوتھا منظر', title: 'کلمات کی بلاغت اور راز', subtitle: 'حکمت نبوی کی گہرائی', reflectionPrompt: '' },
    { badge: 'پانچواں منظر', title: 'عبرت اور عملی زندگی میں نفاذ', subtitle: 'موجودہ دور میں اطلاق', reflectionPrompt: '' }
  ],
  fa: [
    { badge: 'صحنه اول', title: 'چه اتفاقی افتاد؟', subtitle: 'موقعیت و شأن ورود تاریخی', reflectionPrompt: '' },
    { badge: 'صحنه دوم', title: 'لحظه‌ای بیندیشید: میزان چیست؟', subtitle: 'تأمل و پرسش', reflectionPrompt: 'پیش از خواندن متن حدیث، در حکمت ژرف نبوی تأمل فرمایید.' },
    { badge: 'صحنه سوم', title: 'پیامبر اکرم ﷺ چه فرمودند؟', subtitle: 'پیام جاویدان نبوی', reflectionPrompt: '' },
    { badge: 'صحنه چهارم', title: 'راز کلمات و بلاغت رهنمود', subtitle: 'حکمت و زیبایی بیان نبوی', reflectionPrompt: '' },
    { badge: 'صحنه پنجم', title: 'درس عبرت و کاربرد در زندگی', subtitle: 'کاربرد در زندگی امروز', reflectionPrompt: '' }
  ]
};

// Fully translated primary Hadiths (Hadith of the Day, Morals, Intentions, Faith, etc.)
interface FullHadithTranslation {
  hadith_text: string;
  topic: string;
  context: string;
  explanation: string;
  practical_lesson: string[];
  sceneContents: [string, string, string, string, string];
}

const PRIMARY_HADITHS_TRANSLATIONS: Record<string, Record<Exclude<AppLanguage, 'ar'>, FullHadithTranslation>> = {
  // 1. حديث اللسان والجوار والضيف (hadith-6018)
  'hadith-6018': {
    en: {
      hadith_text: 'Abu Hurairah (may Allah be pleased with him) reported that the Messenger of Allah ﷺ said: "Whoever believes in Allah and the Last Day should speak good or remain silent. Whoever believes in Allah and the Last Day should honor his neighbor. And whoever believes in Allah and the Last Day should honor his guest."',
      topic: 'Morals & Ethics',
      context: 'In the nascent society of Madinah, Companions lived closely with regular gatherings, trade, and visiting neighbors. The Prophet ﷺ set a definitive moral standard linking faith directly with guarding speech, honoring neighbors, and hospitality.',
      explanation: 'This noble Hadith emphasizes that faith is not merely an inner feeling, but manifests in three essential ethical actions: speaking only righteousness, treating neighbors with genuine respect, and warmly honoring guests as pillars of community harmony.',
      practical_lesson: [
        'Always ensure your words are beneficial, kind, and peaceful; otherwise, silence is wisdom and safety.',
        'Guard the rights of neighbors, protect their privacy, and never cause them harm.',
        'Welcome guests with warmth, generosity, and cheerful hospitality.',
        'Understand that every word spoken is recorded and accountable on the Day of Judgment.'
      ],
      sceneContents: [
        'In Madinah, people gathered daily in homes and markets. Casual speech often tested interpersonal bonds, requiring a clear, decisive divine standard.',
        'How can a cohesive society thrive without wounds from the tongue? How is sincere belief in Allah linked to what you say? Pause and reflect on this profound balance.',
        'The Prophet ﷺ stood to proclaim a timeless pillar of human conduct: "Whoever believes in Allah and the Last Day should speak good or remain silent..."',
        'The Prophet ﷺ did not simply say "be silent always"—he prioritized "speak good." Only when goodness is absent does silence become sanctuary.',
        'Before you speak in a gathering or post a comment on social media, remember: is it good that pleases Allah? If so, speak; otherwise, silence is noble wisdom.'
      ]
    },
    ur: {
      hadith_text: 'حضرت ابوہریرہ رضی اللہ عنہ سے روایت ہے کہ رسول اللہ ﷺ نے فرمایا: "جو شخص اللہ اور آخرت کے دن پر ایمان رکھتا ہے، وہ اچھی بات کہے ورنہ خاموش رہے؛ اور جو شخص اللہ اور آخرت پر ایمان رکھتا ہے وہ اپنے پڑوسی کی عزت کرے؛ اور جو شخص اللہ اور آخرت پر ایمان رکھتا ہے وہ اپنے مہمان کی تکریم کرے۔"',
      topic: 'اخلاق و آداب',
      context: 'مدینہ منورہ کے نوخیز معاشرے میں لوگ کثرت سے ملتے جلتے تھے۔ نبی اکرم ﷺ نے معاشرتی زندگی کی بنیاد زبان کی حفاظت، پڑوسیوں کے حقوق اور مہمان نوازی پر استوار فرمائی۔',
      explanation: 'یہ حدیث مبارکہ واضح کرتی ہے کہ اللہ اور یوم آخرت پر سچا ایمان محض دعویٰ نہیں بلکہ کردار سے ظاہر ہوتا ہے: بھلائی کی بات کرنا، پڑوسی کو تکلیف نہ دینا اور مہمان کی دلجوئی کرنا ایمان کی علامات ہیں۔',
      practical_lesson: [
        'ہمیشہ خیر اور بھلائی کی بات کریں، بے ہودہ گفتگو سے پرہیز کریں اور فتنوں کے وقت خاموشی اختیار کریں۔',
        'پڑوسی کے حقوق کا خیال رکھیں، ان کی عزت کی حفاظت کریں اور کسی قسم کی اذیت نہ دیں۔',
        'مہمان کی خوش دلی اور کشادہ پیشانی کے ساتھ تکریم کریں۔',
        'یاد رکھیں کہ ہر بولا گیا لفظ نامہ اعمال میں درج ہو رہا ہے۔'
      ],
      sceneContents: [
        'مدینہ منورہ کی فضا میں مہاجرین و انصار کے باہمی معاملات اور مجالس عام تھیں۔ روزمرہ کی گفتگو میں بعض اوقات غلط فہمیاں پیدا ہو سکتی تھیں۔',
        'اسلام ایک پرامن اور باوقار معاشرہ کیسے تشکیل دیتا ہے؟ زبان کے بول اور دل کے ایمان کا کیا تعلق ہے؟ ایک لمحہ اس نبوی میزان پر سوچیے۔',
        'رسول اللہ ﷺ نے انسانی سلوک کا سنہری اصول بیان فرمایا: "جو شخص اللہ اور آخرت کے دن پر ایمان رکھتا ہے، وہ اچھی بات کہے یا خاموش رہے..."',
        'آپ ﷺ نے یہ نہیں فرمایا کہ ہمیشہ چپ رہو، بلکہ پہلی ترجیح نیکی کی بات کہنے کو دی، ورنہ خاموشی کو سلامتی قرار دیا۔',
        'کوئی بھی بات بولنے یا سوشل میڈیا پر لکھنے سے پہلے سوچیں: کیا یہ بات اللہ کو راضی کرے گی؟ اگر ہاں تو بولیں، ورنہ خاموشی ہی حکمت ہے۔'
      ]
    },
    fa: {
      hadith_text: 'از ابوهریره رضی الله عنه روایت است که رسول خدا ﷺ فرمودند: «هر کس به خدا و روز قیامت ایمان دارد، باید سخن نیک بگوید یا خاموش بماند؛ و هر کس به خدا و روز قیامت ایمان دارد، باید همسایه خود را گرامی دارد؛ و هر کس به خدا و روز قیامت ایمان دارد، باید مهمان خود را اکرام نماید.»',
      topic: 'اخلاق و سیرت',
      context: 'در مدینه منوره، جامعه‌ای نوپا بر پایه ایمان شکل می‌گرفت. پیامبر اکرم ﷺ برای صیانت از زبان و استحکام پیوندهای اجتماعی، میزان دقیقی بیان فرمودند.',
      explanation: 'این حدیث شریف نشان می‌دهد که ایمان راستین به خدا و روز رستاخیز، در سه رفتار برجسته متجلی می‌شود: سخن نیکو گفتن، رعایت حقوق همسایگان و گشاده‌رویی در پذیرایی از مهمانان.',
      practical_lesson: [
        'همواره به سخن نیکو و خیر زبان بگشایید و از سخنان بیهوده دوری گزینید.',
        'حقوق همسایگان را پاس بدارید و از هرگونه آزار کلامی یا عملی بپرهیزید.',
        'مهمانان را با گشاده‌رویی و احسان اکرام نمایید.',
        'بدانید هر واژه‌ای که بر زبان جاری می‌شود در نامه اعمال ثبت خواهد شد.'
      ],
      sceneContents: [
        'در کوچه‌ها و بازارهای مدینه، دل‌های مؤمنان به هم پیوند خورده بود؛ اما سخنان نسنجیده می‌توانست سبب رنجش شود و نیازمند راهنمایی الهی بود.',
        'چگونه می‌توان جامعه‌ای ساخت که هیچ کلمه‌ای دلی را نشکند؟ لحظه‌ای بیندیشید که پیوند زبان و ایمان در چیست؟',
        'پیامبر اکرم ﷺ یکی از والاترین اصول رفتار انسانی را اعلام فرمودند: «هر کس به خدا و روز قیامت ایمان دارد، سخن نیک بگوید یا خاموش بماند...»',
        'پیامبر نفرمودند همواره سکوت کنید، بلکه نخستین انتخاب را گفتار نیک قرار دادند؛ و چون خیری نباشد، خاموشی سرچشمه سلامت است.',
        'پیش از آنکه کلمه‌ای بر زبان بیاورید یا مطلبی بنویسید، بیندیشید: آیا این کلمه رضایت پروردگار را در پی دارد؟ اگر نه، سکوت اوج خرد است.'
      ]
    }
  },

  // 2. حديث إنما الأعمال بالنيات (hadith-1)
  'hadith-1': {
    en: {
      hadith_text: 'Umar ibn al-Khattab (may Allah be pleased with him) narrated: I heard the Messenger of Allah ﷺ say: "Actions are but by intentions, and every person will only have what they intended. So whoever migrated for Allah and His Messenger, their migration was for Allah and His Messenger; and whoever migrated for worldly gain or to marry a woman, their migration was for what they migrated for."',
      topic: 'Faith (Iman)',
      context: 'During the great migration (Hijrah) from Makkah to Madinah, believers sacrificed everything for faith. A man was said to have migrated specifically to marry a woman known as Umm Qays. The Prophet ﷺ clarified the foundational rule of sincerity in all deeds.',
      explanation: 'This Hadith is widely regarded by scholars as one-third of Islam. It establishes that all deeds—worship, charity, labor, and intentions—are weighed solely by the purity of devotion to Allah Almighty.',
      practical_lesson: [
        'Purify intentions before undertaking any deed, whether prayer, study, or daily work.',
        'Know that outward appearances mean nothing without an honest, sincere heart.',
        'Transform regular daily habits into rewarding worship by intending the pleasure of Allah.'
      ],
      sceneContents: [
        'Believers journeyed across burning desert sands to Madinah. Their steps seemed similar outwardly, but what was in their hearts differed.',
        'Can two people do the exact same physical action yet one attains highest Paradise while the other gains nothing? Pause and contemplate the secret of the heart.',
        'The Prophet ﷺ climbed the pulpit and proclaimed the golden principle: "Actions are judged only by intentions, and each soul shall have what it intended..."',
        'Intention is the spiritual engine of every action; without sincerity, the most arduous journey remains merely a physical movement.',
        'Renew your intention before every word and deed: Do I do this for Allah, or for praise, pride, or worldly gain?'
      ]
    },
    ur: {
      hadith_text: 'حضرت عمر بن خطاب رضی اللہ عنہ سے روایت ہے کہ میں نے رسول اللہ ﷺ کو فرماتے ہوئے سنا: "اعمال کا دارومدار نیتوں پر ہے اور ہر انسان کے لیے وہی ہے جس کی اس نے نیت کی۔ پس جس کی ہجرت اللہ اور اس کے رسول کے لیے ہو، اس کی ہجرت اللہ اور اس کے رسول ہی کے لیے ہے؛ اور جس کی ہجرت دنیا کے حصول یا کسی عورت سے نکاح کے لیے ہو، تو اس کی ہجرت اسی کے لیے ہے جس کی خاطر اس نے ہجرت کی۔"',
      topic: 'ایمان اور عقیدہ',
      context: 'مکہ سے مدینہ ہجرت کے عظیم سفر میں مسلمانوں نے اللہ کی خاطر گھر بار چھوڑا۔ ایک شخص نے ام قیس نامی خاتون سے نکاح کی غرض سے ہجرت کی، تو آپ ﷺ نے خلوص نیت کا ابدی قانون بیان فرمایا۔',
      explanation: 'یہ حدیث مبارکہ دین اسلام کا ایک تہائی کہلاتی ہے۔ یہ اصول سکھاتی ہے کہ ہر نیکی، نماز اور قربانی کی قیمت اور وزن صرف اور صرف دل کے خلوص اور اللہ کی رضا پر منحصر ہے۔',
      practical_lesson: [
        'ہر عمل اور کام سے پہلے اپنی نیت کو خالصتاً اللہ کے لیے درست کریں۔',
        'ظاہری نمائش سے بچیں اور دل کے اخلاص پر توجہ دیں۔',
        'روزمرہ کے معمولات کو بھی نیک نیت کے ذریعے عبادت میں تبدیل کریں۔'
      ],
      sceneContents: [
        'مسلمانوں کا قافلہ صحرا کے کٹھن راستوں سے مدینہ پہنچا۔ سب کا ظاہری سفر ایک جیسا تھا، لیکن نیتیں جداگانہ تھیں۔',
        'کیا دو انسان ایک جیسا عمل کر کے بالکل مختلف انجام پا سکتے ہیں؟ ایک لمحہ سوچیے کہ دل کی نیت عمل کا رخ کیسے بدلتی ہے۔',
        'رسول اللہ ﷺ نے منبر پر تشریف فرما ہو کر اعلان فرمایا: "اعمال کا دارومدار صرف نیتوں پر ہے..."',
        'نیت روح ہے اور عمل جسم؛ بغیر اخلاص کے کتنا ہی بڑا کام کیوں نہ ہو، اللہ کے ہاں بے وزن رہ جاتا ہے۔',
        'ہر نماز، صدقہ اور اچھے کام سے پہلے دل سے پوچھیں: کیا میں یہ صرف اپنے رب کی رضا کے لیے کر رہا ہوں؟'
      ]
    },
    fa: {
      hadith_text: 'از عمر بن خطاب رضی الله عنه روایت است که شنیدم رسول خدا ﷺ فرمودند: «همانا اعمال به نیت‌ها بستگی دارد، و برای هر کس همان است که نیت کرده است. پس هر کس که هجرتش به سوی خدا و پیامبرش باشد، هجرت او برای خدا و پیامبرش است؛ و هر کس هجرتش برای دستیابی به دنیا یا ازدواج با زنی باشد، هجرتش برای همان چیزی است که به سوی آن هجرت نموده است.»',
      topic: 'ایمان و عقیده',
      context: 'در جریان هجرت به مدینه، یاران پیامبر تمام دارایی خود را رها کردند. مردی برای ازدواج با زنی به نام ام‌قیس هجرت کرد. پیامبر ﷺ اصل خلوص نیت را برای تمام اعصار تبیین نمودند.',
      explanation: 'بزرگان علم این حدیث را بنیاد یک‌سوم اسلام دانسته‌اند؛ زیرا نشان می‌دهد ارزش تمامی عبادات و رفتارها در درگاه خداوند، به پاکی و اخلاص دل وابسته است.',
      practical_lesson: [
        'پیش از هر کار، نیت خود را برای رضایت خداوند خالص گردانید.',
        'بدانید اعمال ظاهری بدون اخلاص قلبی هیچ ارزشی ندارند.',
        'کارهای روزمره را با نیت خیر به عبادت تبدیل کنید.'
      ],
      sceneContents: [
        'کاروان مؤمنان در بیابان‌های سوزان به سوی مدینه حرکت می‌کرد؛ گام‌ها مشابه بودند، اما انگیزه‌های درون تفاوت داشت.',
        'آیا ممکن است دو نفر یک کار را انجام دهند ولی پاداش یکی بهشت و دیگری هیچ باشد؟ در راز نیت بیندیشید.',
        'پیامبر اکرم ﷺ بر منبر برآمدند و قانون جاودان را آشکار کردند: «همانا ارزش اعمال تنها به نیت‌هاست...»',
        'نیت، جان عمل است؛ هجرتی که برای خدا نباشد، تنها رنج سفر در پی دارد.',
        'پیش از آغاز هر سخن و کار، از خود بپرسید: آیا این کار برای رضای خداست یا خودنمایی؟'
      ]
    }
  },

  // 3. حديث لا يؤمن أحدكم حتى يحب لأخيه (hadith-15)
  'hadith-15': {
    en: {
      hadith_text: 'Anas ibn Malik (may Allah be pleased with him) reported that the Prophet ﷺ said: "None of you truly believes until he loves for his brother what he loves for himself."',
      topic: 'Dealing with People',
      context: 'In Madinah, the Prophet ﷺ established deep brotherhood between the Muhajirun and Ansar. To solidify this united community, he taught that true faith requires wishing the best for one fellow believers just as one desires for oneself.',
      explanation: 'True faith purges the heart of envy, malice, and selfishness. The believer experiences joy when others receive blessings and seeks to protect others from harm just as they would protect themselves.',
      practical_lesson: [
        'Celebrate the success, happiness, and blessings bestowed upon others without envy.',
        'Treat others with the fairness, patience, and kindness you wish to receive.',
        'Actively strive to remove harm from the path of your community.'
      ],
      sceneContents: [
        'In Madinah, strangers became brothers sharing homes, food, and lives. The Ansar welcomed the Muhajirun with legendary generosity.',
        'Can faith be complete while harboring jealousy or resentment toward others? Pause and consider the purity of love in faith.',
        'The Prophet ﷺ revealed the spiritual milestone: "None of you truly believes until he loves for his brother what he loves for himself."',
        'Love for others is not a mere recommendation; it is an intrinsic pillar of full and sincere faith.',
        'Ask yourself today: Do I truly wish ease, honor, and guidance for my brother as I wish for myself?'
      ]
    },
    ur: {
      hadith_text: 'حضرت انس بن مالک رضی اللہ عنہ سے روایت ہے کہ نبی کریم ﷺ نے فرمایا: "تم میں سے کوئی شخص اس وقت تک کامل مومن نہیں ہو سکتا جب تک کہ وہ اپنے بھائی کے لیے بھی وہی پسند نہ کرے جو اپنے لیے پسند کرتا ہے۔"',
      topic: 'معاملات و معاشرت',
      context: 'مدینہ منورہ میں انصار و مہاجرین کے درمیان مواخات قائم ہوئی۔ آپ ﷺ نے امت کو سکھایا کہ ایمان کا کمال خود غرضی کو مٹانے اور دوسروں کے لیے خیر چاہنے میں ہے۔',
      explanation: 'یہ حدیث دل کو حسد، کینہ اور بغض سے پاک کرنے کا نسخہ کیمیا ہے۔ کامل ایمان وہ ہے جو انسان کو اس قابل بنائے کہ وہ اپنے مسلمان بھائی کی کامیابی اور بھلائی پر سچے دل سے خوش ہو۔',
      practical_lesson: [
        'دوسروں کو ملنے والی نعمتوں پر حسد کرنے کے بجائے خوش ہوں اور ان کے لیے برکت کی دعا کریں۔',
        'لوگوں کے ساتھ وہی نرمی اور انصاف کا معاملہ کریں جس کی آپ خود توقع رکھتے ہیں۔',
        'دوسروں کے دکھ درد کو اپنا درد سمجھیں اور ان کی مدد کریں۔'
      ],
      sceneContents: [
        'مدینہ منورہ میں انصار نے مہاجرین کو اپنے گھروں اور دلوں میں بسایا، تاریخ نے ایسی بے مثال محبت کبھی نہ دیکھی تھی۔',
        'کیا دل میں بغض اور حسد رکھتے ہوئے ایمان مکمل ہو سکتا ہے؟ ایک لمحہ سوچیے کہ سچی محبت ایمان کا معیار کیسے بنتی ہے۔',
        'رسول اللہ ﷺ نے ایمان کا اعلیٰ ترین پیمانہ بیان فرمایا: "تم میں سے کوئی مومن نہیں ہو سکتا جب تک اپنے بھائی کے لیے وہی نہ چاہے جو اپنے لیے چاہتا ہے..."',
        'یہ محض اخلاقی نصیحت نہیں بلکہ کامل ایمانداری کی کسوٹی ہے۔',
        'آج اپنے دل سے پوچھیں: کیا میں اپنے بھائی کے لیے بھی وہی عزت اور خیر چاہتا ہوں جو اپنے لیے چاہتا ہوں؟'
      ]
    },
    fa: {
      hadith_text: 'از انس بن مالک رضی الله عنه روایت است که پیامبر ﷺ فرمودند: «هیچ یک از شما حقیقتاً مؤمن نمی‌شود مگر آنکه آنچه را برای خود دوست می‌دارد، برای برادرش نیز دوست بدارد.»',
      topic: 'رفتار با مردم',
      context: 'در مدینه، پیوند برادری میان مهاجران و انصار شکل گرفت. پیامبر ﷺ تعلیم دادند که ایمان کامل، دل را از خودخواهی می‌پالاید.',
      explanation: 'این حدیث قلب انسان را از حسادت و کینه‌توزی پاک می‌کند و نشان می‌دهد ایمان راستین یعنی آرزوی خیر و نیکی برای دیگران، درست همان‌گونه که برای خود می‌خواهیم.',
      practical_lesson: [
        'از موفقیت و نعمت دیگران شادمان شوید و حسادت را از دل برانید.',
        'با مردم همان‌گونه رفتار کنید که انتظار دارید با شما رفتار شود.',
        'در سختی‌ها یار و مددکار برادران دینی خود باشید.'
      ],
      sceneContents: [
        'در مدینه، انصار خانه‌ها و دارایی‌های خود را با مهاجران تقسیم کردند؛ نمادی بی‌همتا از ایثار و محبت.',
        'آیا ایمان با خودخواهی سازگار است؟ لحظه‌ای در زیبایی محبت خالصانه در پرتو ایمان بیندیشید.',
        'پیامبر اکرم ﷺ میزان ایمان را نمایان کردند: «هیچ‌یک از شما مؤمن نیست مگر آنکه آنچه برای خود می‌پسندد برای برادرش نیز بپسندد.»',
        'این فرمان، قلوب مؤمنان را به هم پیوند می‌دهد و خودخواهی را از ریشه می‌خشکاند.',
        'از خود بپرسید: آیا برای دیگران نیز عزت و خیری می‌خواهم که برای خود تمنا دارم؟'
      ]
    }
  },

  // 4. حديث الصدق يهدي إلى البر (hadith-6094)
  'hadith-6094': {
    en: {
      hadith_text: 'Abdullah ibn Masud (may Allah be pleased with him) reported that the Prophet ﷺ said: "Adhere to truthfulness, for truthfulness leads to righteousness, and righteousness leads to Paradise. A person continues to tell the truth and strive for truthfulness until he is written with Allah as a truthful person. And beware of lying, for lying leads to wickedness, and wickedness leads to Hell. A person continues to lie and strive in lying until he is written with Allah as a liar."',
      topic: 'Morals & Ethics',
      context: 'Pre-Islamic society normalized deceit in trade, boasting, and poetry. The Prophet ﷺ established truthfulness as the sacred moral foundation of Muslim character.',
      explanation: 'Truthfulness is not merely avoiding false speech; it is a way of life that elevates a person step by step toward complete righteousness and the highest ranks of Paradise.',
      practical_lesson: [
        'Always speak the truth, even when facing hardship, fear, or embarrassment.',
        'Never indulge in lies, exaggerations, or deception, even in humor or trade.',
        'Continuously habituate yourself to honesty until it becomes second nature.'
      ],
      sceneContents: [
        'In marketplaces and councils, some believed falsehood was a clever way to escape difficulty, while the truthful feared earthly consequences.',
        'Does a word vanish once uttered? Or does it plant a seed in the soul that grows into light or darkness? Pause and reflect.',
        'The Prophet ﷺ placed the golden chain linking words to ultimate eternity: "Adhere to truthfulness, for truthfulness leads to righteousness..."',
        'The Hadith emphasizes "striving for truthfulness"—meaning persistent self-discipline until honesty becomes an inseparable virtue.',
        'Speak the truth even if you fear worldly harm; in truthfulness lies your genuine salvation.'
      ]
    },
    ur: {
      hadith_text: 'حضرت عبداللہ بن مسعود رضی اللہ عنہ سے روایت ہے کہ نبی کریم ﷺ نے فرمایا: "سچائی کو لازم پکڑو، کیونکہ سچ نیکی کی طرف لے جاتا ہے اور نیکی جنت کی طرف لے جاتی ہے؛ اور انسان سچ بولتا رہتا ہے اور سچ کی جستجو میں رہتا ہے یہاں تک کہ اللہ کے ہاں سچا لکھ دیا جاتا ہے۔ اور جھوٹ سے بچو، کیونکہ جھوٹ برائی کی طرف لے جاتا ہے اور برائی جہنم کی طرف لے جاتی ہے؛ اور انسان جھوٹ بولتا رہتا ہے یہاں تک کہ اللہ کے ہاں کذاب (جھوٹا) لکھ دیا جاتا ہے۔"',
      topic: 'اخلاق و آداب',
      context: 'زمانہ جاہلیت میں تجارت اور گفتگو میں جھوٹ عام تھا۔ اسلام نے آ کر سچائی کو معاشرے اور کردار کی بنیاد قرار دیا۔',
      explanation: 'یہ حدیث واضح کرتی ہے کہ سچائی محض الفاظ کا نام نہیں بلکہ زندگی کا منہج ہے جو انسان کو قدم بقدم نیکی اور جنت الفردوس کے اعلیٰ درجات تک پہنچاتا ہے۔',
      practical_lesson: [
        'ہر حال میں سچ کا دامن تھامے رکھیں، چاہے وقتی طور پر نقصان کا اندیشہ ہو۔',
        'مذاق یا تجارت میں بھی مبالغہ آرائی اور جھوٹ سے مکمل پرہیز کریں۔',
        'سچ بولنے کی مسلسل مشق کریں یہاں تک کہ یہ آپ کی فطرت بن جائے۔'
      ],
      sceneContents: [
        'بازاروں اور محافل میں بعض لوگ جھوٹ کو ہوشیاری سمجھتے تھے، جبکہ سچے لوگ حق کی راہ میں قربانی دیتے۔',
        'کیا بولی گئی بات ہوا میں غائب ہو جاتی ہے یا وہ انسان کے انجام کی بنیاد رکھتی ہے؟ ایک لمحہ سوچیے۔',
        'نبی کریم ﷺ نے سنہری زنجیر بیان فرمائی: "سچائی کو لازم پکڑو، کیونکہ سچ نیکی کی طرف اور نیکی جنت کی طرف لے جاتی ہے..."',
        'حدیث میں "سچ کی جستجو" پر زور ہے، یعنی مسلسل کوشش یہاں تک کہ بارگاہ الٰہی میں صدیق کا لقب مل جائے۔',
        'سچ بولیں چاہے جان کا خوف ہو، سچائی ہی میں حقیقی نجات اور سکون ہے۔'
      ]
    },
    fa: {
      hadith_text: 'از عبدالله بن مسعود رضی الله عنه روایت است که پیامبر ﷺ فرمودند: «بر شما باد راستی و صداقت، چرا که راستی به نیکی رهنمون می‌شود و نیکی به بهشت می‌انجامد؛ و انسان همواره راست می‌گوید و جویای راستی است تا نزد خدا راستگو نوشته شود. و از دروغ بپرهیزید، زیرا دروغ به تباهی می‌انجامد و تباهی به دوزخ رهنمون می‌گردد؛ و انسان همواره دروغ می‌گوید تا آنکه نزد خدا دروغگو ثبت گردد.»',
      topic: 'اخلاق و سیرت',
      context: 'در روزگار جاهلیت، دروغ در دادوستد و مفاخرت‌ها رایج بود. اسلام آمد تا راستگویی را رکن رکین جامعه ایمانی قرار دهد.',
      explanation: 'صداقت تنها گفتار نیست، بلکه شیوه زیستن است که گام به گام انسان را به سوی نیکی مطلق و بهشت برین بالا می‌برد.',
      practical_lesson: [
        'همواره جانب حق و راستی را نگه دارید، حتی در شرایط سخت.',
        'از هرگونه دروغ، فریب و مبالغه، حتی به شوخی یا در تجارت بپرهیزید.',
        'راستگویی را در وجود خود نهادینه کنید تا خصلت پایدار شما گردد.'
      ],
      sceneContents: [
        'در بازارهای مکه و مدینه، عده‌ای دروغ را راه فرار می‌دانستند، در حالی که اهل ایمان بر راستی پای می‌فشردند.',
        'آیا کلام پس از بیان فراموش می‌شود؟ یا بذری در جان انسان می‌کارد که به نور یا تاریکی می‌انجامد؟',
        'پیامبر اکرم ﷺ مسیر ابدی را بیان فرمودند: «بر شما باد راستی، چرا که راستی به نیکی و نیکی به بهشت می‌انجامد...»',
        'حدیث بر "تلاش مداوم برای راستی" تأکید می‌کند تا انسان در پیشگاه الهی به مقام والای "صدیق" برسد.',
        'راست بگویید، چرا که رستگاری واقعی و آرامش جاودان تنها در راستی نهفته است.'
      ]
    }
  }
};

/**
 * Localizes a single HadithItem for the selected language
 */
export function getLocalizedHadith(hadith: HadithItem, lang: AppLanguage): HadithItem {
  if (lang === 'ar') {
    return hadith;
  }

  // 1. Check if we have a full primary translation
  const fullTrans = PRIMARY_HADITHS_TRANSLATIONS[hadith.id]?.[lang];
  const templates = SCENE_TEMPLATES[lang];

  // 2. Resolve localized metadata
  const localizedNarrator = NARRATORS_MAP[hadith.narrator]?.[lang] || hadith.narrator;
  const localizedBook = BOOKS_MAP[hadith.book]?.[lang] || hadith.book;
  const localizedGrade = (GRADES_MAP[hadith.authenticity_grade]?.[lang] || hadith.authenticity_grade) as any;
  const localizedCategory = CATEGORIES_LOCALIZATION[lang].find(c => c.id === hadith.topic || c.name === hadith.topic);
  const localizedTopic = localizedCategory ? localizedCategory.name : hadith.topic;

  if (fullTrans) {
    const localizedScenes: StoryScene[] = hadith.scenes.map((sc, idx) => {
      const tmpl = templates[idx] || templates[0];
      const content = fullTrans.sceneContents[idx] || sc.content;
      return {
        ...sc,
        badge: tmpl.badge,
        title: tmpl.title,
        subtitle: tmpl.subtitle,
        content: content,
        reflectionPrompt: idx === 1 ? tmpl.reflectionPrompt : undefined,
        hadithTextExcerpt: idx === 2 ? fullTrans.hadith_text : undefined,
        audioText: content
      };
    });

    return {
      ...hadith,
      hadith_text: fullTrans.hadith_text,
      narrator: localizedNarrator,
      source: `${localizedBook}${hadith.hadith_number ? ` (#${hadith.hadith_number})` : ''}`,
      book: localizedBook,
      authenticity_grade: localizedGrade,
      topic: localizedTopic,
      context: fullTrans.context,
      explanation: fullTrans.explanation,
      practical_lesson: fullTrans.practical_lesson,
      scenes: localizedScenes
    };
  }

  // 3. Fallback for any other hadiths in the 2000 collection:
  // Translate scenes chrome, narrator, book, grade, and topic
  const fallbackScenes: StoryScene[] = hadith.scenes.map((sc, idx) => {
    const tmpl = templates[idx] || templates[0];
    return {
      ...sc,
      badge: tmpl.badge,
      title: tmpl.title,
      subtitle: tmpl.subtitle,
      reflectionPrompt: idx === 1 ? tmpl.reflectionPrompt : undefined
    };
  });

  return {
    ...hadith,
    narrator: localizedNarrator,
    book: localizedBook,
    source: `${localizedBook}${hadith.hadith_number ? ` (#${hadith.hadith_number})` : ''}`,
    authenticity_grade: localizedGrade,
    topic: localizedTopic,
    scenes: fallbackScenes
  };
}

/**
 * Returns the entire database localized for the given language
 */
export function getLocalizedHadiths(hadiths: HadithItem[], lang: AppLanguage): HadithItem[] {
  if (lang === 'ar') return hadiths;
  return hadiths.map(h => getLocalizedHadith(h, lang));
}

/**
 * Returns localized categories
 */
export function getLocalizedCategories(lang: AppLanguage): LocalizedCategory[] {
  return CATEGORIES_LOCALIZATION[lang] || CATEGORIES_LOCALIZATION.ar;
}
