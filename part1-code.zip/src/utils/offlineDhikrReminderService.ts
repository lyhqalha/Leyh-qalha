/**
 * Professional Studio Human Podcast Athkar Engine
 * 100% Offline, Real Human Voice (Charon studio narration).
 * Cycles through distinct Athkar automatically every 15, 30, or 60 minutes.
 */

import { OFFLINE_ATHKAR_COLLECTION, OfflineDhikrItem } from '../data/offlineAthkarAudios';

export type DhikrIntervalMinutes = 15 | 30 | 60;

export interface DhikrReminderConfig {
  enabled: boolean;
  intervalMinutes: DhikrIntervalMinutes;
  lastTriggeredTimestamp?: number;
  lastDhikrIndex: number;
}

const STORAGE_KEY = 'leh_qalha_periodic_dhikr_config';

const DEFAULT_CONFIG: DhikrReminderConfig = {
  enabled: true, // Enabled by default
  intervalMinutes: 30, // Default 30 minutes
  lastDhikrIndex: 0,
};

let currentAudio: HTMLAudioElement | null = null;
let timerId: any = null;
let onReminderTriggerCallback: ((item: OfflineDhikrItem) => void) | null = null;
let audioContextInstance: AudioContext | null = null;

export function loadDhikrReminderConfig(): DhikrReminderConfig {
  if (typeof window === 'undefined') return DEFAULT_CONFIG;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_CONFIG;
    const parsed = JSON.parse(raw);
    return {
      enabled: typeof parsed.enabled === 'boolean' ? parsed.enabled : DEFAULT_CONFIG.enabled,
      intervalMinutes: [15, 30, 60].includes(parsed.intervalMinutes) ? parsed.intervalMinutes : 30,
      lastTriggeredTimestamp: parsed.lastTriggeredTimestamp,
      lastDhikrIndex: typeof parsed.lastDhikrIndex === 'number' ? parsed.lastDhikrIndex : 0,
    };
  } catch {
    return DEFAULT_CONFIG;
  }
}

export function saveDhikrReminderConfig(config: DhikrReminderConfig): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
  } catch {
    // Ignored
  }
}

/**
 * Gets the next distinct Dhikr to recite, ensuring a different dhikr every time
 */
export function getNextDhikrItem(config: DhikrReminderConfig): { item: OfflineDhikrItem; newIndex: number } {
  const items = OFFLINE_ATHKAR_COLLECTION;
  if (!items || items.length === 0) {
    throw new Error('No athkar available in collection');
  }
  const nextIdx = (config.lastDhikrIndex + 1) % items.length;
  return { item: items[nextIdx], newIndex: nextIdx };
}

/**
 * Plays the Athkar audio with boosted volume for mobile & desktop clarity
 */
export function playOfflineDhikrAudio(item: OfflineDhikrItem, onEnd?: () => void): Promise<void> {
  return new Promise((resolve) => {
    try {
      if (currentAudio) {
        currentAudio.pause();
        currentAudio.currentTime = 0;
        currentAudio = null;
      }

      const audioSrc = item.dataUri || item.url;
      const audio = new Audio(audioSrc);
      currentAudio = audio;
      audio.volume = 1.0;

      // Safe user gesture audio unlock without hijacking HTML5 audio if suspended
      if (typeof window !== 'undefined') {
        try {
          const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
          if (AudioContextClass) {
            if (!audioContextInstance || audioContextInstance.state === 'closed') {
              audioContextInstance = new AudioContextClass();
            }
            if (audioContextInstance.state === 'suspended') {
              audioContextInstance.resume().catch(() => {});
            }
          }
        } catch {
          // Ignore
        }
      }

      audio.onended = () => {
        currentAudio = null;
        if (onEnd) onEnd();
        resolve();
      };

      audio.onerror = (e) => {
        console.warn('[Dhikr Player] Audio play error, trying fallback:', e);
        tryWebSpeechArabicFallback(item.text);
        currentAudio = null;
        if (onEnd) onEnd();
        resolve();
      };

      const playPromise = audio.play();
      if (playPromise !== undefined) {
        playPromise
          .then(() => resolve())
          .catch((err) => {
            console.warn('[Dhikr Player] Autoplay policy prevented playback:', err);
            tryWebSpeechArabicFallback(item.text);
            resolve();
          });
      }
    } catch {
      tryWebSpeechArabicFallback(item.text);
      resolve();
    }
  });
}

export function stopCurrentDhikrAudio(): void {
  if (currentAudio) {
    currentAudio.pause();
    currentAudio.currentTime = 0;
    currentAudio = null;
  }
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}

function tryWebSpeechArabicFallback(text: string): void {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
  try {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'ar-SA';
    utterance.rate = 0.85;
    utterance.pitch = 0.9;
    window.speechSynthesis.speak(utterance);
  } catch {
    // Ignored
  }
}

/**
 * Triggers the next distinct Dhikr: plays professional human podcast audio and notifies UI
 */
export async function triggerDhikrReminderNow(): Promise<OfflineDhikrItem> {
  const config = loadDhikrReminderConfig();
  const { item, newIndex } = getNextDhikrItem(config);

  config.lastDhikrIndex = newIndex;
  config.lastTriggeredTimestamp = Date.now();
  saveDhikrReminderConfig(config);

  // Play professional human podcast audio
  await playOfflineDhikrAudio(item);

  // Notify UI
  if (onReminderTriggerCallback) {
    onReminderTriggerCallback(item);
  }

  return item;
}

/**
 * Initialize background scheduler in the browser
 */
export function initDhikrScheduler(onTrigger: (item: OfflineDhikrItem) => void): () => void {
  onReminderTriggerCallback = onTrigger;

  if (timerId) {
    clearInterval(timerId);
    timerId = null;
  }

  const checkTick = () => {
    // Reminders appear/speak ONLY while the app is open on screen
    if (typeof document !== 'undefined' && document.visibilityState !== 'visible') return;
    const config = loadDhikrReminderConfig();
    if (!config.enabled) return;

    const intervalMs = config.intervalMinutes * 60 * 1000;
    const now = Date.now();
    const lastTime = config.lastTriggeredTimestamp || 0;

    // If interval has passed
    if (now - lastTime >= intervalMs) {
      triggerDhikrReminderNow();
    }
  };

  // Going to background: silence anything playing, never speak in background
  const onVisibility = () => {
    if (document.visibilityState !== 'visible') stopCurrentDhikrAudio();
  };
  document.addEventListener('visibilitychange', onVisibility);

  // Run initial check after 5 seconds
  setTimeout(checkTick, 5000);
  timerId = setInterval(checkTick, 25000);

  return () => {
    document.removeEventListener('visibilitychange', onVisibility);
    if (timerId) {
      clearInterval(timerId);
      timerId = null;
    }
    onReminderTriggerCallback = null;
  };
}
