/**
 * Native (Android) daily-hadith notification with a custom tone.
 * - Schedules the next 30 days, each with that day's own hadith text.
 * - Only runs inside the Android app; on the web it does nothing.
 * - The periodic dhikr reminders (15/30/60 min) are NOT handled here:
 *   they only run while the app is open (see offlineDhikrReminderService).
 */
import { Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';
import { HadithItem } from '../types/hadith';
import { getDailyHadith } from './dailyHadith';

const CHANNEL_ID = 'daily_hadith_v1';
const SOUND_FILE = 'hadith_tone.wav'; // android/app/src/main/res/raw/hadith_tone.wav
const DAYS_AHEAD = 30;
const ID_BASE = 7000;

export const isNativeApp = (): boolean => {
  try {
    return Capacitor.isNativePlatform();
  } catch {
    return false;
  }
};

async function ensureChannel(): Promise<void> {
  await LocalNotifications.createChannel({
    id: CHANNEL_ID,
    name: 'حديث اليوم',
    description: 'تذكير يومي بقراءة حديث اليوم',
    importance: 5,
    sound: SOUND_FILE,
    vibration: true,
    visibility: 1,
  });
}

export async function requestNotificationPermission(): Promise<boolean> {
  if (!isNativeApp()) return false;
  try {
    const cur = await LocalNotifications.checkPermissions();
    if (cur.display === 'granted') return true;
    const res = await LocalNotifications.requestPermissions();
    return res.display === 'granted';
  } catch {
    return false;
  }
}

export async function cancelDailyHadithNotifications(): Promise<void> {
  if (!isNativeApp()) return;
  try {
    await LocalNotifications.cancel({
      notifications: Array.from({ length: DAYS_AHEAD + 2 }, (_, i) => ({ id: ID_BASE + i })),
    });
  } catch {
    // ignored
  }
}

/**
 * (Re)schedules the daily hadith notification. Call whenever the setting
 * changes and every time the app opens (keeps the 30-day window rolling).
 */
export async function scheduleDailyHadithNotifications(
  enabled: boolean,
  time: string,
  hadiths: HadithItem[],
  appTitle: string,
  heading: string
): Promise<void> {
  if (!isNativeApp()) return;
  try {
    await cancelDailyHadithNotifications();
    if (!enabled || !hadiths.length) return;

    const granted = await requestNotificationPermission();
    if (!granted) return;
    await ensureChannel();

    // Android 12+: exact alarms need user approval for on-time delivery
    try {
      const exact = await LocalNotifications.checkExactNotificationSetting();
      if (exact.exact_alarm !== 'granted') {
        await LocalNotifications.changeExactNotificationSetting();
      }
    } catch {
      // older Android / plugin versions: ignore
    }

    const [hh, mm] = time.split(':').map((n) => parseInt(n, 10));
    const hour = Number.isFinite(hh) ? hh : 9;
    const minute = Number.isFinite(mm) ? mm : 0;
    const now = new Date();
    const notifications = [];

    for (let i = 0; i <= DAYS_AHEAD; i++) {
      const at = new Date(now.getFullYear(), now.getMonth(), now.getDate() + i, hour, minute, 0, 0);
      if (at.getTime() <= now.getTime() + 5000) continue;
      const item = getDailyHadith(hadiths, at);
      const body = item.hadith_text
        ? item.hadith_text.slice(0, 110) + (item.hadith_text.length > 110 ? '...' : '')
        : item.context.slice(0, 110);
      notifications.push({
        id: ID_BASE + i,
        title: `📖 ${appTitle} - ${heading}: ${item.topic}`,
        body: `«${body}»`,
        channelId: CHANNEL_ID,
        sound: SOUND_FILE,
        schedule: { at, allowWhileIdle: true },
        extra: { target: 'daily' },
      });
    }

    if (notifications.length) {
      await LocalNotifications.schedule({ notifications });
    }
  } catch (e) {
    console.warn('[Notifications] schedule failed', e);
  }
}

/** Fire one immediately (for the "test" button) with the custom tone. */
export async function sendTestNativeNotification(title: string, body: string): Promise<void> {
  if (!isNativeApp()) return;
  try {
    if (!(await requestNotificationPermission())) return;
    await ensureChannel();
    await LocalNotifications.schedule({
      notifications: [
        {
          id: ID_BASE + 900,
          title,
          body,
          channelId: CHANNEL_ID,
          sound: SOUND_FILE,
          schedule: { at: new Date(Date.now() + 1500), allowWhileIdle: true },
          extra: { target: 'daily' },
        },
      ],
    });
  } catch {
    // ignored
  }
}

/** Called when the user taps the notification. */
export function onNotificationTapped(cb: () => void): () => void {
  if (!isNativeApp()) return () => {};
  let handle: { remove: () => Promise<void> } | null = null;
  LocalNotifications.addListener('localNotificationActionPerformed', () => cb()).then((h) => {
    handle = h;
  });
  return () => {
    handle?.remove();
  };
}
