import React, { createContext, useContext, useState, useEffect } from 'react';
import { AppLanguage, translations, TranslationKey, SUPPORTED_LANGUAGES, LanguageOption } from '../utils/translations';

interface LanguageContextType {
  language: AppLanguage;
  setLanguage: (lang: AppLanguage) => void;
  t: (key: TranslationKey, params?: Record<string, string | number>) => string;
  isRtl: boolean;
  currentLanguageOption: LanguageOption;
  supportedLanguages: LanguageOption[];
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const LANGUAGE_STORAGE_KEY = 'leh_qalha_app_language';

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<AppLanguage>(() => {
    try {
      const saved = localStorage.getItem(LANGUAGE_STORAGE_KEY) as AppLanguage;
      if (saved && ['ar', 'en', 'ur', 'fa'].includes(saved)) {
        return saved;
      }
    } catch {
      // Ignored
    }
    return 'ar'; // Default Arabic
  });

  const currentLanguageOption = SUPPORTED_LANGUAGES.find((l) => l.code === language) || SUPPORTED_LANGUAGES[0];
  const isRtl = currentLanguageOption.dir === 'rtl';

  useEffect(() => {
    try {
      localStorage.setItem(LANGUAGE_STORAGE_KEY, language);
      document.documentElement.lang = language;
      document.documentElement.dir = currentLanguageOption.dir;
      if (currentLanguageOption.dir === 'rtl') {
        document.documentElement.classList.add('dir-rtl');
        document.documentElement.classList.remove('dir-ltr');
      } else {
        document.documentElement.classList.add('dir-ltr');
        document.documentElement.classList.remove('dir-rtl');
      }
    } catch {
      // Ignored
    }
  }, [language, currentLanguageOption.dir]);

  const setLanguage = (newLang: AppLanguage) => {
    if (['ar', 'en', 'ur', 'fa'].includes(newLang)) {
      setLanguageState(newLang);
    }
  };

  const t = (key: TranslationKey, params?: Record<string, string | number>): string => {
    const langDict = translations[language] || translations.ar;
    let text = (langDict as any)[key] || (translations.ar as any)[key] || key;
    if (params) {
      Object.entries(params).forEach(([k, v]) => {
        text = text.replace(new RegExp(`\\{${k}\\}`, 'g'), String(v));
      });
    }
    return text;
  };

  return (
    <LanguageContext.Provider
      value={{
        language,
        setLanguage,
        t,
        isRtl,
        currentLanguageOption,
        supportedLanguages: SUPPORTED_LANGUAGES,
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
};

export function useLanguage(): LanguageContextType {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
