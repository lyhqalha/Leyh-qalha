import React from 'react';
import { ActiveTab } from '../types/hadith';
import { Home, Bookmark, Search, Calendar, LayoutGrid } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface BottomNavProps {
  activeTab: ActiveTab;
  onChangeTab: (tab: ActiveTab) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, onChangeTab }) => {
  const { t } = useLanguage();

  const navItems: { tab: ActiveTab; label: string; icon: React.ReactNode }[] = [
    { tab: 'home', label: t('navHome'), icon: <Home className="w-5 h-5" /> },
    { tab: 'saved', label: t('navSaved'), icon: <Bookmark className="w-5 h-5" /> },
    { tab: 'search', label: t('navSearch'), icon: <Search className="w-5 h-5" /> },
    { tab: 'daily', label: t('navDaily'), icon: <Calendar className="w-5 h-5" /> },
    { tab: 'categories', label: t('navCategories'), icon: <LayoutGrid className="w-5 h-5" /> },
  ];

  return (
    <nav className="fixed bottom-0 inset-x-0 z-40 bg-[#131B2E]/95 backdrop-blur-md border-t border-slate-800 flex justify-center pb-safe">
      <div className="grid grid-cols-5 items-center w-full max-w-md h-16 px-1">
        {navItems.map((item) => {
          const isActive = activeTab === item.tab;
          return (
            <button
              key={item.tab}
              onClick={() => onChangeTab(item.tab)}
              className="flex flex-col items-center justify-center h-full min-h-[44px] relative transition-colors focus:outline-none"
            >
              <div
                className={`transition-transform duration-200 ${
                  isActive ? 'text-[#E2B773] scale-110' : 'text-[#94A3B8] hover:text-slate-300'
                }`}
              >
                {item.icon}
              </div>
              <span
                className={`text-[10px] mt-1 font-bold tracking-tight transition-colors ${
                  isActive ? 'text-[#E2B773]' : 'text-[#94A3B8]'
                }`}
              >
                {item.label}
              </span>

              {/* Active subtle indicator dot */}
              {isActive && (
                <div className="absolute top-1 w-1 h-1 rounded-full bg-[#E2B773]" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
