import React, { useState, useEffect } from 'react';
import { getAllDownloadedAudios, getTotalOfflineSizeMB, clearAllOfflineAudios, cacheAllPrepackagedAudios } from '../utils/offlineAudioService';
import {
  X,
  Type,
  Sparkles,
  Bell,
  Clock,
  Heart,
  Trash2,
  WifiOff,
  Volume2,
  Square,
  Mic,
  Check,
  Globe,
  Download,
  RotateCw,
  Play
} from 'lucide-react';
import {
  loadDhikrReminderConfig,
  saveDhikrReminderConfig,
  triggerDhikrReminderNow,
  stopCurrentDhikrAudio,
  playOfflineDhikrAudio,
  DhikrIntervalMinutes,
  DhikrReminderConfig
} from '../utils/offlineDhikrReminderService';
import { OFFLINE_ATHKAR_COLLECTION, OfflineDhikrItem } from '../data/offlineAthkarAudios';
import { useLanguage } from '../context/LanguageContext';
import { downloadAllAthkarPack, getAthkarPackStatus, AthkarPackStatus } from '../utils/offlineAthkarDownloader';
import { AppLanguage } from '../utils/translations';

interface SettingsModalProps {
  isOpen?: boolean;
  onClose: () => void;
  // Font size
  fontSize?: 'sm' | 'md' | 'lg' | 'normal' | 'large' | 'xlarge';
  onChangeFontSize?: (size: any) => void;
  // Daily reminder
  isReminderEnabled: boolean;
  onToggleReminder: (enabled: boolean) => void;
  reminderTime: string;
  onChangeReminderTime: (time: string) => void;
  onTriggerTestReminder?: () => void;
  onTestReminder?: () => void;
  onOpenStats?: () => void;
  onOpenAbout?: () => void;
  // Backward compatibility optional props
  isDeviceFrame?: boolean;
  onToggleDeviceFrame?: () => void;
  themeMode?: string;
  onChangeThemeMode?: (mode: any) => void;
  isUltraDarkMode?: boolean;
  onToggleUltraDarkMode?: (enabled?: any) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen = true,
  onClose,
  fontSize = 'md',
  onChangeFontSize,
  isReminderEnabled,
  onToggleReminder,
  reminderTime,
  onChangeReminderTime,
  onTriggerTestReminder,
  onTestReminder,
}) => {
  const { language, setLanguage, t, supportedLanguages, isRtl } = useLanguage();

  const [offlineCount, setOfflineCount] = useState<number>(0);
  const [offlineSizeMB, setOfflineSizeMB] = useState<number>(0);
  const [testNotificationSent, setTestNotificationSent] = useState(false);

  // Periodic Dhikr & Salawat configuration
  const [dhikrConfig, setDhikrConfig] = useState<DhikrReminderConfig>(loadDhikrReminderConfig);
  const [activeTestItem, setActiveTestItem] = useState<OfflineDhikrItem | null>(null);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [playingSingleTrackId, setPlayingSingleTrackId] = useState<string | null>(null);

  // Offline Athkar Pack Download status
  const [packStatus, setPackStatus] = useState<AthkarPackStatus>(getAthkarPackStatus);
  const [isDownloadingPack, setIsDownloadingPack] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);

  useEffect(() => {
    if (isOpen) {
      setOfflineCount(getAllDownloadedAudios().length);
      setOfflineSizeMB(getTotalOfflineSizeMB());
      setDhikrConfig(loadDhikrReminderConfig());
      setPackStatus(getAthkarPackStatus());
    }
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen) {
      stopCurrentDhikrAudio();
      setIsPlayingAudio(false);
      setPlayingSingleTrackId(null);
      setActiveTestItem(null);
    }
  }, [isOpen]);

  const handleToggleDhikrEnabled = (enabled: boolean) => {
    const updated = { ...dhikrConfig, enabled };
    setDhikrConfig(updated);
    saveDhikrReminderConfig(updated);
  };

  const handleChangeDhikrInterval = (interval: DhikrIntervalMinutes) => {
    const updated = { ...dhikrConfig, intervalMinutes: interval };
    setDhikrConfig(updated);
    saveDhikrReminderConfig(updated);
  };

  const handleTestNextDhikr = async () => {
    try {
      setIsPlayingAudio(true);
      const item = await triggerDhikrReminderNow();
      setActiveTestItem(item);
      setDhikrConfig(loadDhikrReminderConfig());
      setTimeout(() => {
        setIsPlayingAudio(false);
      }, 8000);
    } catch {
      setIsPlayingAudio(false);
    }
  };

  const handleStopAudio = () => {
    stopCurrentDhikrAudio();
    setIsPlayingAudio(false);
    setPlayingSingleTrackId(null);
    setActiveTestItem(null);
  };

  const handlePlaySingleTrack = async (track: OfflineDhikrItem) => {
    if (playingSingleTrackId === track.id) {
      handleStopAudio();
      return;
    }
    stopCurrentDhikrAudio();
    setPlayingSingleTrackId(track.id);
    setIsPlayingAudio(true);
    setActiveTestItem(track);

    await playOfflineDhikrAudio(track, () => {
      setPlayingSingleTrackId(null);
      setIsPlayingAudio(false);
    });
  };

  const handleDownloadPack = async () => {
    setIsDownloadingPack(true);
    setDownloadProgress(0);

    // 1. Download Athkar pack
    await downloadAllAthkarPack((progress) => {
      setDownloadProgress(Math.round(progress * 0.5));
    });

    // 2. Cache Hadiths & Stories pre-stored tracks
    await cacheAllPrepackagedAudios((progress) => {
      setDownloadProgress(50 + Math.round(progress * 0.5));
    });

    setIsDownloadingPack(false);
    setPackStatus(getAthkarPackStatus());
    setOfflineCount(getAllDownloadedAudios().length);
    setOfflineSizeMB(getTotalOfflineSizeMB());
  };

  const handleClearAllOffline = async () => {
    if (window.confirm(t('confirmClearOffline'))) {
      await clearAllOfflineAudios();
      setOfflineCount(0);
      setOfflineSizeMB(0);
    }
  };

  if (!isOpen) return null;

  const handleTriggerTestReminder = () => {
    if (onTriggerTestReminder) {
      onTriggerTestReminder();
    } else if (onTestReminder) {
      onTestReminder();
    }
    setTestNotificationSent(true);
    setTimeout(() => {
      setTestNotificationSent(false);
    }, 3000);
  };

  const REMINDER_PRESETS = [
    { label: t('dawnPreset'), time: '05:30' },
    { label: t('morningPreset'), time: '09:00' },
    { label: t('afternoonPreset'), time: '16:30' },
    { label: t('eveningPreset'), time: '21:00' }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div
        className="w-full max-w-lg bg-[#0F172A] border border-slate-800 rounded-3xl shadow-2xl flex flex-col max-h-[92vh] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="px-5 py-4 border-b border-slate-800/80 flex items-center justify-between bg-[#141E33]/60">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#E2B773]/15 text-[#E2B773] flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white leading-tight">{t('settings')}</h2>
              <p className="text-[11px] text-slate-400">{t('languageDescription')}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center transition-all"
            title={t('close')}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 custom-scrollbar text-start">

          {/* 1. لغة التطبيق بالكامل (Language Selector) */}
          <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-b from-[#152035] to-[#0D1424] border border-[#E2B773]/40 shadow-lg space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-[#E2B773]/20 text-[#E2B773] flex items-center justify-center">
                  <Globe className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-xs sm:text-sm">{t('language')}</h3>
                  <p className="text-[10px] text-slate-400">{t('chooseLanguage')}</p>
                </div>
              </div>
              <span className="px-2.5 py-1 rounded-full bg-[#E2B773]/15 border border-[#E2B773]/30 text-xs font-bold text-[#E2B773]">
                {supportedLanguages.find((l) => l.code === language)?.nativeName}
              </span>
            </div>

            {/* 4 Language Buttons */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
              {supportedLanguages.map((lang) => {
                const isSelected = language === lang.code;
                return (
                  <button
                    key={lang.code}
                    onClick={() => setLanguage(lang.code as AppLanguage)}
                    className={`p-2.5 rounded-xl border flex flex-col items-center justify-center gap-1 transition-all ${
                      isSelected
                        ? 'bg-[#E2B773] border-[#E2B773] text-[#0D131F] font-bold shadow-md scale-102'
                        : 'bg-[#141C2E] border-slate-800 text-slate-300 hover:border-slate-700 hover:text-white'
                    }`}
                  >
                    <span className="text-xl leading-none">{lang.flag}</span>
                    <span className="text-xs font-bold leading-tight">{lang.nativeName}</span>
                    <span className={`text-[9px] ${isSelected ? 'text-[#0D131F]/80' : 'text-slate-400'}`}>
                      {lang.name}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 2. الأذكار */}
          <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-b from-[#131E33] to-[#0D131F] border border-[#E2B773]/50 shadow-xl space-y-3.5 relative overflow-hidden">
            {/* Header with Switch */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-[#E2B773]/20 text-[#E2B773] flex items-center justify-center shrink-0 border border-[#E2B773]/30">
                  <Mic className="w-4 h-4 text-[#E2B773]" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-xs sm:text-sm">
                    {t('dhikrTitle')}
                  </h3>
                  <p className="text-[11px] text-slate-300 mt-0.5">
                    {t('dhikrSub')}
                  </p>
                </div>
              </div>

              {/* Master Control Switch */}
              <button
                onClick={() => handleToggleDhikrEnabled(!dhikrConfig.enabled)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none shrink-0 ${
                  dhikrConfig.enabled ? 'bg-[#E2B773]' : 'bg-slate-800'
                }`}
                title={dhikrConfig.enabled ? 'إلغاء' : 'تشغيل'}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-[#0D131F] transition-transform ${
                    dhikrConfig.enabled
                      ? isRtl ? '-translate-x-6' : 'translate-x-6'
                      : isRtl ? '-translate-x-1' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            {/* Controls when enabled */}
            {dhikrConfig.enabled ? (
              <div className="pt-2 border-t border-slate-800/80 space-y-3 animate-fadeIn">
                {/* Interval Selection: 15m, 30m, 60m */}
                <div className="space-y-1.5">
                  <span className="text-[11px] font-bold text-slate-300 block">
                    {t('dhikrIntervalLabel')}
                  </span>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { minutes: 15 as DhikrIntervalMinutes, label: t('every15m'), sub: t('every15mSub') },
                      { minutes: 30 as DhikrIntervalMinutes, label: t('every30m'), sub: t('every30mSub') },
                      { minutes: 60 as DhikrIntervalMinutes, label: t('every60m'), sub: t('every60mSub') }
                    ].map((item) => {
                      const isSelected = dhikrConfig.intervalMinutes === item.minutes;
                      return (
                        <button
                          key={item.minutes}
                          onClick={() => handleChangeDhikrInterval(item.minutes)}
                          className={`p-2.5 rounded-xl border text-center transition-all ${
                            isSelected
                              ? 'bg-[#E2B773] border-[#E2B773] text-[#0D131F] font-bold shadow-md'
                              : 'bg-[#141C2E] border-slate-800 text-slate-300 hover:border-slate-700'
                          }`}
                        >
                          <span className="text-xs block leading-tight">{item.label}</span>
                          <span className={`text-[10px] block opacity-80 mt-0.5 ${isSelected ? 'text-[#0D131F]' : 'text-slate-400'}`}>
                            {item.sub}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Instant Test / Listen Button */}
                <div className="pt-1 space-y-2">
                  <button
                    onClick={isPlayingAudio ? handleStopAudio : handleTestNextDhikr}
                    className={`w-full py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 border transition-all active:scale-98 shadow-sm ${
                      isPlayingAudio
                        ? 'bg-rose-500/20 border-rose-500/40 text-rose-300'
                        : 'bg-[#E2B773]/15 hover:bg-[#E2B773]/25 border-[#E2B773]/40 text-[#E2B773]'
                    }`}
                  >
                    {isPlayingAudio ? (
                      <>
                        <Square className="w-3.5 h-3.5 fill-current" />
                        <span>{t('stopDhikrNow')}</span>
                      </>
                    ) : (
                      <>
                        <Volume2 className="w-3.5 h-3.5" />
                        <span>{t('listenDhikrNow')}</span>
                      </>
                    )}
                  </button>

                  {/* Active Playing Dhikr Card */}
                  {activeTestItem && (
                    <div className="p-3 rounded-xl bg-slate-900 border border-[#E2B773]/40 text-center animate-fadeIn space-y-1">
                      <span className="text-[10px] font-bold text-[#E2B773] block">
                        🎙️ {activeTestItem.title}
                      </span>
                      <p className="text-xs text-white font-arabic leading-relaxed font-bold">
                        «{activeTestItem.text}»
                      </p>
                    </div>
                  )}

                  <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center gap-2 text-[11px] text-emerald-300">
                    <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>{t('dhikrQualityBadge')}</span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="pt-1 text-center py-2 text-slate-500 text-xs">
                {t('dhikrDisabledPrompt')}
              </div>
            )}
          </div>

          {/* 3. زر تنزيل باقة الأذكار بالكامل للعمل أوفلاين (Download All Athkar Pack) */}
          <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-b from-[#132228] to-[#0D181D] border border-emerald-500/40 shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 border border-emerald-500/30">
                  <Download className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-xs sm:text-sm">
                    {t('downloadPackTitle')}
                  </h3>
                  <p className="text-[11px] text-slate-300 mt-0.5">
                    {t('downloadPackDesc')}
                  </p>
                </div>
              </div>
            </div>

            {/* Download Button & Status */}
            <div className="pt-1 space-y-2">
              <button
                onClick={handleDownloadPack}
                disabled={isDownloadingPack}
                className={`w-full py-3 px-4 rounded-xl text-xs font-black flex items-center justify-center gap-2 transition-all active:scale-98 shadow-md ${
                  isDownloadingPack
                    ? 'bg-slate-800 text-slate-400 border border-slate-700 cursor-wait'
                    : 'bg-emerald-500 hover:bg-emerald-400 text-[#0D131F]'
                }`}
              >
                {isDownloadingPack ? (
                  <>
                    <RotateCw className="w-4 h-4 animate-spin text-emerald-400" />
                    <span>{t('downloadingPackProgress', { progress: downloadProgress })}</span>
                  </>
                ) : (
                  <>
                    <Download className="w-4 h-4" />
                    <span>{t('downloadPackBtn')}</span>
                  </>
                )}
              </button>

              {/* Progress bar during download */}
              {isDownloadingPack && (
                <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden border border-emerald-500/30">
                  <div
                    className="bg-emerald-400 h-full transition-all duration-200"
                    style={{ width: `${downloadProgress}%` }}
                  />
                </div>
              )}

              {/* Verified badge */}
              <div className="p-2.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 space-y-1">
                <div className="flex items-center gap-2 text-xs font-bold text-emerald-300">
                  <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>{t('downloadPackSuccess')}</span>
                </div>
                <p className="text-[10px] text-emerald-200/80">
                  {t('packStatsInfo')}
                </p>
              </div>

              {/* Quick Athkar List Previews */}
              <div className="pt-2 space-y-1.5">
                <span className="text-[10px] font-bold text-slate-400 block">
                  {t('athkarClickListen')}
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                  {OFFLINE_ATHKAR_COLLECTION.map((item) => {
                    const isPlayingThis = playingSingleTrackId === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => handlePlaySingleTrack(item)}
                        className={`p-2 rounded-xl border text-start flex items-center justify-between gap-2 text-[11px] transition-all ${
                          isPlayingThis
                            ? 'bg-[#E2B773]/20 border-[#E2B773] text-[#E2B773] font-bold'
                            : 'bg-[#141C2E] border-slate-800 text-slate-300 hover:border-slate-700 hover:text-white'
                        }`}
                      >
                        <div className="flex items-center gap-2 truncate">
                          {isPlayingThis ? (
                            <Square className="w-3.5 h-3.5 fill-current shrink-0 text-[#E2B773]" />
                          ) : (
                            <Play className="w-3.5 h-3.5 shrink-0 text-slate-400" />
                          )}
                          <span className="truncate">{item.spokenText || item.text}</span>
                        </div>
                        <span className="text-[9px] px-1.5 py-0.5 rounded bg-black/40 text-slate-400 shrink-0">
                          {t('offline')}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* 4. حجم خط نصوص الأحاديث والقصص */}
          <div className="p-4 rounded-2xl bg-[#0D131F] border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-200 flex items-center gap-1.5 text-xs sm:text-sm">
                <Type className="w-4 h-4 text-[#E2B773]" />
                <span>{t('fontSizeTitle')}</span>
              </span>
              <span className="text-[11px] font-mono text-[#E2B773]">
                {fontSize === 'sm' ? t('fontSmall') : fontSize === 'lg' ? t('fontLarge') : t('fontMedium')}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'sm', label: t('fontSmall'), desc: t('fontSmallDesc') },
                { id: 'md', label: t('fontMedium'), desc: t('fontMediumDesc') },
                { id: 'lg', label: t('fontLarge'), desc: t('fontLargeDesc') }
              ].map((opt) => {
                const isSelected = fontSize === opt.id;
                return (
                  <button
                    key={opt.id}
                    onClick={() => onChangeFontSize && onChangeFontSize(opt.id)}
                    className={`p-2 rounded-xl border text-center transition-all ${
                      isSelected
                        ? 'bg-[#E2B773] border-[#E2B773] text-[#0D131F] font-bold shadow-md'
                        : 'bg-[#141C2E] border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <span className="text-xs block leading-tight">{opt.label}</span>
                    <span className={`text-[10px] block opacity-80 mt-0.5 ${isSelected ? 'text-[#0D131F]' : 'text-slate-400'}`}>
                      {opt.desc}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 5. تذكير القراءة اليومي للحديث الشريف */}
          <div className="p-4 rounded-2xl bg-[#0D131F] border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-500/15 text-amber-400 flex items-center justify-center shrink-0">
                  <Bell className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-xs sm:text-sm">{t('dailyNotifTitle')}</h3>
                  <p className="text-[10px] text-slate-400">{t('dailyNotifSub')}</p>
                </div>
              </div>

              {/* Toggle Switch */}
              <button
                onClick={() => onToggleReminder(!isReminderEnabled)}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none shrink-0 ${
                  isReminderEnabled ? 'bg-[#E2B773]' : 'bg-slate-800'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-[#0D131F] transition-transform ${
                    isReminderEnabled
                      ? isRtl ? '-translate-x-6' : 'translate-x-6'
                      : isRtl ? '-translate-x-1' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            {isReminderEnabled && (
              <div className="pt-2 border-t border-slate-800/80 space-y-2.5 animate-fadeIn">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[11px] text-slate-300 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-[#E2B773]" />
                    <span>{t('setAlertTime')}</span>
                  </span>
                  <input
                    type="time"
                    value={reminderTime}
                    onChange={(e) => onChangeReminderTime(e.target.value)}
                    className="bg-[#141C2E] border border-slate-700 text-[#E2B773] font-mono font-bold text-xs px-2.5 py-1 rounded-xl focus:outline-none focus:border-[#E2B773]"
                  />
                </div>

                {/* Quick Presets */}
                <div className="grid grid-cols-4 gap-1.5 pt-1">
                  {REMINDER_PRESETS.map((p) => (
                    <button
                      key={p.time}
                      onClick={() => onChangeReminderTime(p.time)}
                      className={`py-1 px-1 rounded-lg text-center transition-all text-[10px] ${
                        reminderTime === p.time
                          ? 'bg-[#E2B773] text-[#0D131F] font-bold shadow-sm'
                          : 'bg-[#141C2E] text-slate-400 hover:text-white border border-slate-800'
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>

                {/* Test Notification Button */}
                <div className="pt-1 flex items-center justify-between gap-2">
                  <button
                    onClick={handleTriggerTestReminder}
                    className="w-full py-1.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 active:scale-98 text-slate-200 text-[11px] font-semibold flex items-center justify-center gap-2 border border-slate-700/80 transition-all"
                  >
                    <Bell className="w-3.5 h-3.5 text-[#E2B773]" />
                    <span>{testNotificationSent ? t('testNotifSent') : t('testNotifBtn')}</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* 6. الصوتيات المحفوظة أوفلاين */}
          <div className="p-4 rounded-2xl bg-[#0D131F] border border-slate-800 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-200 flex items-center gap-1.5 text-xs sm:text-sm">
                <WifiOff className="w-4 h-4 text-emerald-400" />
                <span>{t('offlineAudiosTitle')}</span>
              </span>
              <span className="text-xs font-mono font-bold text-emerald-400">
                {offlineCount} ملف ({offlineSizeMB} MB)
              </span>
            </div>

            <p className="text-[11px] text-slate-400 leading-relaxed">
              {t('offlineAudiosDesc')}
            </p>

            {offlineCount > 0 && (
              <div className="pt-1">
                <button
                  onClick={handleClearAllOffline}
                  className="w-full py-1.5 px-3 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 text-xs font-semibold flex items-center justify-center gap-2 border border-rose-500/20 transition-all"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>{t('clearOfflineAudiosBtn')}</span>
                </button>
              </div>
            )}
          </div>

          {/* 7. حول التطبيق والرسالة الوقفية */}
          <div className="p-4 rounded-2xl bg-[#0D131F] border border-slate-800 space-y-2">
            <span className="font-bold text-slate-300 flex items-center gap-1.5 text-xs sm:text-sm">
              <Heart className="w-4 h-4 text-rose-400 fill-rose-400/20" />
              <span>{t('charitableTag')}</span>
            </span>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              {t('charitableNotice')}
            </p>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-800/80 bg-[#141E33]/40 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-[#E2B773] hover:bg-[#d8a860] active:scale-95 text-[#0D131F] font-bold text-xs transition-all shadow-md"
          >
            {t('saveAndClose')}
          </button>
        </div>
      </div>
    </div>
  );
};
