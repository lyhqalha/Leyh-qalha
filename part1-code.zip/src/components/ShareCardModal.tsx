import React, { useRef, useState } from 'react';
import { HadithItem } from '../types/hadith';
import { useLanguage } from '../context/LanguageContext';
import { X, Download, Copy, Share2, Check } from 'lucide-react';

interface ShareCardModalProps {
  hadith: HadithItem;
  onClose: () => void;
}

export const ShareCardModal: React.FC<ShareCardModalProps> = ({ hadith, onClose }) => {
  const { t, language } = useLanguage();
  const [copied, setCopied] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  const handleCopyText = async () => {
    let textToCopy = `قال رسول الله ﷺ:
${hadith.hadith_text}

• الراوي: ${hadith.narrator}
• المصدر: ${hadith.source} - ${hadith.book} (رقم: ${hadith.hadith_number})
• درجة الحديث: ${hadith.authenticity_grade}

تطبيق «ليه قالها؟» - كل حديث قصة قبل أن يكون كلمة`;

    if (language === 'en') {
      textToCopy = `The Messenger of Allah ﷺ said:
${hadith.hadith_text}

• Narrator: ${hadith.narrator}
• Source: ${hadith.source} (#${hadith.hadith_number})
• Grade: ${hadith.authenticity_grade}

App: Why Did He Say It?`;
    } else if (language === 'ur') {
      textToCopy = `رسول اللہ ﷺ نے فرمایا:
${hadith.hadith_text}

• راوی: ${hadith.narrator}
• ماخذ: ${hadith.source} (نمبر: ${hadith.hadith_number})
• درجہ: ${hadith.authenticity_grade}

ایپ: کیوں فرمایا؟`;
    } else if (language === 'fa') {
      textToCopy = `رسول خدا ﷺ فرمودند:
${hadith.hadith_text}

• راوی: ${hadith.narrator}
• منبع: ${hadith.source} (شماره: ${hadith.hadith_number})
• درجه: ${hadith.authenticity_grade}

برنامه: چرا فرمود؟`;
    }

    try {
      await navigator.clipboard.writeText(textToCopy);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // Fallback
    }
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${t('hadithDetailTitle')}: ${hadith.topic}`,
          text: `${hadith.hadith_text}\n\n${t('appTitle')}`,
          url: window.location.href,
        });
      } catch {
        // Cancelled
      }
    } else {
      handleCopyText();
    }
  };

  const handleDownloadImage = () => {
    setDownloading(true);
    try {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      canvas.width = 1080;
      canvas.height = 1350;

      // Draw background
      const grad = ctx.createLinearGradient(0, 0, 0, canvas.height);
      grad.addColorStop(0, '#FDFBF7');
      grad.addColorStop(0.6, '#F8F3E8');
      grad.addColorStop(1, '#EFE5D3');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Borders
      ctx.strokeStyle = 'rgba(212, 175, 55, 0.6)';
      ctx.lineWidth = 14;
      ctx.strokeRect(30, 30, canvas.width - 60, canvas.height - 60);

      ctx.strokeStyle = 'rgba(212, 175, 55, 0.3)';
      ctx.lineWidth = 2;
      ctx.strokeRect(48, 48, canvas.width - 96, canvas.height - 96);

      // Title
      ctx.fillStyle = '#9C7A28';
      ctx.font = 'bold 36px "Amiri", serif';
      ctx.textAlign = 'center';
      ctx.fillText('﷽', canvas.width / 2, 110);

      ctx.fillStyle = '#78350F';
      ctx.font = 'bold 28px sans-serif';
      ctx.fillText(language === 'en' ? 'Prophetic Hadith' : 'قال رسول الله ﷺ:', canvas.width / 2, 160);

      // Hadith Text
      ctx.fillStyle = '#0F172A';
      ctx.font = 'bold 36px "Amiri", serif';
      const words = hadith.hadith_text.split(' ');
      let line = '';
      let y = 280;
      const maxWidth = 900;
      const lineHeight = 58;

      for (let n = 0; n < words.length; n++) {
        const testLine = line + words[n] + ' ';
        const metrics = ctx.measureText(testLine);
        if (metrics.width > maxWidth && n > 0) {
          ctx.fillText(line, canvas.width / 2, y);
          line = words[n] + ' ';
          y += lineHeight;
        } else {
          line = testLine;
        }
      }
      ctx.fillText(line, canvas.width / 2, y);

      // Info
      const infoY = Math.max(y + 90, 1050);
      ctx.fillStyle = '#475569';
      ctx.font = '500 24px sans-serif';
      ctx.fillText(`${t('narratorLabel')} ${hadith.narrator}`, canvas.width / 2, infoY);
      ctx.fillText(`${t('sourceLabel')} ${hadith.source} · ${hadith.authenticity_grade}`, canvas.width / 2, infoY + 40);

      // Footer
      ctx.fillStyle = '#B45309';
      ctx.font = 'bold 32px sans-serif';
      ctx.fillText(t('appTitle'), canvas.width / 2, canvas.height - 90);
      ctx.fillStyle = '#64748B';
      ctx.font = '20px sans-serif';
      ctx.fillText(t('appSubtitle'), canvas.width / 2, canvas.height - 52);

      const link = document.createElement('a');
      link.download = `hadith-${hadith.id}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    } catch (e) {
      console.warn('Canvas export error:', e);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn select-none">
      <div className="relative w-full max-w-md bg-[#131B2E] border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800 bg-[#0D131F]">
          <h3 className="text-sm font-bold text-slate-200">
            {t('shareHadith')}
          </h3>
          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-slate-800/80 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
            title={t('close')}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Card Preview */}
        <div className="p-4 overflow-y-auto flex-1 flex flex-col items-center">
          <div
            ref={cardRef}
            className="w-full rounded-2xl p-6 relative shadow-xl overflow-hidden border-2 border-[#D4AF37]/50"
            style={{
              background: 'linear-gradient(180deg, #FDFBF7 0%, #F8F3E8 60%, #EFE5D3 100%)',
              color: '#1E293B'
            }}
          >
            <div className="absolute inset-2 border border-[#D4AF37]/30 rounded-xl pointer-events-none" />
            <div className="absolute top-3 right-3 text-[#B38B29] text-xs font-serif opacity-70">✤</div>
            <div className="absolute top-3 left-3 text-[#B38B29] text-xs font-serif opacity-70">✤</div>

            <div className="text-center mb-3">
              <span className="text-[#9C7A28] text-xs font-serif block mb-0.5">﷽</span>
              <span className="text-xs font-bold text-amber-800/80 tracking-wide">
                {language === 'en' ? 'The Messenger of Allah ﷺ said:' : 'قال رسول الله ﷺ:'}
              </span>
            </div>

            <div className="text-center px-2 my-4">
              <p className="font-hadith text-lg leading-relaxed font-bold text-slate-900 select-all">
                {hadith.hadith_text}
              </p>
            </div>

            <div className="flex items-center justify-center my-3 gap-2 opacity-50">
              <div className="h-px w-16 bg-[#D4AF37]" />
              <span className="text-[#D4AF37] text-xs">◆</span>
              <div className="h-px w-16 bg-[#D4AF37]" />
            </div>

            <div className="text-xs text-slate-600 space-y-1 text-center font-medium">
              <p>{t('narratorLabel')} <span className="text-slate-900">{hadith.narrator}</span></p>
              <p>{t('sourceLabel')} <span className="text-slate-900">{hadith.source}</span> ({hadith.book})</p>
              <p className="text-[11px] text-slate-500">
                {t('hadithNumber')}{hadith.hadith_number} · {t('gradeLabel')} <span className="text-emerald-700 font-semibold">{hadith.authenticity_grade}</span>
              </p>
            </div>

            <div className="mt-5 pt-3 border-t border-[#D4AF37]/20 flex flex-col items-center justify-center">
              <span className="text-amber-800 font-bold text-sm">{t('appTitle')}</span>
              <span className="text-[10px] text-slate-500">{t('appSubtitle')}</span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="p-4 bg-[#0D131F] border-t border-slate-800 grid grid-cols-3 gap-2">
          <button
            onClick={handleDownloadImage}
            disabled={downloading}
            className="flex items-center justify-center gap-1.5 py-3 px-3 rounded-xl bg-[#E2B773] text-[#0D131F] font-bold text-xs hover:bg-[#d4a861] active:scale-95 transition-all shadow-md"
          >
            <Download className="w-4 h-4" />
            <span>{downloading ? '...' : (language === 'en' ? 'Save Card' : 'حفظ الصورة')}</span>
          </button>

          <button
            onClick={handleCopyText}
            className="flex items-center justify-center gap-1.5 py-3 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs active:scale-95 transition-all"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? t('copied') : (language === 'en' ? 'Copy Text' : 'نسخ النص')}</span>
          </button>

          <button
            onClick={handleNativeShare}
            className="flex items-center justify-center gap-1.5 py-3 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs active:scale-95 transition-all"
          >
            <Share2 className="w-4 h-4" />
            <span>{t('share')}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
