import React, { useState } from 'react';
import {
  X,
  Heart,
  Share2,
  Sparkles,
  BookOpen,
  Check,
  Flame,
  Award
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface AboutAppModalProps {
  onClose: () => void;
}

export const AboutAppModal: React.FC<AboutAppModalProps> = ({ onClose }) => {
  const { t, language, isRtl } = useLanguage();
  const [prayedBlessing, setPrayedBlessing] = useState(false);

  const handlePrayDuaa = () => {
    setPrayedBlessing(true);
  };

  const shareTextMap: Record<string, string> = {
    ar: 'تطبيق «ليه قالها؟» – كل يوم قصة وحديث للنبي ﷺ ❤️\nتطبيق خيري مجاني يضم أكثر من 2000 حديث صحيح مع أسباب ورودها وسياقها التاريخي ومشاهد تفاعلية وصوتية هادئة.\nشاركونا الأجر ونشر سنة النبي ﷺ:',
    en: '"Why Did He Say It?" App – Every day a story and Hadith of the Prophet ﷺ ❤️\nA free non-profit app with 2000+ authentic Hadiths, their historical context, interactive scenes, and calm audio.\nShare the reward and spread the Sunnah:',
    ur: 'ایپ «کیوں فرمایا؟» – ہر روز نبی کریم ﷺ کی ایک حدیث اور اس کا واقعہ ❤️\nایک مفت اور خیراتی ایپ جس میں ۲۰۰۰+ صحیح احادیث، ان کے اسبابِ ورود اور تاریخی پس منظر شامل ہیں۔\nنیکی کو عام کرنے میں شریک بنیں:',
    fa: 'برنامه «چرا فرمود؟» – هر روز یک داستان و حدیث از پیامبر اکرم ﷺ ❤️\nبرنامه‌ای کاملاً خیریه و رایگان شامل بیش از ۲۰۰۰ حدیث صحیح با بیان شأن ورود و بستر تاریخی.\nدر نشر سنت نبوی سهیم باشید:'
  };

  const handleShareApp = async () => {
    const text = shareTextMap[language] || shareTextMap.ar;
    if (navigator.share) {
      try {
        await navigator.share({
          title: t('appTitle'),
          text,
          url: window.location.href
        });
      } catch {
        // Cancelled
      }
    } else {
      try {
        await navigator.clipboard.writeText(`${text}\n${window.location.href}`);
        alert(t('copied'));
      } catch {
        // Fallback
      }
    }
  };

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn select-none ${isRtl ? 'dir-rtl' : 'dir-ltr'}`}>
      <div className="relative w-full max-w-md bg-[#131B2E] border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-[#0D131F]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-[#E2B773]/20 flex items-center justify-center text-[#E2B773]">
              <Heart className="w-4 h-4 fill-current text-rose-500" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white leading-tight">{t('about')}</h2>
              <p className="text-[11px] text-[#E2B773] font-medium">{t('charitableSub')}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-5 text-start">
          {/* Main Title & Slogan */}
          <div className="text-center pb-1 border-b border-slate-800/80">
            <span className="text-xl font-extrabold text-[#E2B773] block mb-1">
              {t('appTitle')}
            </span>
            <p className="text-sm font-bold text-slate-200 flex items-center justify-center gap-1.5">
              <span>{t('appSubtitle')}</span>
              <span className="text-rose-400">❤️</span>
            </p>
          </div>

          {/* Description */}
          <div className="p-4 rounded-2xl bg-[#0D131F] border border-slate-800 text-xs sm:text-sm text-slate-300 leading-relaxed space-y-2">
            <p>
              {t('charitableNotice')}
            </p>
          </div>

          {/* Feature Highlights Points */}
          <div className="grid grid-cols-1 gap-2 text-xs">
            <div className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-900/60 border border-slate-800/80">
              <span className="text-base">📖</span>
              <span className="font-semibold text-slate-200">{t('highlightsAuthentic')}</span>
            </div>
            <div className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-900/60 border border-slate-800/80">
              <span className="text-base">📚</span>
              <span className="font-semibold text-slate-200">{t('highlightsScenes')}</span>
            </div>
            <div className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-900/60 border border-slate-800/80">
              <span className="text-base">💡</span>
              <span className="font-semibold text-slate-200">{t('highlightsCalmAudio')}</span>
            </div>
            <div className="flex items-center gap-2.5 p-2.5 rounded-xl bg-slate-900/60 border border-slate-800/80">
              <span className="text-base">❤️</span>
              <span className="font-semibold text-slate-200">{t('highlightsCards')}</span>
            </div>
          </div>

          {/* Charitable Dedication Banner */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/10 via-[#E2B773]/10 to-amber-500/10 border border-[#E2B773]/30 text-xs text-slate-300 leading-relaxed space-y-2">
            <p className="font-bold text-[#E2B773] text-sm flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-[#E2B773]" />
              <span>{t('charitableBannerTitle')}</span>
            </p>
            <p>
              {t('charitableBannerSub')}
            </p>
          </div>

          {/* Du'aa Box with Interactive Response */}
          <div className="p-4 rounded-2xl bg-[#0D131F] border border-slate-800 text-center space-y-3">
            <p className="text-sm sm:text-base text-slate-100 font-bold leading-relaxed">
              {language === 'en'
                ? '«O Allah, make this work purely for Your Noble Face, and benefit all who use it or share it.»'
                : language === 'ur'
                ? '«اے اللہ اس عمل کو اپنی رضا کے لیے خالص فرما، اور ہر اس شخص کو نفع پہنچا جو اسے پڑھے یا آگے پھیلائے۔»'
                : language === 'fa'
                ? '«خدایا این خدمت را خالصانه برای رضای خود قرار ده و هر که از آن بهره می‌برد را مشمول برکت فرما.»'
                : '«اللهم اجعل هذا العمل خالصًا لوجهك الكريم، وانفع به كل من استخدمه أو نشره أو علّم به غيره»'}
            </p>

            {prayedBlessing ? (
              <div className="py-2.5 px-4 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center justify-center gap-2 animate-fadeIn">
                <Check className="w-4 h-4" />
                <span>
                  {language === 'en'
                    ? 'May Allah reward you with goodness and accept your prayers ❤️'
                    : language === 'ur'
                    ? 'جزاک اللہ خیراً، اللہ تعالیٰ آپ کی دعا قبول فرمائے ❤️'
                    : language === 'fa'
                    ? 'خداوند به شما جزای خیر دهد و دعایتان را مستجاب فرماید ❤️'
                    : 'جزاك الله خيراً، وتقبل الله دعاءك ولك بالمثل وزيادة ❤️'}
                </span>
              </div>
            ) : (
              <button
                onClick={handlePrayDuaa}
                className="py-2 px-5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/30 text-rose-300 font-bold text-xs flex items-center justify-center gap-1.5 mx-auto active:scale-95 transition-all"
              >
                <Heart className="w-3.5 h-3.5 fill-current text-rose-400" />
                <span>
                  {language === 'en'
                    ? 'I prayed for you ❤️'
                    : language === 'ur'
                    ? 'میں نے آپ کے لیے دعا کی ❤️'
                    : language === 'fa'
                    ? 'برای شما دعا کردم ❤️'
                    : 'دعوتُ لكم بظهر الغيب ❤️'}
                </span>
              </button>
            )}
          </div>

          {/* Share App Action */}
          <div className="pt-1">
            <button
              onClick={handleShareApp}
              className="w-full py-3 rounded-2xl bg-[#E2B773] hover:bg-[#d4a861] text-[#0D131F] font-black text-xs flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-all"
            >
              <Share2 className="w-4 h-4" />
              <span>{t('share')}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
