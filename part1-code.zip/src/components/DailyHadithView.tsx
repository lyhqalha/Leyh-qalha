import React, { useState } from 'react';
import { HadithItem } from '../types/hadith';
import { desertHeroImage } from '../data/hadiths';
import { HadithReciterPlayer } from './HadithReciterPlayer';
import { getDailyHadith, formatArabicDate } from '../utils/dailyHadith';
import { useLanguage } from '../context/LanguageContext';
import { Sparkles, Calendar, BookOpen, ChevronRight, ChevronLeft, Play } from 'lucide-react';

interface DailyHadithViewProps {
  hadiths: HadithItem[];
  onOpenStory: (hadith: HadithItem) => void;
  onOpenDetail: (hadith: HadithItem) => void;
}

export const DailyHadithView: React.FC<DailyHadithViewProps> = ({
  hadiths,
  onOpenStory,
  onOpenDetail,
}) => {
  const { t, language, isRtl } = useLanguage();
  const [dayOffset, setDayOffset] = useState(0);

  // Pick hadith dynamically based on the exact calendar date
  const targetDate = new Date();
  targetDate.setDate(targetDate.getDate() + dayOffset);
  const hadith = getDailyHadith(hadiths, targetDate);
  const formattedDate = formatArabicDate(targetDate, language);

  return (
    <div className="w-full min-h-screen bg-[#0D131F] text-slate-100 p-4 pb-28 max-w-xl mx-auto flex flex-col items-center">
      {/* Top Header & Date Navigation */}
      <div className="w-full text-center mb-4">
        <h2 className="text-xl font-bold text-white mb-1">{t('dailyHadithHeading')}</h2>
        
        {/* Date Selector Row */}
        <div className="flex items-center justify-center gap-3 mt-2">
          <button
            onClick={() => setDayOffset(prev => prev + 1)}
            disabled={dayOffset >= 0}
            className={`p-1.5 rounded-full bg-slate-800 transition-colors ${
              dayOffset >= 0 ? 'text-slate-600 cursor-not-allowed' : 'text-slate-300 hover:text-white'
            }`}
            title={t('nextDay')}
          >
            {isRtl ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>

          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#131B2E] border border-slate-800 text-xs text-[#E2B773] font-medium">
            <Calendar className="w-3.5 h-3.5" />
            <span>{formattedDate}</span>
          </div>

          <button
            onClick={() => setDayOffset(prev => prev - 1)}
            className="p-1.5 rounded-full bg-slate-800 text-slate-300 hover:text-white transition-colors"
            title={t('prevDay')}
          >
            {isRtl ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Featured Artwork & Context */}
      <div className="relative w-full rounded-3xl overflow-hidden border border-slate-800 shadow-2xl bg-[#131B2E] mb-4">
        <div className="relative w-full h-48 overflow-hidden">
          <img
            src={desertHeroImage}
            alt={hadith.topic}
            className="w-full h-full object-cover filter brightness-[0.7]"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#131B2E] via-transparent to-transparent" />
          
          <div className="absolute bottom-3 right-3 left-3 flex items-center justify-between">
            <span className="px-3 py-1 rounded-full bg-[#E2B773] text-[#0D131F] text-xs font-bold shadow">
              {hadith.topic}
            </span>
            <span className="text-xs text-slate-300 font-mono">
              #{hadith.hadith_number}
            </span>
          </div>
        </div>

        <div className="p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="text-xs text-[#E2B773] font-bold flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{t('dailyParchmentTitle')}</span>
            </span>
            <span className="text-xs text-slate-400">{hadith.narrator}</span>
          </div>

          {/* Audio Reciter Player */}
          <HadithReciterPlayer
            hadithText={hadith.hadith_text}
            hadithId={hadith.id}
            narrator={hadith.narrator}
            source={hadith.source}
            variant="card"
            showText={true}
          />

          <p className="text-xs text-slate-400 leading-relaxed">
            {hadith.context}
          </p>

          <div className="flex items-center gap-3 pt-2">
            <button
              onClick={() => onOpenStory(hadith)}
              className="flex-1 py-3 px-4 rounded-xl bg-[#E2B773] hover:bg-[#d4a861] text-[#0D131F] text-xs font-black flex items-center justify-center gap-2 shadow-md transition-all active:scale-95"
            >
              <Play className="w-4 h-4 fill-current ml-0.5" />
              <span>{t('listenStory')}</span>
            </button>

            <button
              onClick={() => onOpenDetail(hadith)}
              className="py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center justify-center gap-1.5 border border-slate-700 transition-all"
            >
              <BookOpen className="w-4 h-4" />
              <span>{t('hadithFullPage')}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
