import React, { useState } from 'react';
import { HadithItem } from '../types/hadith';
import { HadithReciterPlayer } from './HadithReciterPlayer';
import { useLanguage } from '../context/LanguageContext';
import { getLocalizedCategories } from '../utils/hadithLocalization';
import {
  MessageSquareHeart,
  ShieldCheck,
  UsersRound,
  Compass,
  Moon,
  Flame,
  RotateCcw,
  BookOpen,
  Heart,
  Smile,
  Users,
  Sparkles,
  Award,
  GraduationCap,
  Sparkle,
  Navigation,
  Coins,
  HandHeart,
  ArrowRight,
  ArrowLeft
} from 'lucide-react';

interface CategoriesViewProps {
  hadiths: HadithItem[];
  onSelectCategoryHadith: (hadith: HadithItem) => void;
  onOpenStory: (hadith: HadithItem) => void;
}

export const CategoriesView: React.FC<CategoriesViewProps> = ({
  hadiths,
  onSelectCategoryHadith,
  onOpenStory,
}) => {
  const { t, language, isRtl } = useLanguage();
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [categoryVisibleCount, setCategoryVisibleCount] = useState<number>(30);

  const categories = getLocalizedCategories(language);

  // Helper icon mapper
  const renderIcon = (iconName: string) => {
    const props = { className: "w-6 h-6 text-[#E2B773]" };
    switch (iconName) {
      case 'MessageSquareHeart': return <MessageSquareHeart {...props} />;
      case 'ShieldCheck': return <ShieldCheck {...props} />;
      case 'UsersRound': return <UsersRound {...props} />;
      case 'Hands': return <HandHeart {...props} />;
      case 'Smile': return <Smile {...props} />;
      case 'Sparkles': return <Sparkles {...props} />;
      case 'Sparkle': return <Sparkle {...props} />;
      case 'Users': return <Users {...props} />;
      case 'Compass': return <Compass {...props} />;
      case 'Moon': return <Moon {...props} />;
      case 'Flame': return <Flame {...props} />;
      case 'RotateCcw': return <RotateCcw {...props} />;
      case 'BookOpen': return <BookOpen {...props} />;
      case 'Heart': return <Heart {...props} />;
      case 'Award': return <Award {...props} />;
      case 'GraduationCap': return <GraduationCap {...props} />;
      case 'Coins': return <Coins {...props} />;
      case 'Navigation': return <Navigation {...props} />;
      default: return <HandHeart {...props} />;
    }
  };

  const selectedCategoryObj = categories.find(c => c.name === selectedCategory || c.id === selectedCategory);
  const matchingHadiths = selectedCategory
    ? hadiths.filter(
        h =>
          h.topic === selectedCategory ||
          h.topic.includes(selectedCategory) ||
          selectedCategory.includes(h.topic) ||
          h.keywords.some(k => k.includes(selectedCategory) || selectedCategory.includes(k))
      )
    : [];

  const paginatedCategoryHadiths = matchingHadiths.slice(0, categoryVisibleCount);

  return (
    <div className="w-full min-h-screen bg-[#0D131F] text-slate-100 p-4 pb-28 max-w-xl mx-auto">
      {/* If a category is selected, show its Hadiths list */}
      {selectedCategory ? (
        <div className="space-y-4 animate-fadeIn">
          {/* Header */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <button
              onClick={() => {
                setSelectedCategory(null);
                setCategoryVisibleCount(30);
              }}
              className="inline-flex items-center gap-2 text-xs font-bold text-slate-300 hover:text-white"
            >
              {isRtl ? <ArrowRight className="w-4 h-4" /> : <ArrowLeft className="w-4 h-4" />}
              <span>{t('backToCategories')}</span>
            </button>
            <span className="text-sm font-bold text-[#E2B773]">
              {selectedCategory} ({t('hadithsCount', { count: matchingHadiths.length })})
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-[#131B2E] border border-slate-800 text-xs text-slate-400">
            {selectedCategoryObj?.description || selectedCategory}
          </div>

          {matchingHadiths.length === 0 ? (
            <div className="text-center py-12 px-4 rounded-3xl bg-[#131B2E] border border-slate-800">
              <p className="text-sm text-slate-400">{t('hadithsCount', { count: 0 })}</p>
            </div>
          ) : (
            <div className="space-y-3">
              {paginatedCategoryHadiths.map((h) => (
                <div
                  key={h.id}
                  className="p-4 rounded-2xl bg-[#131B2E] border border-slate-800 hover:border-slate-700 transition-all space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-[#E2B773]">{h.topic}</span>
                    <span className="text-[10px] text-slate-400 font-mono">#{h.hadith_number}</span>
                  </div>

                  {/* Audio reciter player with text */}
                  <HadithReciterPlayer
                    hadithText={h.hadith_text}
                    hadithId={h.id}
                    narrator={h.narrator}
                    source={h.source}
                    variant="card"
                    showText={true}
                  />

                  <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-[11px] text-slate-400">
                    <span>{h.narrator}</span>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onOpenStory(h)}
                        className="text-xs text-[#E2B773] hover:underline font-bold"
                      >
                        {t('listenStory')}
                      </button>
                      <button
                        onClick={() => onSelectCategoryHadith(h)}
                        className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-bold"
                      >
                        {t('hadithFullPage')}
                      </button>
                    </div>
                  </div>
                </div>
              ))}

              {categoryVisibleCount < matchingHadiths.length && (
                <div className="pt-2 flex justify-center">
                  <button
                    onClick={() => setCategoryVisibleCount(prev => prev + 30)}
                    className="w-full py-3 rounded-2xl bg-[#131B2E] border border-slate-800 hover:border-[#E2B773]/40 text-xs font-bold text-[#E2B773] transition-all flex items-center justify-center gap-2 active:scale-95 shadow-md"
                  >
                    <span>{categoryVisibleCount} / {matchingHadiths.length}</span>
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      ) : (
        <div>
          {/* Main Categories Grid */}
          <h2 className="text-xl font-bold text-center text-white mb-1">
            {t('categoriesTitle')}
          </h2>
          <p className="text-xs text-center text-slate-400 mb-5">
            {t('categoriesSub')}
          </p>

          <div className="grid grid-cols-3 sm:grid-cols-3 gap-3">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.name)}
                className="flex flex-col items-center justify-center p-4 rounded-2xl bg-[#131B2E] border border-slate-800 hover:border-[#E2B773]/50 hover:bg-[#1a233a] active:scale-95 transition-all text-center group"
              >
                <div className="w-12 h-12 rounded-2xl bg-[#1E293B] group-hover:bg-[#E2B773]/15 flex items-center justify-center mb-2.5 transition-colors">
                  {renderIcon(category.iconName)}
                </div>
                <span className="text-xs font-bold text-slate-200 group-hover:text-white mb-1">
                  {category.name}
                </span>
                <span className="text-[10px] text-slate-400">
                  {t('hadithsCount', { count: category.count })}
                </span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
