import React from 'react';
import { ReadingStats, getWeeklyActivity, getBadges } from '../utils/readingTracker';
import { useLanguage } from '../context/LanguageContext';
import {
  X,
  Flame,
  BookOpen,
  Award,
  Sparkles,
  Volume2,
  GraduationCap,
  CheckCircle2,
  Share2,
  Calendar,
  TrendingUp,
  Heart
} from 'lucide-react';

interface UserStatsModalProps {
  stats: ReadingStats;
  totalHadithsCount?: number;
  onClose: () => void;
  onOpenAbout?: () => void;
}

export const UserStatsModal: React.FC<UserStatsModalProps> = ({
  stats,
  totalHadithsCount = 2000,
  onClose,
  onOpenAbout
}) => {
  const { t, language, isRtl } = useLanguage();
  const weekly = getWeeklyActivity(stats.activeDates);
  const badges = getBadges(stats);
  const percentComplete = ((stats.readHadithIds.length / totalHadithsCount) * 100).toFixed(1);

  // Motivational quote based on streak
  const getStreakMessage = (streak: number) => {
    if (language === 'en') {
      if (streak === 0) return 'Read today’s Hadith to start your daily streak!';
      if (streak === 1) return 'Blessed start! Return tomorrow to keep the streak going.';
      if (streak < 3) return 'MashaAllah! A wonderful step to deepen your bond with the Sunnah.';
      if (streak < 7) return 'Great devotion! The most beloved deeds to Allah are those that are consistent.';
      if (streak < 14) return 'A full week of Prophetic guidance! May Allah keep you steadfast.';
      return 'MashaAllah TabarakAllah! May Allah reward your noble perseverance.';
    }
    if (language === 'ur') {
      if (streak === 0) return 'روزانہ حدیث پڑھ کر اپنے مطالعے کا تسلسل شروع کریں!';
      if (streak === 1) return 'مبارک شروعات! کل دوبارہ تشریف لا کر سلسلہ برقرار رکھیں۔';
      if (streak < 3) return 'ماشاء اللہ! سنت نبوی سے تعلق کو مضبوط کرنے کا بہترین اقدام۔';
      if (streak < 7) return 'اللہ تعالیٰ کو وہ عمل سب سے پسند ہے جو ہمیشگی سے کیا جائے۔';
      return 'ماشاء اللہ تبارک اللہ! سنت کی پیروی پر اللہ تعالیٰ آپ کو جزائے خیر عطا فرمائے۔';
    }
    if (language === 'fa') {
      if (streak === 0) return 'با مطالعه حدیث امروز، زنجیره یادگیری روزانه خود را آغاز کنید!';
      if (streak === 1) return 'شروع مبارکی است! فردا هم بازگردید تا این زنجیره حفظ شود.';
      if (streak < 3) return 'ماشاءالله! گامی زیبا در جهت آشنایی با سیره مطهر نبوی.';
      return 'ماشاءالله تبارک‌الله! خداوند این توفیق مداوم را بر شما مبارک گرداند.';
    }
    if (streak === 0) return 'ابدأ قراءة حديث اليوم لتشعل شعلة الالتزام بسنة النبي ﷺ!';
    if (streak === 1) return 'بداية مباركة! عُد غداً لتحافظ على استمرار السلسلة.';
    if (streak < 3) return 'ما شاء الله! خطوة رائعة نحو تعميق صلتك بسيرة المصطفى ﷺ.';
    if (streak < 7) return 'همة عالية! أحب الأعمال إلى الله أدومها وإن قل.';
    if (streak < 14) return 'أسبوع كامل من الهدى النبوي! تقبل الله منك وثبتك.';
    return 'ما شاء الله تبارك الله! ثبات واقتداء مبارك، هنيئاً لك هذا الأجر.';
  };

  const handleShareStreak = async () => {
    const textMap: Record<string, string> = {
      ar: `أنا ملتزم بقراءة أحاديث النبي ﷺ عبر تطبيق «ليه قالها؟» وسلسلة قراءتي وصلت إلى ${stats.currentStreak} أيام متتالية 🔥\nشاركوني هذه الرحلة الإيمانية المباركة!`,
      en: `I am maintaining my daily Prophetic Hadiths reading with "Why Did He Say It?" app – streak reached ${stats.currentStreak} consecutive days! 🔥`,
      ur: `میں روزانہ «کیوں فرمایا؟» ایپ کے ذریعے احادیث نبوی پڑھ رہا ہوں اور میرا سلسلہ ${stats.currentStreak} دن تک پہنچ چکا ہے! 🔥`,
      fa: `من با برنامه «چرا فرمود؟» هر روز احادیث نبوی را می‌خوانم و زنجیره مطالعه‌ام به ${stats.currentStreak} روز متوالی رسیده است! 🔥`
    };
    const text = textMap[language] || textMap.ar;

    if (navigator.share) {
      try {
        await navigator.share({
          title: t('stats'),
          text
        });
      } catch {
        // User cancelled
      }
    } else {
      try {
        await navigator.clipboard.writeText(text);
        alert(t('copied'));
      } catch {
        // Fallback
      }
    }
  };

  return (
    <div className={`fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn select-none ${isRtl ? 'dir-rtl' : 'dir-ltr'}`}>
      <div className="relative w-full max-w-md bg-[#131B2E] border border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-[#0D131F]">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-amber-500/20 flex items-center justify-center text-[#E2B773]">
              <Flame className="w-4 h-4 fill-current text-amber-500" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white leading-tight">{t('stats')}</h2>
              <p className="text-[11px] text-slate-400">{t('statsBoard')}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Scrollable Content */}
        <div className="p-5 overflow-y-auto space-y-4 text-start">
          {/* Main Streak Card */}
          <div className="relative rounded-2xl p-5 bg-gradient-to-br from-[#1E293B] via-[#162032] to-[#0D131F] border border-amber-500/30 overflow-hidden shadow-lg">
            <div className="absolute top-0 left-0 w-32 h-32 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center">
                  <Flame className="w-6 h-6 text-amber-500 fill-current animate-pulse" />
                </div>
                <div>
                  <span className="text-xs text-slate-400 block font-medium">{t('streakTitle')}</span>
                  <span className="text-2xl font-black text-white font-mono flex items-baseline gap-1">
                    {stats.currentStreak}
                    <span className="text-xs font-normal text-amber-400">
                      {language === 'en' ? 'days' : language === 'ur' ? 'دن' : language === 'fa' ? 'روز' : 'يوم متتالٍ'}
                    </span>
                  </span>
                </div>
              </div>

              {/* Best Streak Badge */}
              <div className="text-center bg-black/40 px-3 py-1.5 rounded-xl border border-white/5">
                <span className="text-[10px] text-slate-400 block">
                  {language === 'en' ? 'Best Streak' : language === 'ur' ? 'بہترین تسلسل' : language === 'fa' ? 'بهترین زنجیره' : 'أعلى سلسلة'}
                </span>
                <span className="text-xs font-bold text-amber-300 font-mono">
                  {stats.bestStreak} {language === 'en' ? 'days' : language === 'ur' ? 'دن' : language === 'fa' ? 'روز' : 'يوم'}
                </span>
              </div>
            </div>

            {/* Motivational Banner */}
            <p className="text-xs text-slate-300 font-medium leading-relaxed bg-black/30 p-2.5 rounded-xl border border-white/5">
              {getStreakMessage(stats.currentStreak)}
            </p>

            {/* Weekly Activity Tracker Row (7 days) */}
            <div className="mt-4 pt-3 border-t border-slate-700/60">
              <div className="flex items-center justify-between text-[11px] text-slate-400 mb-2">
                <span className="flex items-center gap-1">
                  <Calendar className="w-3 h-3 text-[#E2B773]" />
                  <span>
                    {language === 'en' ? 'Activity in last 7 days' : language === 'ur' ? 'پچھلے ۷ دنوں کی سرگرمی' : language === 'fa' ? 'فعالیت در ۷ روز گذشته' : 'نشاطك خلال آخر 7 أيام'}
                  </span>
                </span>
                <span className="text-amber-400 font-medium">
                  {weekly.filter(w => w.isCompleted).length} / 7 {language === 'en' ? 'days' : language === 'ur' ? 'دن' : language === 'fa' ? 'روز' : 'أيام'}
                </span>
              </div>

              <div className="grid grid-cols-7 gap-1.5">
                {weekly.map((day, idx) => (
                  <div
                    key={idx}
                    className={`flex flex-col items-center justify-center py-2 rounded-xl text-center transition-all ${
                      day.isCompleted
                        ? 'bg-amber-500/20 border border-amber-500/50 text-amber-300 font-bold'
                        : day.isToday
                        ? 'bg-slate-800/80 border border-slate-600 text-slate-300'
                        : 'bg-black/30 border border-slate-800 text-slate-500'
                    }`}
                  >
                    <span className="text-[10px] leading-tight mb-1">{day.dayName.slice(0, 3)}</span>
                    {day.isCompleted ? (
                      <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 fill-amber-400/20" />
                    ) : (
                      <div className="w-2 h-2 rounded-full bg-slate-700" />
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Core Numbers 3-Column Grid */}
          <div className="grid grid-cols-3 gap-2.5">
            <div className="p-3 rounded-2xl bg-[#0D131F] border border-slate-800 text-center flex flex-col items-center">
              <BookOpen className="w-4 h-4 text-[#E2B773] mb-1" />
              <span className="text-lg font-black text-white font-mono">{stats.readHadithIds.length}</span>
              <span className="text-[10px] text-slate-400">
                {language === 'en' ? 'Read' : language === 'ur' ? 'پڑھی گئیں' : language === 'fa' ? 'خوانده‌شده' : 'حديث مقروء'}
              </span>
            </div>

            <div className="p-3 rounded-2xl bg-[#0D131F] border border-slate-800 text-center flex flex-col items-center">
              <Volume2 className="w-4 h-4 text-emerald-400 mb-1" />
              <span className="text-lg font-black text-white font-mono">{stats.listenedCount}</span>
              <span className="text-[10px] text-slate-400">
                {language === 'en' ? 'Listened' : language === 'ur' ? 'سنی گئیں' : language === 'fa' ? 'شنیده‌شده' : 'قصة مستمعة'}
              </span>
            </div>

            <div className="p-3 rounded-2xl bg-[#0D131F] border border-slate-800 text-center flex flex-col items-center">
              <TrendingUp className="w-4 h-4 text-sky-400 mb-1" />
              <span className="text-lg font-black text-white font-mono">%{percentComplete}</span>
              <span className="text-[10px] text-slate-400">
                {language === 'en' ? 'of 2000' : language === 'ur' ? 'از ۲۰۰۰' : language === 'fa' ? 'از ۲۰۰۰' : 'من الـ 2000'}
              </span>
            </div>
          </div>

          {/* Hadiths Reading Progress Bar */}
          <div className="p-4 rounded-2xl bg-[#0D131F] border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-slate-300 font-bold flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#E2B773]" />
                <span>
                  {language === 'en' ? 'Total Hadiths Read' : language === 'ur' ? 'کل پڑھی گئی احادیث' : language === 'fa' ? 'مجموع احادیث خوانده‌شده' : 'إجمالي الأحاديث المقروءة'}
                </span>
              </span>
              <span className="text-[#E2B773] font-mono font-bold">
                {stats.readHadithIds.length} / {totalHadithsCount}
              </span>
            </div>

            <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden p-0.5">
              <div
                className="h-full bg-gradient-to-r from-amber-600 via-[#E2B773] to-amber-300 rounded-full transition-all duration-700"
                style={{ width: `${Math.max(2, Math.min(100, (stats.readHadithIds.length / totalHadithsCount) * 100))}%` }}
              />
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-2 flex flex-col gap-2">
            <button
              onClick={handleShareStreak}
              className="w-full py-3 rounded-2xl bg-[#E2B773] hover:bg-[#d4a861] text-[#0D131F] font-black text-xs flex items-center justify-center gap-2 shadow-lg active:scale-95 transition-all"
            >
              <Share2 className="w-4 h-4" />
              <span>{t('share')}</span>
            </button>

            {onOpenAbout && (
              <button
                onClick={() => {
                  onClose();
                  onOpenAbout();
                }}
                className="w-full py-2.5 rounded-2xl bg-[#0D131F] border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-all"
              >
                <Heart className="w-3.5 h-3.5 text-rose-400" />
                <span>{t('about')}</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
