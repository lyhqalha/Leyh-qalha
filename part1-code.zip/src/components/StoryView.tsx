import React, { useState, useEffect, useRef } from 'react';
import { HadithItem, StoryScene } from '../types/hadith';
import { audioEngine, cleanStoryContentForSpeech } from '../utils/audioService';
import { ambientEngine, detectAmbientContext, AMBIENT_PRESETS } from '../utils/ambientSoundService';
import {
  desertHeroImage,
  companionsStoryImage,
  mosqueMinaretImage,
  prophetCourtyardImage,
  nightDesertStarsImage
} from '../data/hadiths';
import { HadithReciterPlayer } from './HadithReciterPlayer';
import { OfflineDownloadButton } from './OfflineDownloadButton';
import { useLanguage } from '../context/LanguageContext';
import { hasPrepackagedAudio } from '../data/offlineHadithAudios';
import { ArrowRight, ArrowLeft, Volume2, Square, Sparkles, BookOpen, Waves, Radio } from 'lucide-react';

interface StoryViewProps {
  hadith: HadithItem;
  onBack: () => void;
  onOpenHadithDetail: () => void;
  onRecordRead?: (hadithId: string) => void;
  onRecordAudioListened?: (hadithId: string) => void;
}

export const StoryView: React.FC<StoryViewProps> = ({
  hadith,
  onBack,
  onOpenHadithDetail,
  onRecordRead,
  onRecordAudioListened
}) => {
  const { t, isRtl } = useLanguage();
  const [currentSceneIndex, setCurrentSceneIndex] = useState(0);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [isContinuousStory, setIsContinuousStory] = useState(false);
  const isContinuousStoryRef = useRef(false);
  const currentSceneIndexRef = useRef(0);

  const onRecordReadRef = useRef(onRecordRead);
  const onRecordAudioListenedRef = useRef(onRecordAudioListened);

  useEffect(() => {
    onRecordReadRef.current = onRecordRead;
    onRecordAudioListenedRef.current = onRecordAudioListened;
  });

  useEffect(() => {
    currentSceneIndexRef.current = currentSceneIndex;
  }, [currentSceneIndex]);

  useEffect(() => {
    if (onRecordReadRef.current) {
      onRecordReadRef.current(hadith.id);
    }
  }, [hadith.id]);

  const scene: StoryScene = hadith.scenes[currentSceneIndex] || hadith.scenes[0];
  const totalScenes = hadith.scenes.length;
  const ambientType = detectAmbientContext(hadith);
  const ambientPreset = AMBIENT_PRESETS[ambientType] || AMBIENT_PRESETS.sanctuary;

  const getSceneBackground = (index: number) => {
    const isNightOrQuiet = hadith.topic === 'الصلاة' || hadith.topic === 'الدعاء' || hadith.topic === 'رمضان';
    if (index === 0) return isNightOrQuiet ? nightDesertStarsImage : desertHeroImage;
    if (index === 1) return companionsStoryImage;
    if (index === 2) return prophetCourtyardImage;
    if (index === 3) return mosqueMinaretImage;
    return prophetCourtyardImage;
  };

  const currentBg = getSceneBackground(currentSceneIndex);

  const stopAllAudio = () => {
    isContinuousStoryRef.current = false;
    setIsContinuousStory(false);
    audioEngine.stopSpeaking();
    ambientEngine.stop();
    setIsPlayingAudio(false);
  };

  const handleNext = () => {
    stopAllAudio();
    if (currentSceneIndex < totalScenes - 1) {
      setCurrentSceneIndex(prev => prev + 1);
    } else {
      onOpenHadithDetail();
    }
  };

  const handlePrev = () => {
    stopAllAudio();
    if (currentSceneIndex > 0) {
      setCurrentSceneIndex(prev => prev - 1);
    }
  };

  const playSingleSceneAudio = (sceneIdx: number, onComplete?: () => void) => {
    const targetScene = hadith.scenes[sceneIdx];
    if (!targetScene) return;

    const rawText = targetScene.audioText || targetScene.content;
    const textToSpeak = cleanStoryContentForSpeech(rawText);

    ambientEngine.play(ambientType);

    audioEngine.narrateStoryScene(
      { content: textToSpeak },
      {
        hadithId: hadith.id,
        type: 'story',
        onEnd: () => {
          if (onComplete) {
            onComplete();
          } else {
            setIsPlayingAudio(false);
            ambientEngine.stop();
          }
        },
        onError: () => {
          setIsPlayingAudio(false);
          ambientEngine.stop();
        }
      }
    );
  };

  const playSceneSequence = (sceneIdx: number) => {
    if (!isContinuousStoryRef.current) return;
    if (sceneIdx >= totalScenes) {
      isContinuousStoryRef.current = false;
      setIsContinuousStory(false);
      setIsPlayingAudio(false);
      ambientEngine.stop();
      if (onRecordAudioListenedRef.current) {
        onRecordAudioListenedRef.current(hadith.id);
      }
      return;
    }

    setCurrentSceneIndex(sceneIdx);
    playSingleSceneAudio(sceneIdx, () => {
      if (isContinuousStoryRef.current) {
        setTimeout(() => {
          playSceneSequence(sceneIdx + 1);
        }, 1200);
      }
    });
  };

  const handlePlayFullStoryContinuous = () => {
    if (isPlayingAudio && isContinuousStory) {
      stopAllAudio();
      return;
    }
    stopAllAudio();
    isContinuousStoryRef.current = true;
    setIsContinuousStory(true);
    setIsPlayingAudio(true);

    if (hasPrepackagedAudio(hadith.id, 'story')) {
      ambientEngine.play(ambientType);
      const fullStoryText = hadith.scenes.map(s => s.content).join(' ');
      audioEngine.narrateStoryScene(
        { content: fullStoryText },
        {
          hadithId: hadith.id,
          type: 'story',
          onProgress: (_pct, cur, total) => {
            if (total > 0) {
              const fraction = cur / total;
              const targetIdx = Math.min(totalScenes - 1, Math.floor(fraction * totalScenes));
              setCurrentSceneIndex(targetIdx);
            }
          },
          onEnd: () => {
            isContinuousStoryRef.current = false;
            setIsContinuousStory(false);
            setIsPlayingAudio(false);
            ambientEngine.stop();
            if (onRecordAudioListenedRef.current) {
              onRecordAudioListenedRef.current(hadith.id);
            }
          },
          onError: () => {
            // Fallback to scene sequence
            playSceneSequence(0);
          }
        }
      );
    } else {
      playSceneSequence(0);
    }
  };

  const handleToggleCurrentSceneAudio = () => {
    if (isPlayingAudio && !isContinuousStory) {
      stopAllAudio();
    } else {
      stopAllAudio();
      setIsContinuousStory(false);
      setIsPlayingAudio(true);
      playSingleSceneAudio(currentSceneIndex, () => {
        setIsPlayingAudio(false);
        ambientEngine.stop();
        if (onRecordAudioListenedRef.current) {
          onRecordAudioListenedRef.current(hadith.id);
        }
      });
    }
  };

  useEffect(() => {
    return () => {
      stopAllAudio();
    };
  }, []);

  return (
    <div className="relative w-full min-h-screen bg-[#0D131F] text-slate-100 flex flex-col justify-between overflow-hidden select-none">
      {/* Background with crossfade transition */}
      <div className="absolute inset-0 z-0">
        <img
          key={currentBg}
          src={currentBg}
          alt={scene.title}
          className="w-full h-full object-cover filter brightness-[0.25] transition-all duration-700 ease-in-out scale-105"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0D131F] via-[#0D131F]/70 to-[#0D131F]/30" />
      </div>

      {/* Top Header */}
      <header className="relative z-10 p-4 pt-5 flex items-center justify-between max-w-xl mx-auto w-full">
        <button
          onClick={() => {
            stopAllAudio();
            onBack();
          }}
          className="w-10 h-10 rounded-full bg-slate-900/60 backdrop-blur-md border border-slate-700/60 flex items-center justify-center text-slate-300 hover:text-white transition-colors"
          title={t('backBtn')}
        >
          {isRtl ? <ArrowRight className="w-5 h-5" /> : <ArrowLeft className="w-5 h-5" />}
        </button>

        <div className="flex flex-col items-center">
          <span className="text-xs text-[#E2B773] font-medium tracking-wide">{t('storyTab')}</span>
          <span className="text-sm font-bold text-slate-200">{hadith.topic}</span>
        </div>

        {/* Actions & Scene progress badge */}
        <div className="flex items-center gap-2">
          <OfflineDownloadButton
            hadithId={hadith.id}
            type="story"
            textToSpeak={hadith.scenes.map(s => s.content).join(' ')}
            title={`${t('storyTab')}: ${hadith.topic}`}
            variant="icon"
          />

          <div className="px-3 py-1 rounded-full bg-slate-900/60 backdrop-blur-md border border-[#E2B773]/30 text-xs font-mono font-bold text-[#E2B773] shadow-[0_0_12px_rgba(226,183,115,0.15)]">
            {scene.sceneNumber} / {totalScenes}
          </div>
        </div>
      </header>

      {/* Progress Line Bar across top */}
      <div className="relative z-10 px-5 flex gap-1.5 py-1">
        {hadith.scenes.map((_, idx) => (
          <div
            key={idx}
            onClick={() => {
              audioEngine.stopSpeaking();
              setIsPlayingAudio(false);
              setCurrentSceneIndex(idx);
            }}
            className={`h-1 flex-1 rounded-full cursor-pointer transition-all duration-500 ${
              idx === currentSceneIndex
                ? 'bg-[#E2B773] shadow-[0_0_8px_rgba(226,183,115,0.8)]'
                : idx < currentSceneIndex
                ? 'bg-[#E2B773]/50'
                : 'bg-white/20 hover:bg-white/40'
            }`}
          />
        ))}
      </div>

      {/* Center Story Content Card */}
      <main className="relative z-10 flex-1 flex flex-col justify-center px-6 py-4 max-w-lg mx-auto w-full">
        <div
          key={currentSceneIndex}
          className="bg-[#131B2E]/90 backdrop-blur-md border border-[#E2B773]/30 rounded-3xl p-6 sm:p-8 shadow-2xl flex flex-col items-center text-center animate-scene-card animate-card-glow relative overflow-hidden"
        >
          {/* Subtle Corner Star Accent */}
          <div className="absolute top-3 right-3 text-[#E2B773]/30 text-xs font-serif pointer-events-none select-none">✤</div>
          <div className="absolute top-3 left-3 text-[#E2B773]/30 text-xs font-serif pointer-events-none select-none">✤</div>

          {/* Floating Badge */}
          <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-[#E2B773]/15 border border-[#E2B773]/35 text-[#E2B773] text-xs font-bold mb-4 animate-badge-float shadow-sm">
            <Sparkles className="w-3.5 h-3.5 text-[#E2B773]" />
            <span>{scene.badge}</span>
          </div>

          {/* Title */}
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white mb-2 leading-tight">
            {scene.title}
          </h2>

          {scene.subtitle && (
            <p className="text-xs sm:text-sm text-slate-400 mb-5 font-medium">
              {scene.subtitle}
            </p>
          )}

          {/* Hadith Excerpt Spotlight */}
          {scene.hadithTextExcerpt && (
            <div className="w-full my-4">
              <HadithReciterPlayer
                hadithText={scene.hadithTextExcerpt}
                variant="card"
                showText={true}
              />
            </div>
          )}

          {/* Main Story Narrative */}
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed my-2 max-w-md">
            {scene.content}
          </p>

          {/* Reflection Prompt */}
          {scene.reflectionPrompt && (
            <div className="mt-4 p-3.5 rounded-xl bg-amber-950/30 border border-amber-700/40 text-xs sm:text-sm text-amber-200/95 font-medium animate-soft-pulse shadow-sm">
              💡 {scene.reflectionPrompt}
            </div>
          )}

          {/* Voice Narration Buttons */}
          <div className="mt-6 flex flex-col items-center gap-2.5 w-full">
            <div className="flex flex-wrap items-center justify-center gap-2">
              {/* Continuous Full Story Playback */}
              <button
                onClick={handlePlayFullStoryContinuous}
                className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-full border text-xs sm:text-sm font-black transition-all active:scale-95 ${
                  isPlayingAudio && isContinuousStory
                    ? 'bg-[#E2B773] border-[#E2B773] text-[#0D131F] shadow-lg shadow-[#E2B773]/30 animate-pulse'
                    : 'bg-[#E2B773]/20 hover:bg-[#E2B773]/30 border-[#E2B773]/50 text-[#E2B773] hover:text-white shadow-sm'
                }`}
              >
                {isPlayingAudio && isContinuousStory ? (
                  <>
                    <Square className="w-4 h-4 fill-current" />
                    <span>{t('stopStory')} ({scene.sceneNumber}/{totalScenes})</span>
                  </>
                ) : (
                  <>
                    <Radio className="w-4 h-4 text-[#E2B773]" />
                    <span>{t('fullStoryPlaying')}</span>
                  </>
                )}
              </button>

              {/* Single Scene Playback */}
              <button
                onClick={handleToggleCurrentSceneAudio}
                className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-full border text-xs font-bold transition-all active:scale-95 ${
                  isPlayingAudio && !isContinuousStory
                    ? 'bg-[#E2B773] border-[#E2B773] text-[#0D131F] shadow-lg shadow-[#E2B773]/30 animate-pulse'
                    : 'bg-slate-800/80 hover:bg-slate-700/90 border-slate-700 text-slate-300 hover:text-white shadow-sm'
                }`}
              >
                {isPlayingAudio && !isContinuousStory ? (
                  <>
                    <Square className="w-3.5 h-3.5 fill-current" />
                    <span>{t('stopScene')}</span>
                  </>
                ) : (
                  <>
                    <Volume2 className="w-3.5 h-3.5 text-[#E2B773]" />
                    <span>{t('singleScenePlaying')}</span>
                  </>
                )}
              </button>
            </div>

            {/* Ambient sound cue */}
            <div className="flex items-center gap-2 text-[10px] text-slate-400">
              <Waves className={`w-3 h-3 ${isPlayingAudio ? 'text-[#E2B773] animate-pulse' : 'text-slate-500'}`} />
              <span>{t('ambientSound')}</span>
              <span className="text-[#E2B773] font-medium">{ambientPreset.icon} {ambientPreset.name.split(' ')[0]}</span>
            </div>
          </div>
        </div>
      </main>

      {/* Bottom Navigation Controls */}
      <footer className="relative z-10 px-6 pb-6 pt-2 flex items-center justify-between gap-3 max-w-lg mx-auto w-full">
        {currentSceneIndex > 0 ? (
          <button
            onClick={handlePrev}
            className="flex-1 h-12 rounded-2xl bg-slate-800/90 hover:bg-slate-700 text-slate-200 font-bold text-sm flex items-center justify-center gap-2 border border-slate-700 active:scale-98 transition-all"
          >
            {isRtl ? <ArrowRight className="w-4 h-4" /> : <ArrowLeft className="w-4 h-4" />}
            <span>{t('prevBtn')}</span>
          </button>
        ) : (
          <div className="flex-1" />
        )}

        <button
          onClick={handleNext}
          className="flex-1 h-12 rounded-2xl bg-[#E2B773] hover:bg-[#d4a861] text-[#0D131F] font-extrabold text-sm flex items-center justify-center gap-2 shadow-lg shadow-[#E2B773]/20 active:scale-98 transition-all"
        >
          {currentSceneIndex < totalScenes - 1 ? (
            <>
              <span>{t('nextBtn')}</span>
              {isRtl ? <ArrowLeft className="w-4 h-4" /> : <ArrowRight className="w-4 h-4" />}
            </>
          ) : (
            <>
              <BookOpen className="w-4 h-4" />
              <span>{t('hadithFullPage')}</span>
            </>
          )}
        </button>
      </footer>
    </div>
  );
};
