import React, { useMemo } from 'react';
import { HadithItem, ActiveTab } from '../types/hadith';
import { desertHeroImage } from '../data/hadiths';
import { getDailyHadith, formatShortArabicDate } from '../utils/dailyHadith';
import { ReadingStats } from '../utils/readingTracker';
import { useLanguage } from '../context/LanguageContext';
import {
  Search,
  Settings,
  Play,
  Sparkles,
  ChevronLeft,
  Calendar,
  Flame,
  Heart
} from 'lucide-react';

interface HomeViewProps {
  hadiths: HadithItem[];
  stats: ReadingStats;
  onOpenStory: (hadith: HadithItem) => void;
  onSelectHadith?: (hadith: HadithItem) => void;
  onChangeTab: (tab: ActiveTab) => void;
  onOpenSettings: () => void;
  onOpenStats: () => void;
  onOpenAbout: () => void;
  themeMode?: 'default' | 'light' | 'ultra-dark';
  onToggleTheme?: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  hadiths,
  stats,
  onOpenStory,
  onChangeTab,
  onOpenSettings,
  onOpenStats,
  onOpenAbout,
}) => {
  const { t } = useLanguage();

  // Automatically rotates every single day across all 2000 hadiths
  const featuredHadith = useMemo(() => getDailyHadith(hadiths, new Date()), [hadiths]);
  const todayArabicDate = useMemo(() => formatShortArabicDate(new Date()), []);

  return (
    <div className="w-full min-h-screen bg-[#0D131F] text-slate-100 p-4 pb-28 max-w-2xl mx-auto space-y-5">
      {/* Top Header */}
      <header className="flex items-center justify-between pt-2">
        <button
          onClick={() => onChangeTab('search')}
          className="w-10 h-10 rounded-full bg-[#131B2E] border border-slate-800 flex items-center justify-center text-slate-300 hover:text-white active:scale-95 transition-all"
          title={t('search')}
        >
          <Search className="w-5 h-5" />
        </button>

        {/* Center Logo Branding */}
        <div className="text-center flex flex-col items-center">
          <div className="flex items-center justify-center text-[#E2B773] mb-0.5">
            <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24">
              <path d="M12 2C10.5 4 9 6.5 9 9C9 10.66 10.34 12 12 12C13.66 12 15 10.66 15 9C15 6.5 13.5 4 12 2ZM4 19V11C4 10.45 4.45 10 5 10H6V19H4ZM18 10H19C19.55 10 20 10.45 20 11V19H18V10ZM8 19V11.5C8 9.5 9.8 8 12 8C14.2 8 16 9.5 16 11.5V19H8ZM3 21H21V22H3V21Z" />
            </svg>
          </div>
          <h1 className="text-2xl font-black text-slate-100 tracking-tight leading-none">
            {t('appTitle')}
          </h1>
          <p className="text-[11px] text-[#94A3B8] font-medium mt-1">
            {t('appSubtitle')}
          </p>
        </div>

        {/* Left Actions: Settings */}
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenSettings}
            className="w-10 h-10 rounded-full bg-[#131B2E] border border-slate-800 flex items-center justify-center text-slate-300 hover:text-white active:scale-95 transition-all"
            title={t('settings')}
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Featured Hero Card: حديث اليوم */}
      <div className="relative w-full rounded-3xl overflow-hidden border border-slate-800/80 shadow-2xl bg-[#131B2E]">
        {/* Desert artwork background */}
        <div className="relative w-full h-72 sm:h-80 overflow-hidden">
          <img
            src={desertHeroImage}
            alt="المشهد النبوي"
            className="w-full h-full object-cover filter brightness-[0.7]"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#131B2E] via-[#131B2E]/40 to-black/30" />

          {/* Badge */}
          <div className="absolute top-4 inset-x-0 flex justify-center z-10">
            <span className="px-4 py-1.5 rounded-full bg-black/70 backdrop-blur-md border border-[#E2B773]/40 text-xs text-[#E2B773] font-bold flex items-center gap-1.5 shadow-lg">
              <Calendar className="w-3.5 h-3.5 text-[#E2B773]" />
              <span>{t('todayDatePrefix')}{todayArabicDate}</span>
            </span>
          </div>

          {/* Center Callout */}
          <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center z-10 pt-10">
            {/* Topic pill */}
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#131B2E]/80 backdrop-blur-md border border-slate-700/80 text-[11px] font-semibold text-[#E2B773] mb-2">
              <Sparkles className="w-3 h-3" />
              <span>{featuredHadith.topic} · {featuredHadith.narrator}</span>
            </span>

            <h3 className="text-xl sm:text-2xl font-extrabold text-white mb-1.5 max-w-sm drop-shadow">
              {t('beforeReading')}
            </h3>
            <p className="text-xs sm:text-sm text-slate-200 mb-5 font-medium drop-shadow max-w-md line-clamp-2 px-2 text-slate-300">
              {featuredHadith.context.slice(0, 95)}...
            </p>

            {/* Start Story CTA button */}
            <button
              onClick={() => onOpenStory(featuredHadith)}
              className="py-3 px-8 rounded-full bg-[#E2B773] hover:bg-[#d4a861] text-[#0D131F] font-black text-sm flex items-center gap-2 shadow-xl shadow-black/40 active:scale-95 transition-all"
            >
              <Play className="w-4 h-4 fill-current ml-0.5" />
              <span>{t('startTodayStory')}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Interactive User Reading Streak & Stats Card */}
      <div
        onClick={onOpenStats}
        className="p-4 rounded-2xl bg-gradient-to-r from-[#1A2438] via-[#141C2E] to-[#101726] border border-amber-500/30 hover:border-amber-500/60 transition-all cursor-pointer shadow-lg group relative overflow-hidden"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center shrink-0">
              <Flame className="w-6 h-6 text-amber-500 fill-current animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-black text-white">
                  {stats.currentStreak > 0
                    ? `${t('streakTitle')} ${stats.currentStreak} ${stats.currentStreak === 1 ? t('streakDaysSingular') : t('streakDaysPlural')}`
                    : t('startStreakPrompt')}
                </span>
                {stats.currentStreak >= 3 && (
                  <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-bold">
                    {t('mashaAllah')}
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                {t('statsSummary', { read: stats.readHadithIds.length, total: hadiths.length })}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1 text-xs font-bold text-amber-400 shrink-0">
            <span className="hidden sm:inline">{t('statsBoard')}</span>
            <ChevronLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform rtl:group-hover:translate-x-0" />
          </div>
        </div>
      </div>

      {/* Charitable Mission & Du'aa Banner */}
      <div
        onClick={onOpenAbout}
        className="p-3.5 rounded-2xl bg-gradient-to-r from-rose-500/10 via-[#131B2E] to-amber-500/10 border border-slate-800 hover:border-slate-700 transition-all cursor-pointer flex items-center justify-between text-xs group"
      >
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center shrink-0">
            <Heart className="w-4 h-4 fill-current" />
          </div>
          <div>
            <span className="text-white font-bold block text-xs">{t('charitableBannerTitle')}</span>
            <span className="text-[10px] text-slate-400">{t('charitableBannerSub')}</span>
          </div>
        </div>
        <ChevronLeft className="w-4 h-4 text-slate-400 group-hover:text-white transition-all" />
      </div>

      {/* Value Proposition Highlights Banner */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-[#1E293B] to-[#131B2E] border border-slate-800 flex items-center justify-around text-center text-xs text-slate-300">
        <div className="flex flex-col items-center">
          <span className="text-[#E2B773] font-bold text-sm">2000+</span>
          <span className="text-[10px] text-slate-400">{t('highlightsAuthentic')}</span>
        </div>
        <div className="w-px h-7 bg-slate-700" />
        <div className="flex flex-col items-center">
          <span className="text-[#E2B773] font-bold text-sm">5</span>
          <span className="text-[10px] text-slate-400">{t('highlightsScenes')}</span>
        </div>
        <div className="w-px h-7 bg-slate-700" />
        <div className="flex flex-col items-center">
          <span className="text-[#E2B773] font-bold text-sm">100%</span>
          <span className="text-[10px] text-slate-400">{t('highlightsCalmAudio')}</span>
        </div>
        <div className="w-px h-7 bg-slate-700" />
        <div className="flex flex-col items-center">
          <span className="text-[#E2B773] font-bold text-sm">HD</span>
          <span className="text-[10px] text-slate-400">{t('highlightsCards')}</span>
        </div>
      </div>
    </div>
  );
};
