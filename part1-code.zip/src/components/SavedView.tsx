import React, { useState } from 'react';
import { HadithItem } from '../types/hadith';
import { HadithReciterPlayer } from './HadithReciterPlayer';
import { useLanguage } from '../context/LanguageContext';
import { Bookmark } from 'lucide-react';

interface SavedViewProps {
  hadiths: HadithItem[];
  bookmarkedIds: string[];
  onToggleBookmark: (id: string) => void;
  onSelectHadith: (hadith: HadithItem) => void;
  onOpenStory: (hadith: HadithItem) => void;
}

export const SavedView: React.FC<SavedViewProps> = ({
  hadiths,
  bookmarkedIds,
  onToggleBookmark,
  onSelectHadith,
  onOpenStory,
}) => {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<'all' | 'favorites'>('all');

  const savedHadiths = hadiths.filter(h => bookmarkedIds.includes(h.id));

  return (
    <div className="w-full min-h-screen bg-[#0D131F] text-slate-100 p-4 pb-28 max-w-xl mx-auto">
      <h2 className="text-xl font-bold text-center text-white mb-4">{t('savedHadithsHeading')}</h2>

      {/* Tabs */}
      <div className="flex bg-[#131B2E] p-1 rounded-2xl mb-5 border border-slate-800">
        <button
          onClick={() => setActiveTab('all')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
            activeTab === 'all'
              ? 'bg-[#E2B773] text-[#0D131F] shadow'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          {t('tabAll')} ({savedHadiths.length})
        </button>
        <button
          onClick={() => setActiveTab('favorites')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all ${
            activeTab === 'favorites'
              ? 'bg-[#E2B773] text-[#0D131F] shadow'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          {t('tabFavorites')} ({savedHadiths.length})
        </button>
      </div>

      {savedHadiths.length === 0 ? (
        <div className="text-center py-16 px-4 rounded-3xl bg-[#131B2E] border border-slate-800">
          <Bookmark className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <h4 className="text-base font-bold text-slate-200 mb-1">{t('noSavedPrompt')}</h4>
          <p className="text-xs text-slate-400 max-w-xs mx-auto">
            {t('noSavedSub')}
          </p>
        </div>
      ) : (
        <div className="space-y-3.5">
          {savedHadiths.map(item => (
            <div
              key={item.id}
              className="p-4 rounded-2xl bg-[#131B2E] border border-slate-800 hover:border-slate-700 transition-all space-y-3"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#E2B773]">{item.topic}</span>
                <button
                  onClick={() => onToggleBookmark(item.id)}
                  className="text-amber-400 hover:text-slate-400 transition-colors p-1"
                  title={t('bookmarked')}
                >
                  <Bookmark className="w-4 h-4 fill-current" />
                </button>
              </div>

              {/* Audio reciter player */}
              <HadithReciterPlayer
                hadithText={item.hadith_text}
                hadithId={item.id}
                narrator={item.narrator}
                source={item.source}
                variant="card"
                showText={true}
              />

              <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-[11px] text-slate-400">
                <span>{item.narrator}</span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onOpenStory(item)}
                    className="text-xs text-[#E2B773] hover:underline font-bold"
                  >
                    {t('listenStory')}
                  </button>
                  <button
                    onClick={() => onSelectHadith(item)}
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-bold"
                  >
                    {t('hadithFullPage')}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
