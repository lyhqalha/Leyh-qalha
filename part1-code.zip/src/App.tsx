import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { HadithItem, ActiveTab } from './types/hadith';
import { HADITHS_DATABASE } from './data/hadiths';
import { getDailyHadith } from './utils/dailyHadith';
import { getLocalizedHadiths, getLocalizedHadith } from './utils/hadithLocalization';
import { HomeView } from './components/HomeView';
import { SavedView } from './components/SavedView';
import { SearchView } from './components/SearchView';
import { DailyHadithView } from './components/DailyHadithView';
import { CategoriesView } from './components/CategoriesView';
import { StoryView } from './components/StoryView';
import { HadithDetail } from './components/HadithDetail';
import { BottomNav } from './components/BottomNav';
import { ShareCardModal } from './components/ShareCardModal';
import { AudioPlayerModal } from './components/AudioPlayerModal';
import { SettingsModal } from './components/SettingsModal';
import { UserStatsModal } from './components/UserStatsModal';
import { AboutAppModal } from './components/AboutAppModal';
import { LanguageProvider, useLanguage } from './context/LanguageContext';
import { getInitialStats, recordHadithRead, recordStoryListened, ReadingStats } from './utils/readingTracker';
import { initDhikrScheduler, playOfflineDhikrAudio } from './utils/offlineDhikrReminderService';
import { OfflineDhikrItem } from './data/offlineAthkarAudios';
import {
  isNativeApp,
  scheduleDailyHadithNotifications,
  sendTestNativeNotification,
  requestNotificationPermission,
  onNotificationTapped,
} from './utils/nativeNotifications';
import { Bell, X, BookOpen, Volume2, Sparkles } from 'lucide-react';

function AppContent() {
  const { t, language, isRtl } = useLanguage();

  const [activeTab, setActiveTab] = useState<ActiveTab>('home');
  const [activeView, setActiveView] = useState<'tab' | 'story' | 'detail'>('tab');
  const [selectedHadith, setSelectedHadith] = useState<HadithItem>(() => getDailyHadith(HADITHS_DATABASE, new Date()));

  // Localized database and selected hadith dynamically adapted to the active language
  const localizedDatabase = useMemo(() => getLocalizedHadiths(HADITHS_DATABASE, language), [language]);
  const currentHadith = useMemo(() => getLocalizedHadith(selectedHadith, language), [selectedHadith, language]);
  
  // Reading statistics & streak tracking
  const [readingStats, setReadingStats] = useState<ReadingStats>(getInitialStats);

  // Bookmarks persistence
  const [bookmarkedIds, setBookmarkedIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('leh_qalha_bookmarks');
      return saved ? JSON.parse(saved) : ['hadith-6018', 'hadith-1', 'hadith-15'];
    } catch {
      return ['hadith-6018', 'hadith-1', 'hadith-15'];
    }
  });

  // Modal states
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [isAudioModalOpen, setIsAudioModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isStatsModalOpen, setIsStatsModalOpen] = useState(false);
  const [isAboutModalOpen, setIsAboutModalOpen] = useState(false);

  // Appearance font size
  const [fontSize, setFontSize] = useState<'sm' | 'md' | 'lg'>('md');

  // Daily Reading Reminder
  const [isReminderEnabled, setIsReminderEnabled] = useState<boolean>(() => {
    try {
      return localStorage.getItem('leh_qalha_reminder_enabled') === 'true';
    } catch {
      return false;
    }
  });

  const [reminderTime, setReminderTime] = useState<string>(() => {
    try {
      return localStorage.getItem('leh_qalha_reminder_time') || '09:00';
    } catch {
      return '09:00';
    }
  });

  // In-app interactive reminder notification banner
  const [activeReminderBanner, setActiveReminderBanner] = useState<{
    title: string;
    message: string;
  } | null>(null);

  // In-app Periodic Offline Dhikr & Salawat toast
  const [activeDhikrToast, setActiveDhikrToast] = useState<OfflineDhikrItem | null>(null);

  // Background Scheduler for Offline Periodic Dhikr & Salawat
  useEffect(() => {
    const cleanup = initDhikrScheduler((item) => {
      setActiveDhikrToast(item);
    });
    return cleanup;
  }, []);

  // Save Bookmarks
  useEffect(() => {
    try {
      localStorage.setItem('leh_qalha_bookmarks', JSON.stringify(bookmarkedIds));
    } catch {
      // Ignored
    }
  }, [bookmarkedIds]);

  // Clean root classes
  useEffect(() => {
    try {
      document.documentElement.classList.remove('ultra-dark', 'light-mode');
      document.body.classList.remove('ultra-dark', 'light-mode');
    } catch {
      // Ignored
    }
  }, []);

  // Save Reminder settings & request Notification permissions if enabled
  const handleToggleReminder = (enabled: boolean) => {
    setIsReminderEnabled(enabled);
    try {
      localStorage.setItem('leh_qalha_reminder_enabled', enabled.toString());
      if (enabled && isNativeApp()) {
        requestNotificationPermission();
      } else if (enabled && typeof window !== 'undefined' && 'Notification' in window) {
        if (Notification.permission === 'default') {
          Notification.requestPermission();
        }
      }
    } catch {
      // Ignored
    }
  };

  const handleChangeReminderTime = (time: string) => {
    setReminderTime(time);
    try {
      localStorage.setItem('leh_qalha_reminder_time', time);
    } catch {
      // Ignored
    }
  };

  // Immediate Test Notification handler
  const handleTestReminder = () => {
    const dailyItem = getDailyHadith(localizedDatabase, new Date());
    const snippet = dailyItem.hadith_text ? dailyItem.hadith_text.slice(0, 85) + '...' : dailyItem.context.slice(0, 85);
    
    // In-app banner
    setActiveReminderBanner({
      title: `✨ ${t('dailyNotifTitle')}: ${dailyItem.topic}`,
      message: `«${snippet}»`,
    });

    // Android: real notification with the custom tone
    if (isNativeApp()) {
      sendTestNativeNotification(
        `📖 ${t('appTitle')} - ${t('dailyHadithHeading')}: ${dailyItem.topic}`,
        `«${snippet}»`
      );
    } else if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification(`📖 ${t('appTitle')} - ${t('dailyHadithHeading')}: ${dailyItem.topic}`, {
          body: snippet,
          icon: '/favicon.ico',
        });
      } catch {
        // Ignored
      }
    }
  };

  // Check reminder time every minute
  useEffect(() => {
    // On Android the native scheduled notification handles this
    if (isNativeApp() || !isReminderEnabled || !reminderTime) return;

    const checkReminder = () => {
      const now = new Date();
      const currentHours = String(now.getHours()).padStart(2, '0');
      const currentMinutes = String(now.getMinutes()).padStart(2, '0');
      const currentTimeStr = `${currentHours}:${currentMinutes}`;

      if (currentTimeStr === reminderTime) {
        const lastSentDate = localStorage.getItem('leh_qalha_last_notification_date');
        const todayStr = now.toISOString().split('T')[0];

        if (lastSentDate !== todayStr) {
          handleTestReminder();
          localStorage.setItem('leh_qalha_last_notification_date', todayStr);
        }
      }
    };

    const intervalId = setInterval(checkReminder, 60000);
    return () => clearInterval(intervalId);
  }, [isReminderEnabled, reminderTime]);

  // Android: schedule the daily-hadith notification (custom tone) for the next 30 days
  useEffect(() => {
    if (!isNativeApp()) return;
    scheduleDailyHadithNotifications(
      isReminderEnabled,
      reminderTime,
      localizedDatabase,
      t('appTitle'),
      t('dailyHadithHeading')
    );
  }, [isReminderEnabled, reminderTime, language, localizedDatabase]);

  // Tapping the notification opens today's hadith
  useEffect(() => {
    return onNotificationTapped(() => {
      setActiveTab('daily');
      setActiveView('tab');
    });
  }, []);

  const handleToggleBookmark = useCallback((id: string) => {
    setBookmarkedIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  }, []);

  const handleRecordRead = useCallback((hadithId: string) => {
    setReadingStats(prev => {
      const updated = recordHadithRead(hadithId);
      if (
        prev.readHadithIds.length === updated.readHadithIds.length &&
        prev.currentStreak === updated.currentStreak &&
        prev.bestStreak === updated.bestStreak &&
        prev.lastReadDate === updated.lastReadDate &&
        prev.activeDates.length === updated.activeDates.length &&
        prev.listenedCount === updated.listenedCount
      ) {
        return prev;
      }
      return updated;
    });
  }, []);

  const handleRecordAudioListened = useCallback((hadithId: string) => {
    setReadingStats(() => recordStoryListened(hadithId));
  }, []);

  const handleOpenStory = useCallback((hadith: HadithItem) => {
    setSelectedHadith(hadith);
    setActiveView('story');
    handleRecordRead(hadith.id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [handleRecordRead]);

  const handleSelectHadithDetail = useCallback((hadith: HadithItem) => {
    setSelectedHadith(hadith);
    setActiveView('detail');
    handleRecordRead(hadith.id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [handleRecordRead]);

  const handleBackToTabs = useCallback(() => {
    setActiveView('tab');
  }, []);

  const handleOpenDailyHadithFromBanner = () => {
    setActiveReminderBanner(null);
    setActiveTab('daily');
    setActiveView('tab');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Render the current view
  const renderCurrentView = () => {
    if (activeView === 'story') {
      return (
        <StoryView
          hadith={currentHadith}
          onBack={handleBackToTabs}
          onOpenHadithDetail={() => setActiveView('detail')}
          onRecordRead={handleRecordRead}
          onRecordAudioListened={handleRecordAudioListened}
        />
      );
    }

    if (activeView === 'detail') {
      return (
        <HadithDetail
          hadith={currentHadith}
          onBack={handleBackToTabs}
          onOpenStory={() => handleOpenStory(currentHadith)}
          isBookmarked={bookmarkedIds.includes(currentHadith.id)}
          onToggleBookmark={() => handleToggleBookmark(currentHadith.id)}
          onOpenShareCard={() => setIsShareModalOpen(true)}
          onOpenAudioPlayer={() => setIsAudioModalOpen(true)}
        />
      );
    }

    switch (activeTab) {
      case 'home':
        return (
          <HomeView
            hadiths={localizedDatabase}
            stats={readingStats}
            onOpenStory={handleOpenStory}
            onSelectHadith={handleSelectHadithDetail}
            onChangeTab={setActiveTab}
            onOpenSettings={() => setIsSettingsModalOpen(true)}
            onOpenStats={() => setIsStatsModalOpen(true)}
            onOpenAbout={() => setIsAboutModalOpen(true)}
          />
        );
      case 'saved':
        return (
          <SavedView
            hadiths={localizedDatabase}
            bookmarkedIds={bookmarkedIds}
            onToggleBookmark={handleToggleBookmark}
            onSelectHadith={handleSelectHadithDetail}
            onOpenStory={handleOpenStory}
          />
        );
      case 'search':
        return (
          <SearchView
            hadiths={localizedDatabase}
            onSelectHadith={handleSelectHadithDetail}
            onOpenStory={handleOpenStory}
          />
        );
      case 'daily':
        return (
          <DailyHadithView
            hadiths={localizedDatabase}
            onOpenStory={handleOpenStory}
            onOpenDetail={handleSelectHadithDetail}
          />
        );
      case 'categories':
        return (
          <CategoriesView
            hadiths={localizedDatabase}
            onSelectCategoryHadith={handleSelectHadithDetail}
            onOpenStory={handleOpenStory}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className={`min-h-screen w-full bg-[#0D131F] text-slate-100 flex flex-col select-none ${isRtl ? 'dir-rtl' : 'dir-ltr'}`}>
      {/* In-App Daily Reminder Toast / Banner */}
      {activeReminderBanner && (
        <div className="sticky top-0 z-50 w-full p-2.5 bg-gradient-to-r from-[#172238] via-[#1F2C47] to-[#172238] border-b border-[#E2B773]/40 shadow-xl animate-fadeIn">
          <div className="max-w-3xl mx-auto flex items-start justify-between gap-2">
            <div className="flex items-start gap-2.5">
              <div className="w-8 h-8 rounded-full bg-[#E2B773]/20 flex items-center justify-center text-[#E2B773] shrink-0 mt-0.5">
                <Bell className="w-4 h-4 animate-bounce" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-[#E2B773] leading-tight">
                  {activeReminderBanner.title}
                </h4>
                <p className="text-[11px] text-slate-200 mt-0.5 leading-snug">
                  {activeReminderBanner.message}
                </p>
                <div className="mt-1.5 flex items-center gap-2">
                  <button
                    onClick={handleOpenDailyHadithFromBanner}
                    className="px-3 py-1 rounded-lg bg-[#E2B773] text-[#0D131F] text-[10px] font-bold flex items-center gap-1 hover:bg-[#d4a861] active:scale-95 transition-all"
                  >
                    <BookOpen className="w-3 h-3" />
                    <span>{t('readTodayHadithNow')}</span>
                  </button>
                  <button
                    onClick={() => setActiveReminderBanner(null)}
                    className="text-[10px] text-slate-400 hover:text-white px-2 py-1"
                  >
                    {t('dismiss')}
                  </button>
                </div>
              </div>
            </div>

            <button
              onClick={() => setActiveReminderBanner(null)}
              className="w-6 h-6 rounded-full bg-black/40 text-slate-400 hover:text-white flex items-center justify-center shrink-0"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* In-App Periodic Offline Dhikr & Salawat Toast / Banner */}
      {activeDhikrToast && (
        <div className="sticky top-0 z-50 w-full p-3 bg-gradient-to-r from-[#17261E] via-[#1A2E2B] to-[#14231E] border-b border-emerald-500/40 shadow-2xl animate-fadeIn">
          <div className="max-w-2xl mx-auto flex items-start justify-between gap-3">
            <div className="flex items-start gap-2.5">
              <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5 animate-pulse">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-black text-emerald-300">
                    📿 {activeDhikrToast.title}
                  </span>
                  <span className="px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[9px] font-bold">
                    {t('offline')}
                  </span>
                </div>
                <p className="text-xs text-white font-arabic font-bold mt-1 leading-relaxed">
                  «{activeDhikrToast.spokenText || activeDhikrToast.text}»
                </p>
                <div className="mt-1.5 flex items-center gap-2">
                  <button
                    onClick={() => playOfflineDhikrAudio(activeDhikrToast)}
                    className="px-2.5 py-1 rounded-lg bg-emerald-500 text-[#0D131F] text-[10px] font-bold flex items-center gap-1 hover:bg-emerald-400 active:scale-95 transition-all shadow-sm"
                  >
                    <Volume2 className="w-3 h-3" />
                    <span>🔊 {t('listenPodcastNow')}</span>
                  </button>
                  <button
                    onClick={() => setActiveDhikrToast(null)}
                    className="text-[10px] text-emerald-400/80 hover:text-white px-2 py-1"
                  >
                    {t('close')}
                  </button>
                </div>
              </div>
            </div>

            <button
              onClick={() => setActiveDhikrToast(null)}
              className="w-6 h-6 rounded-full bg-black/40 text-slate-400 hover:text-white flex items-center justify-center shrink-0"
              title={t('close')}
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Main Full-Screen Application Content */}
      <main className="w-full flex-1 flex flex-col">
        {renderCurrentView()}
      </main>

      {/* Bottom Tab Bar (shown when not in full-screen story mode) */}
      {activeView === 'tab' && (
        <BottomNav activeTab={activeTab} onChangeTab={setActiveTab} />
      )}

      {/* Modals */}
      {isShareModalOpen && (
        <ShareCardModal
          hadith={currentHadith}
          onClose={() => setIsShareModalOpen(false)}
        />
      )}

      {isAudioModalOpen && (
        <AudioPlayerModal
          hadith={currentHadith}
          onClose={() => setIsAudioModalOpen(false)}
        />
      )}

      {isSettingsModalOpen && (
        <SettingsModal
          onClose={() => setIsSettingsModalOpen(false)}
          fontSize={fontSize}
          onChangeFontSize={setFontSize}
          isReminderEnabled={isReminderEnabled}
          onToggleReminder={handleToggleReminder}
          reminderTime={reminderTime}
          onChangeReminderTime={handleChangeReminderTime}
          onTestReminder={handleTestReminder}
          onOpenStats={() => setIsStatsModalOpen(true)}
          onOpenAbout={() => setIsAboutModalOpen(true)}
        />
      )}

      {isStatsModalOpen && (
        <UserStatsModal
          stats={readingStats}
          totalHadithsCount={HADITHS_DATABASE.length}
          onClose={() => setIsStatsModalOpen(false)}
          onOpenAbout={() => setIsAboutModalOpen(true)}
        />
      )}

      {isAboutModalOpen && (
        <AboutAppModal
          onClose={() => setIsAboutModalOpen(false)}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AppContent />
    </LanguageProvider>
  );
}
