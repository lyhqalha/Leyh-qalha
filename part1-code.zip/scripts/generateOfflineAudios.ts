import dotenv from 'dotenv';
dotenv.config();
import { GoogleGenAI } from '@google/genai';
import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import { HADITHS_DATABASE } from '../src/data/hadiths';

const ai = new GoogleGenAI();

const HADITH_DIR = path.resolve('public/audio/hadiths');
const STORY_DIR = path.resolve('public/audio/stories');

fs.mkdirSync(HADITH_DIR, { recursive: true });
fs.mkdirSync(STORY_DIR, { recursive: true });

// Top featured hadiths list for offline bundle
const targetHadiths = HADITHS_DATABASE.slice(0, 16);

async function generateAudioWithRetry(text: string, outMp3Path: string, maxRetries = 3): Promise<boolean> {
  if (fs.existsSync(outMp3Path) && fs.statSync(outMp3Path).size > 1000) {
    console.log(`Already exists: ${path.basename(outMp3Path)}`);
    return true;
  }

  const cleanText = text.replace(/المشهد\s+[\u0600-\u06FF\w\d]+\s*[:：\-–—\.]\s*/gi, '').trim().slice(0, 800);

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      let res;
      try {
        res = await ai.models.generateContent({
          model: 'gemini-3.8-flash-lite-tts',
          contents: cleanText,
          config: {
            responseModalities: ['AUDIO'],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: {
                  voiceName: 'Charon'
                }
              }
            }
          }
        });
      } catch (err: any) {
        if (err.message && err.message.includes('429')) {
          console.warn(`[Rate limit 429] Waiting 5s before retrying attempt ${attempt}...`);
          await new Promise(r => setTimeout(r, 5000));
          continue;
        }
        // Fallback to flash-tts
        res = await ai.models.generateContent({
          model: 'gemini-3.8-flash-tts',
          contents: cleanText,
          config: {
            responseModalities: ['AUDIO'],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: {
                  voiceName: 'Charon'
                }
              }
            }
          }
        });
      }

      const part = res.candidates?.[0]?.content?.parts?.[0];
      const base64Data = part?.inlineData?.data;
      if (!base64Data) {
        console.warn(`No audio data for: ${outMp3Path}`);
        return false;
      }

      const tempWav = path.join('/tmp', `temp_${Date.now()}_${Math.random().toString(36).substring(7)}.wav`);
      fs.writeFileSync(tempWav, Buffer.from(base64Data, 'base64'));

      // Convert with volume boost & limiter to match athkar volume
      execSync(`ffmpeg -y -i "${tempWav}" -af "volume=6.5dB,alimiter=limit=-0.2dB" -b:a 64k "${outMp3Path}" 2>/dev/null`);
      try { fs.unlinkSync(tempWav); } catch {}

      const size = fs.statSync(outMp3Path).size;
      console.log(`Generated: ${path.basename(outMp3Path)} (${Math.round(size / 1024)} KB)`);
      return true;
    } catch (err: any) {
      console.error(`Attempt ${attempt} failed for ${path.basename(outMp3Path)}:`, err.message);
      if (attempt < maxRetries) {
        await new Promise(r => setTimeout(r, 3000));
      }
    }
  }

  return false;
}

function updateRegistry() {
  const hadithFiles = fs.readdirSync(HADITH_DIR).filter(f => f.endsWith('.mp3'));
  const storyFiles = fs.readdirSync(STORY_DIR).filter(f => f.endsWith('.mp3'));

  const mapObj: Record<string, { hadith?: string; story?: string }> = {};

  for (const f of hadithFiles) {
    const id = path.basename(f, '.mp3');
    if (!mapObj[id]) mapObj[id] = {};
    mapObj[id].hadith = `/audio/hadiths/${f}`;
  }

  for (const f of storyFiles) {
    const id = path.basename(f, '.mp3');
    if (!mapObj[id]) mapObj[id] = {};
    mapObj[id].story = `/audio/stories/${f}`;
  }

  const entriesCode = Object.entries(mapObj)
    .map(([id, paths]) => `  '${id}': {\n    hadith: '${paths.hadith || ''}',\n    story: '${paths.story || ''}'\n  }`)
    .join(',\n');

  const tsContent = `/**
 * Offline Hadiths and Stories Pre-stored Audio Registry
 * 
 * Pre-packages reciter audio tracks directly into the application bundle
 * so that Hadith recitation and Story narrations play 100% offline
 * with the exact same tranquil, reverent recitation voice without needing internet.
 */

export interface PrepackagedHadithTrack {
  hadithId: string;
  hasHadithAudio: boolean;
  hasStoryAudio: boolean;
  hadithUrl: string;
  storyUrl: string;
}

export const PREPACKAGED_HADITH_MAP: Record<string, { hadith: string; story: string }> = {
${entriesCode}
};

/**
 * Checks if a pre-stored offline audio file exists on the application.
 */
export function hasPrepackagedAudio(hadithId: string, type: 'hadith' | 'story' = 'hadith'): boolean {
  if (!hadithId) return false;
  const entry = PREPACKAGED_HADITH_MAP[hadithId];
  if (!entry) return false;
  return Boolean(type === 'story' ? entry.story : entry.hadith);
}

/**
 * Gets the direct offline path to the stored audio file.
 */
export function getPrepackagedAudioPath(hadithId: string, type: 'hadith' | 'story' = 'hadith'): string | null {
  if (!hadithId) return null;
  const entry = PREPACKAGED_HADITH_MAP[hadithId];
  if (!entry) return null;
  return type === 'story' ? (entry.story || null) : (entry.hadith || null);
}

/**
 * Returns all pre-packaged tracks for offline caching and verification.
 */
export function getAllPrepackagedTracks(): { id: string; url: string; type: 'hadith' | 'story' }[] {
  const list: { id: string; url: string; type: 'hadith' | 'story' }[] = [];
  for (const [hadithId, urls] of Object.entries(PREPACKAGED_HADITH_MAP)) {
    if (urls.hadith) list.push({ id: \`\${hadithId}_hadith\`, url: urls.hadith, type: 'hadith' });
    if (urls.story) list.push({ id: \`\${hadithId}_story\`, url: urls.story, type: 'story' });
  }
  return list;
}
`;

  fs.writeFileSync(path.resolve('src/data/offlineHadithAudios.ts'), tsContent, 'utf-8');
  console.log('Updated src/data/offlineHadithAudios.ts with current stored files!');
}

async function main() {
  console.log(`Starting offline audio generation for featured items...`);

  for (const h of targetHadiths) {
    console.log(`\nProcessing ${h.id} (${h.topic})...`);

    // 1. Hadith text audio
    const hadithAudioPath = path.join(HADITH_DIR, `${h.id}.mp3`);
    await generateAudioWithRetry(h.hadith_text, hadithAudioPath);

    // 2. Story audio (all scenes or context)
    const storyText = h.scenes && h.scenes.length > 0
      ? h.scenes.map(s => s.content).join(' ')
      : h.context || h.hadith_text;
    const storyAudioPath = path.join(STORY_DIR, `${h.id}.mp3`);
    await generateAudioWithRetry(storyText, storyAudioPath);

    await new Promise(r => setTimeout(r, 600));
  }

  updateRegistry();
  console.log('\nFinished generating offline audios and updating registry!');
}

main().catch(console.error);
