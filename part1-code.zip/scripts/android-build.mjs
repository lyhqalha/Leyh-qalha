// One command: build web app -> create/sync Android project -> apply
// full-screen + notification-tone customisations -> build the APK.
//   npm run apk
import { execSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

const APP_ID = 'com.lehqalha.app';
const root = process.cwd();
const run = (cmd) => { console.log('\n> ' + cmd); execSync(cmd, { stdio: 'inherit', cwd: root }); };

run('npm run build');
if (!fs.existsSync(path.join(root, 'android'))) run('npx cap add android');

// 1) MainActivity (full-screen / edge-to-edge)
const javaDir = path.join(root, 'android/app/src/main/java', ...APP_ID.split('.'));
fs.mkdirSync(javaDir, { recursive: true });
const act = fs.readFileSync(path.join(root, 'android-overrides/MainActivity.java'), 'utf8')
  .replace('__APP_ID__', APP_ID);
fs.writeFileSync(path.join(javaDir, 'MainActivity.java'), act);

// 2) Custom notification tone
const rawDir = path.join(root, 'android/app/src/main/res/raw');
fs.mkdirSync(rawDir, { recursive: true });
fs.copyFileSync(path.join(root, 'android-overrides/hadith_tone.wav'), path.join(rawDir, 'hadith_tone.wav'));

// 3) Manifest permissions (idempotent)
const manifestPath = path.join(root, 'android/app/src/main/AndroidManifest.xml');
let manifest = fs.readFileSync(manifestPath, 'utf8');
for (const p of ['POST_NOTIFICATIONS', 'SCHEDULE_EXACT_ALARM', 'RECEIVE_BOOT_COMPLETED', 'VIBRATE', 'WAKE_LOCK']) {
  const line = `<uses-permission android:name="android.permission.${p}" />`;
  if (!manifest.includes(`android.permission.${p}"`)) {
    manifest = manifest.replace('</manifest>', `    ${line}\n</manifest>`);
  }
}
fs.writeFileSync(manifestPath, manifest);

run('npx cap sync android');

// 4) Build debug APK (needs JDK 21 + Android SDK, or just use the GitHub workflow)
const gradlew = process.platform === 'win32' ? 'gradlew.bat' : './gradlew';
if (process.platform !== 'win32') run('chmod +x android/gradlew');
try {
  execSync(`${gradlew} assembleDebug`, { stdio: 'inherit', cwd: path.join(root, 'android') });
  console.log('\n✅ APK: android/app/build/outputs/apk/debug/app-debug.apk');
} catch {
  console.log('\n⚠️ Android project is ready in ./android — open it in Android Studio and press Build > Build APK.');
}
