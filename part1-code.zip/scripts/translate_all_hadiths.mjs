import { GoogleGenAI } from '@google/genai';
import fs from 'fs';
import dotenv from 'dotenv';
dotenv.config();

const ai = new GoogleGenAI();
const items = JSON.parse(fs.readFileSync('/tmp/distinct_101.json', 'utf8'));

console.log(`Starting translation for ${items.length} distinct hadiths into en, ur, fa...`);

const BATCH_SIZE = 8;
const results = {};

// Load existing progress if available
const targetFile = 'src/data/hadithsOfflineTranslations.json';
if (fs.existsSync(targetFile)) {
  try {
    const existing = JSON.parse(fs.readFileSync(targetFile, 'utf8'));
    Object.assign(results, existing);
    console.log(`Loaded ${Object.keys(results).length} already translated items.`);
  } catch {
    // start fresh
  }
}

async function translateBatch(batch) {
  const promptItems = batch.map((item, idx) => ({
    key: item.hadith_text,
    id: item.id,
    topic: item.topic,
    text: item.hadith_text,
    context: item.context,
    explanation: item.explanation,
    practical_lesson: item.practical_lesson || []
  }));

  const prompt = `You are an expert Islamic scholar and translator.
Translate the following ${promptItems.length} Prophetic Hadith records into:
1. "en" (English)
2. "ur" (Urdu)
3. "fa" (Persian / Farsi)

Input data:
${JSON.stringify(promptItems, null, 2)}

Requirements:
- Provide accurate, authentic, eloquent translations of the hadith text, historical context (story), explanation, and practical lessons for each language.
- Return ONLY valid JSON in this exact structure:
{
  "translations": [
    {
      "key": "exact original hadith_text from input",
      "en": {
        "hadith_text": "...",
        "context": "...",
        "explanation": "...",
        "practical_lesson": ["..."]
      },
      "ur": {
        "hadith_text": "...",
        "context": "...",
        "explanation": "...",
        "practical_lesson": ["..."]
      },
      "fa": {
        "hadith_text": "...",
        "context": "...",
        "explanation": "...",
        "practical_lesson": ["..."]
      }
    }
  ]
}
`;

  const resp = await ai.models.generateContent({
    model: 'gemini-3.8-flash',
    contents: prompt,
    config: {
      responseMimeType: 'application/json'
    }
  });

  const parsed = JSON.parse(resp.text);
  if (parsed.translations && Array.isArray(parsed.translations)) {
    for (const t of parsed.translations) {
      if (t.key) {
        results[t.key] = {
          en: t.en,
          ur: t.ur,
          fa: t.fa
        };
      }
    }
  }
}

async function run() {
  const uncompleted = items.filter(it => !results[it.hadith_text]);
  console.log(`Remaining to translate: ${uncompleted.length} items`);

  for (let i = 0; i < uncompleted.length; i += BATCH_SIZE) {
    const chunk = uncompleted.slice(i, i + BATCH_SIZE);
    console.log(`Processing chunk ${Math.floor(i / BATCH_SIZE) + 1}/${Math.ceil(uncompleted.length / BATCH_SIZE)} (items ${i + 1}-${i + chunk.length})...`);
    try {
      await translateBatch(chunk);
      // Save checkpoint
      fs.writeFileSync(targetFile, JSON.stringify(results, null, 2));
      console.log(`Saved checkpoint. Total translated so far: ${Object.keys(results).length}`);
    } catch (err) {
      console.error(`Error in chunk ${i}:`, err.message);
      // Wait 2s and retry once
      await new Promise(r => setTimeout(r, 2000));
      try {
        await translateBatch(chunk);
        fs.writeFileSync(targetFile, JSON.stringify(results, null, 2));
      } catch (err2) {
        console.error(`Retry failed for chunk ${i}:`, err2.message);
      }
    }
  }

  console.log(`Done! Total translated records saved: ${Object.keys(results).length}`);
}

run().catch(console.error);
