# تحويل البرنامج إلى APK

## الطريقة 1 (الأسهل – بدون تثبيت أي شيء): GitHub
1. ارفع محتوى المشروع على مستودع GitHub جديد.
2. افتح تبويب **Actions** ← **Build Android APK** ← انتظر ~5 دقائق.
3. حمّل الملف `leh-qalha-apk` (بداخله `app-debug.apk`) وثبّته على التليفون.

## الطريقة 2: على الكمبيوتر
المتطلبات: Node 22 + JDK 21 + Android SDK (أو Android Studio).
```
npm install
npm run apk
```
الناتج: `android/app/build/outputs/apk/debug/app-debug.apk`
(لو ما اتبناش تلقائياً افتح مجلد `android` في Android Studio ← Build ← Build APK).
