package __APP_ID__;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebView;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.getcapacitor.BridgeActivity;

/**
 * Full-screen (edge-to-edge): the app draws behind the status bar and the
 * navigation bar, both stay visible and transparent. The real bar heights are
 * pushed to the page as CSS variables (--sat / --sab / --sal / --sar).
 */
public class MainActivity extends BridgeActivity {
    private int top = 0, bottom = 0, left = 0, right = 0;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        View decor = window.getDecorView();
        WindowCompat.setDecorFitsSystemWindows(window, false);

        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(Color.TRANSPARENT);
        window.setBackgroundDrawableResource(android.R.color.black);
        if (Build.VERSION.SDK_INT >= 29) {
            window.setNavigationBarContrastEnforced(false);
            window.setStatusBarContrastEnforced(false);
        }
        if (Build.VERSION.SDK_INT >= 28) {
            window.getAttributes().layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        // Dark app => light (white) icons on both bars
        WindowInsetsControllerCompat controller = WindowCompat.getInsetsController(window, decor);
        controller.setAppearanceLightStatusBars(false);
        controller.setAppearanceLightNavigationBars(false);

        ViewCompat.setOnApplyWindowInsetsListener(decor, (v, insets) -> {
            Insets bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            float d = getResources().getDisplayMetrics().density;
            top = Math.round(bars.top / d);
            bottom = Math.round(bars.bottom / d);
            left = Math.round(bars.left / d);
            right = Math.round(bars.right / d);
            injectInsets();
            return insets;
        });
        ViewCompat.requestApplyInsets(decor);

        // The page may finish loading after the first inset callback: re-inject a few times
        for (int delay : new int[]{400, 1200, 2500, 5000}) {
            handler.postDelayed(this::injectInsets, delay);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        injectInsets();
    }

    private void injectInsets() {
        if (getBridge() == null) return;
        WebView web = getBridge().getWebView();
        if (web == null) return;
        final String js = "(function(){var s=document.documentElement.style;"
            + "s.setProperty('--sat','" + top + "px');"
            + "s.setProperty('--sab','" + bottom + "px');"
            + "s.setProperty('--sal','" + left + "px');"
            + "s.setProperty('--sar','" + right + "px');})();";
        web.post(() -> web.evaluateJavascript(js, null));
    }
}
