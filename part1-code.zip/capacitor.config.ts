import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.lehqalha.app',
  appName: 'ليه قالها؟',
  webDir: 'dist',
  backgroundColor: '#0D131F',
  android: {
    // we handle full-screen insets ourselves in MainActivity
    adjustMarginsForEdgeToEdge: 'disable',
    allowMixedContent: false,
  },
  plugins: {
    LocalNotifications: {
      iconColor: '#E2B773',
      sound: 'hadith_tone.wav',
    },
  },
};

export default config;
